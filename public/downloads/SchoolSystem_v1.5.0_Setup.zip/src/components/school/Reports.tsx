'use client';

import { useState } from 'react';
import {
  FileBarChart,
  Download,
  Printer,
  GraduationCap,
  ClipboardCheck,
  BarChart3,
} from 'lucide-react';

const GRADES = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر', 'الحادي عشر', 'الثاني عشر'];

export default function Reports() {
  const [activeReport, setActiveReport] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [reportData, setReportData] = useState<any>(null);
  const [reportGrade, setReportGrade] = useState('الأول');
  const [reportType, setReportType] = useState('attendance');

  const generateReport = async () => {
    setLoading(true);
    try {
      let data;
      if (reportType === 'attendance') {
        const today = new Date().toISOString().split('T')[0];
        const res = await fetch(`/api/school/attendance?date=${today}&grade=${reportGrade}`);
        data = await res.json();
        const present = data.filter((r: any) => r.status === 'present').length;
        const absent = data.filter((r: any) => r.status === 'absent').length;
        const late = data.filter((r: any) => r.status === 'late').length;
        const recorded = data.filter((r: any) => r.status !== 'none').length;
        setReportData({ type: 'attendance', grade: reportGrade, students: data, stats: { present, absent, late, total: data.length, recorded, rate: recorded > 0 ? Math.round((present / recorded) * 100) : 0 } });
      } else if (reportType === 'grades') {
        const res = await fetch(`/api/school/grades?grade=${reportGrade}`);
        data = await res.json();
        const subjectMap: Record<string, any[]> = {};
        data.forEach((g: any) => {
          if (!subjectMap[g.subject]) subjectMap[g.subject] = [];
          subjectMap[g.subject].push(g);
        });
        const subjectSummary = Object.entries(subjectMap).map(([subject, grades]) => {
          const avg = grades.reduce((s: number, g: any) => s + (g.mark || 0), 0) / grades.length;
          return { subject, count: grades.length, avg: avg.toFixed(1), max: Math.max(...grades.map((g: any) => g.mark || 0)), min: Math.min(...grades.map((g: any) => g.mark || 0)) };
        });
        setReportData({ type: 'grades', grade: reportGrade, students: data, subjectSummary });
      } else if (reportType === 'dashboard') {
        const res = await fetch('/api/school/dashboard');
        data = await res.json();
        setReportData({ type: 'dashboard', ...data });
      } else if (reportType === 'students') {
        const res = await fetch(`/api/school/students?grade=${reportGrade}`);
        data = await res.json();
        setReportData({ type: 'students', grade: reportGrade, students: data });
      }
      setActiveReport(reportType);
    } catch (err) {
      console.error(err);
    } finally { setLoading(false); }
  };

  const handlePrint = () => window.print();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">التقارير</h2>
        <p className="text-sm text-gray-500 mt-1">إنشاء وتصدير التقارير المختلفة</p>
      </div>

      {/* Report Types */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { type: 'attendance', label: 'تقرير الحضور', icon: ClipboardCheck, desc: 'تقرير حضور اليوم' },
          { type: 'grades', label: 'تقرير العلامات', icon: BarChart3, desc: 'ملخص العلامات' },
          { type: 'students', label: 'قائمة الطلاب', icon: GraduationCap, desc: 'بيانات الطلاب' },
          { type: 'dashboard', label: 'تقرير عام', icon: FileBarChart, desc: 'ملخص شامل' },
        ].map((r) => (
          <button key={r.type} onClick={() => setReportType(r.type)} className={`rounded-xl border p-5 text-right transition-all hover:shadow-md ${reportType === r.type ? 'border-primary-300 bg-primary-50 shadow-sm' : 'border-gray-100 bg-white'}`}>
            <r.icon className={`h-6 w-6 mb-3 ${reportType === r.type ? 'text-primary-600' : 'text-gray-400'}`} />
            <p className="font-bold text-gray-900 text-sm">{r.label}</p>
            <p className="text-xs text-gray-500 mt-1">{r.desc}</p>
          </button>
        ))}
      </div>

      {/* Grade Selection & Generate */}
      {reportType !== 'dashboard' && (
        <div className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">الصف</label>
              <select value={reportGrade} onChange={(e) => setReportGrade(e.target.value)} className="rounded-lg border border-gray-200 py-2.5 px-4 text-sm focus:border-primary-400 outline-none">
                {GRADES.map((g) => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
            <button onClick={generateReport} disabled={loading} className="inline-flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-lg text-sm font-medium transition-colors disabled:opacity-50">
              <Download className="h-4 w-4" /> {loading ? 'جاري التحميل...' : 'إنشاء التقرير'}
            </button>
          </div>
        </div>
      )}

      {reportType === 'dashboard' && (
        <div className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm">
          <button onClick={generateReport} disabled={loading} className="inline-flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-lg text-sm font-medium transition-colors disabled:opacity-50">
            <Download className="h-4 w-4" /> {loading ? 'جاري التحميل...' : 'إنشاء التقرير العام'}
          </button>
        </div>
      )}

      {/* Report Output */}
      {activeReport && reportData && (
        <div className="rounded-xl border border-gray-100 bg-white shadow-sm overflow-hidden print-area">
          <div className="p-5 border-b flex items-center justify-between print:hidden">
            <h3 className="text-lg font-bold text-gray-900">
              {reportData.type === 'attendance' && `تقرير حضور الصف ${reportData.grade}`}
              {reportData.type === 'grades' && `تقرير علامات الصف ${reportData.grade}`}
              {reportData.type === 'students' && `قائمة طلاب الصف ${reportData.grade}`}
              {reportData.type === 'dashboard' && 'التقرير العام للمدرسة'}
            </h3>
            <button onClick={handlePrint} className="inline-flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900">
              <Printer className="h-4 w-4" /> طباعة
            </button>
          </div>

          <div className="p-5">
            {/* Dashboard Report */}
            {reportData.type === 'dashboard' && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
                  <div className="text-center p-4 rounded-lg bg-primary-50">
                    <p className="text-2xl font-bold text-primary-700">{reportData.totalStudents}</p>
                    <p className="text-xs text-gray-600">إجمالي الطلاب</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-blue-50">
                    <p className="text-2xl font-bold text-blue-700">{reportData.totalTeachers}</p>
                    <p className="text-xs text-gray-600">إجمالي المعلمين</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-emerald-50">
                    <p className="text-2xl font-bold text-emerald-700">{reportData.totalClasses}</p>
                    <p className="text-xs text-gray-600">الفصول الدراسية</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-amber-50">
                    <p className="text-2xl font-bold text-amber-700">{reportData.attendanceRate}%</p>
                    <p className="text-xs text-gray-600">نسبة الحضور</p>
                  </div>
                </div>
              </div>
            )}

            {/* Attendance Report */}
            {reportData.type === 'attendance' && (
              <div className="space-y-4">
                <div className="grid grid-cols-4 gap-3">
                  <div className="text-center p-3 rounded-lg bg-emerald-50">
                    <p className="text-xl font-bold text-emerald-600">{reportData.stats.present}</p>
                    <p className="text-xs text-gray-600">حاضر</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-red-50">
                    <p className="text-xl font-bold text-red-600">{reportData.stats.absent}</p>
                    <p className="text-xs text-gray-600">غائب</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-amber-50">
                    <p className="text-xl font-bold text-amber-600">{reportData.stats.late}</p>
                    <p className="text-xs text-gray-600">متأخر</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-primary-50">
                    <p className="text-xl font-bold text-primary-600">{reportData.stats.rate}%</p>
                    <p className="text-xs text-gray-600">نسبة الحضور</p>
                  </div>
                </div>
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="text-right py-2 px-3 font-semibold text-gray-600">#</th>
                      <th className="text-right py-2 px-3 font-semibold text-gray-600">الاسم</th>
                      <th className="text-center py-2 px-3 font-semibold text-gray-600">الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reportData.students.map((s: any, i: number) => (
                      <tr key={i} className="border-b border-gray-50">
                        <td className="py-2 px-3 text-gray-400">{i + 1}</td>
                        <td className="py-2 px-3 font-medium">{s.name}</td>
                        <td className="py-2 px-3 text-center">
                          {s.status === 'present' && <span className="text-emerald-600 text-xs font-medium">حاضر</span>}
                          {s.status === 'absent' && <span className="text-red-600 text-xs font-medium">غائب</span>}
                          {s.status === 'late' && <span className="text-amber-600 text-xs font-medium">متأخر</span>}
                          {s.status === 'none' && <span className="text-gray-400 text-xs">-</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Grades Report */}
            {reportData.type === 'grades' && reportData.subjectSummary && (
              <div className="space-y-4">
                <h4 className="font-bold text-gray-900">ملخص المواد</h4>
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="text-right py-2 px-3 font-semibold text-gray-600">المادة</th>
                      <th className="text-center py-2 px-3 font-semibold text-gray-600">عدد الطلاب</th>
                      <th className="text-center py-2 px-3 font-semibold text-gray-600">المتوسط</th>
                      <th className="text-center py-2 px-3 font-semibold text-gray-600">الأعلى</th>
                      <th className="text-center py-2 px-3 font-semibold text-gray-600">الأدنى</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reportData.subjectSummary.map((s: any, i: number) => (
                      <tr key={i} className="border-b border-gray-50">
                        <td className="py-2 px-3 font-medium">{s.subject}</td>
                        <td className="py-2 px-3 text-center">{s.count}</td>
                        <td className="py-2 px-3 text-center font-bold text-primary-600">{s.avg}</td>
                        <td className="py-2 px-3 text-center text-emerald-600">{s.max}</td>
                        <td className="py-2 px-3 text-center text-red-500">{s.min}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Students Report */}
            {reportData.type === 'students' && (
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="text-right py-2 px-3 font-semibold text-gray-600">#</th>
                    <th className="text-right py-2 px-3 font-semibold text-gray-600">الاسم</th>
                    <th className="text-center py-2 px-3 font-semibold text-gray-600">الصف</th>
                    <th className="text-center py-2 px-3 font-semibold text-gray-600">الشعبة</th>
                    <th className="text-right py-2 px-3 font-semibold text-gray-600">الهاتف</th>
                    <th className="text-right py-2 px-3 font-semibold text-gray-600">ولي الأمر</th>
                  </tr>
                </thead>
                <tbody>
                  {reportData.students.map((s: any, i: number) => (
                    <tr key={s.id} className="border-b border-gray-50">
                      <td className="py-2 px-3 text-gray-400">{i + 1}</td>
                      <td className="py-2 px-3 font-medium">{s.name}</td>
                      <td className="py-2 px-3 text-center">{s.grade}</td>
                      <td className="py-2 px-3 text-center">{s.section}</td>
                      <td className="py-2 px-3 text-gray-500" dir="ltr">{s.phone || '-'}</td>
                      <td className="py-2 px-3 text-gray-500">{s.guardian_name || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
