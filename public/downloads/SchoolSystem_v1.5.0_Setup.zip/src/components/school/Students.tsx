'use client';

import { useState, useEffect, useCallback } from 'react';
import {
  GraduationCap,
  Plus,
  Search,
  Pencil,
  Trash2,
  Phone,
  UserCheck,
  X,
} from 'lucide-react';

interface Student {
  id: number;
  name: string;
  grade: string;
  section: string;
  phone: string;
  guardian_name: string;
  guardian_phone: string;
  enrolled_at: string;
}

const GRADES = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر', 'الحادي عشر', 'الثاني عشر'];
const SECTIONS = ['أ', 'ب', 'ج', 'د'];

const emptyForm = { name: '', grade: 'الأول', section: 'أ', phone: '', guardian_name: '', guardian_phone: '' };

export default function Students() {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterGrade, setFilterGrade] = useState('');
  const [filterSection, setFilterSection] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [editId, setEditId] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const fetchStudents = useCallback(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (filterGrade) params.set('grade', filterGrade);
    if (filterSection) params.set('section', filterSection);
    fetch(`/api/school/students?${params}`)
      .then((r) => r.json())
      .then((data) => { setStudents(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [search, filterGrade, filterSection]);

  useEffect(() => { fetchStudents(); }, [fetchStudents]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const url = editId ? '/api/school/students' : '/api/school/students';
      const method = editId ? 'PUT' : 'POST';
      const body = editId ? { id: editId, ...form } : form;
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (res.ok) {
        setShowForm(false);
        setForm(emptyForm);
        setEditId(null);
        fetchStudents();
      }
    } finally { setSubmitting(false); }
  };

  const handleEdit = (student: Student) => {
    setEditId(student.id);
    setForm({ name: student.name, grade: student.grade, section: student.section, phone: student.phone || '', guardian_name: student.guardian_name || '', guardian_phone: student.guardian_phone || '' });
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('هل أنت متأكد من حذف هذا الطالب؟')) return;
    await fetch(`/api/school/students?id=${id}`, { method: 'DELETE' });
    fetchStudents();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">إدارة الطلاب</h2>
          <p className="text-sm text-gray-500 mt-1">{students.length} طالب</p>
        </div>
        <button onClick={() => { setForm(emptyForm); setEditId(null); setShowForm(true); }} className="inline-flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-colors">
          <Plus className="h-4 w-4" /> إضافة طالب
        </button>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input placeholder="بحث بالاسم..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full rounded-lg border border-gray-200 bg-white py-2.5 pr-10 pl-4 text-sm focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none" />
        </div>
        <select value={filterGrade} onChange={(e) => setFilterGrade(e.target.value)} className="rounded-lg border border-gray-200 bg-white py-2.5 px-4 text-sm focus:border-primary-400 outline-none">
          <option value="">كل الصفوف</option>
          {GRADES.map((g) => <option key={g} value={g}>{g}</option>)}
        </select>
        <select value={filterSection} onChange={(e) => setFilterSection(e.target.value)} className="rounded-lg border border-gray-200 bg-white py-2.5 px-4 text-sm focus:border-primary-400 outline-none">
          <option value="">كل الشعب</option>
          {SECTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => setShowForm(false)}>
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b">
              <h3 className="text-lg font-bold text-gray-900">{editId ? 'تعديل الطالب' : 'إضافة طالب جديد'}</h3>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-600"><X className="h-5 w-5" /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">اسم الطالب *</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full rounded-lg border border-gray-200 px-4 py-2.5 text-sm focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">الصف *</label>
                  <select required value={form.grade} onChange={(e) => setForm({ ...form, grade: e.target.value })} className="w-full rounded-lg border border-gray-200 px-4 py-2.5 text-sm focus:border-primary-400 outline-none">
                    {GRADES.map((g) => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">الشعبة *</label>
                  <select required value={form.section} onChange={(e) => setForm({ ...form, section: e.target.value })} className="w-full rounded-lg border border-gray-200 px-4 py-2.5 text-sm focus:border-primary-400 outline-none">
                    {SECTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">هاتف الطالب</label>
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} dir="ltr" className="w-full rounded-lg border border-gray-200 px-4 py-2.5 text-sm focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">اسم ولي الأمر</label>
                <input value={form.guardian_name} onChange={(e) => setForm({ ...form, guardian_name: e.target.value })} className="w-full rounded-lg border border-gray-200 px-4 py-2.5 text-sm focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">هاتف ولي الأمر</label>
                <input value={form.guardian_phone} onChange={(e) => setForm({ ...form, guardian_phone: e.target.value })} dir="ltr" className="w-full rounded-lg border border-gray-200 px-4 py-2.5 text-sm focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 rounded-lg border border-gray-200 px-4 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50">إلغاء</button>
                <button type="submit" disabled={submitting} className="flex-1 rounded-lg bg-primary-600 hover:bg-primary-700 text-white px-4 py-2.5 text-sm font-medium disabled:opacity-50">
                  {editId ? 'تحديث' : 'إضافة'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Students Table */}
      <div className="rounded-xl border border-gray-100 bg-white shadow-sm overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-4 border-primary-600 border-t-transparent" /></div>
        ) : students.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-gray-400">
            <GraduationCap className="h-12 w-12 mb-3" />
            <p className="font-medium">لا يوجد طلاب</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-right py-3 px-4 font-semibold text-gray-600">#</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-600">الاسم</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-600">الصف</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-600">الشعبة</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-600">الهاتف</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-600">ولي الأمر</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-600">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {students.map((s, i) => (
                  <tr key={s.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                    <td className="py-3 px-4 text-gray-400">{i + 1}</td>
                    <td className="py-3 px-4 font-medium text-gray-900">{s.name}</td>
                    <td className="py-3 px-4"><span className="bg-primary-100 text-primary-700 text-xs font-medium px-2.5 py-1 rounded-full">{s.grade}</span></td>
                    <td className="py-3 px-4 text-gray-600">{s.section}</td>
                    <td className="py-3 px-4 text-gray-500 text-xs" dir="ltr">{s.phone || '-'}</td>
                    <td className="py-3 px-4 text-gray-500 text-xs">{s.guardian_name || '-'}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center justify-center gap-1">
                        <button onClick={() => handleEdit(s)} className="p-1.5 rounded-md text-blue-600 hover:bg-blue-50" title="تعديل"><Pencil className="h-4 w-4" /></button>
                        <button onClick={() => handleDelete(s.id)} className="p-1.5 rounded-md text-red-500 hover:bg-red-50" title="حذف"><Trash2 className="h-4 w-4" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
