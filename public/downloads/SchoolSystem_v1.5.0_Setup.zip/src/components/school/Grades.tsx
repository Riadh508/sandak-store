'use client';

import { useState, useEffect } from 'react';
import {
  BarChart3,
  Save,
  BookOpen,
  FileText,
} from 'lucide-react';

interface StudentGrade {
  student_id: number;
  name: string;
  grade: string;
  section: string;
  grade_id?: number;
  mark: number | null;
  max_mark: number;
  exam_type: string;
  date: string;
}

interface GradeRecord {
  student_id?: number;
  grade_id?: number;
  student_name?: string;
  mark: number | string | null;
  max_mark: number;
  subject?: string;
  exam_type?: string;
  date?: string;
}

const GRADES = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر', 'الحادي عشر', 'الثاني عشر'];
const EXAM_TYPES = ['اختبار شهري', 'اختبار نصفي', 'اختبار نهائي', 'واجب', 'مشاركة'];

export default function Grades() {
  const [grade, setGrade] = useState('الأول');
  const [subject, setSubject] = useState('');
  const [examType, setExamType] = useState('اختبار نهائي');
  const [students, setStudents] = useState<StudentGrade[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loaded, setLoaded] = useState(false);

  const fetchGrades = () => {
    if (!subject) { alert('يرجى إدخال اسم المادة'); return; }
    setLoading(true);
    const params = new URLSearchParams({ grade, subject, examType });
    fetch(`/api/school/grades?${params}`)
      .then((r) => r.json())
      .then((data) => { setStudents(data); setLoading(false); setLoaded(true); })
      .catch(() => setLoading(false));
  };

  const handleMarkChange = (index: number, value: string) => {
    setStudents((prev) => {
      const updated = [...prev];
      const mark = value === '' ? null : parseFloat(value);
      updated[index] = { ...updated[index], mark };
      return updated;
    });
  };

  const handleSave = async () => {
    if (!subject) { alert('يرجى إدخال اسم المادة'); return; }
    setSaving(true);
    try {
      const records: GradeRecord[] = students.map((s) => ({
        student_id: s.student_id,
        grade_id: s.grade_id,
        mark: s.mark,
        max_mark: s.max_mark || 100,
      }));
      const res = await fetch('/api/school/grades', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject, examType, records }),
      });
      if (res.ok) { alert('تم حفظ العلامات بنجاح'); }
    } finally { setSaving(false); }
  };

  const classAverage = students.length > 0
    ? (students.filter((s) => s.mark !== null && s.mark !== undefined).reduce((sum, s) => sum + (s.mark || 0), 0) / (students.filter((s) => s.mark !== null && s.mark !== undefined).length || 1)).toFixed(1)
    : '0';

  const successCount = students.filter((s) => s.mark !== null && s.mark !== undefined && s.mark >= 50).length;
  const failCount = students.filter((s) => s.mark !== null && s.mark !== undefined && s.mark < 50).length;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">إدارة العلامات</h2>
        <p className="text-sm text-gray-500 mt-1">تسجيل وتعديل علامات الطلاب</p>
      </div>

      {/* Filters */}
      <div className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end flex-wrap">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">الصف</label>
            <select value={grade} onChange={(e) => setGrade(e.target.value)} className="rounded-lg border border-gray-200 py-2.5 px-4 text-sm focus:border-primary-400 outline-none">
              {GRADES.map((g) => <option key={g} value={g}>{g}</option>)}
            </select>
          </div>
          <div className="flex-1 min-w-[150px]">
            <label className="block text-sm font-medium text-gray-700 mb-1">المادة *</label>
            <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="مثال: الرياضيات" className="w-full rounded-lg border border-gray-200 py-2.5 px-4 text-sm focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">نوع الامتحان</label>
            <select value={examType} onChange={(e) => setExamType(e.target.value)} className="rounded-lg border border-gray-200 py-2.5 px-4 text-sm focus:border-primary-400 outline-none">
              {EXAM_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <button onClick={fetchGrades} className="inline-flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-lg text-sm font-medium transition-colors">
            <BarChart3 className="h-4 w-4" /> تحميل الطلاب
          </button>
        </div>
      </div>

      {/* Summary */}
      {loaded && students.length > 0 && (
        <div className="grid grid-cols-3 gap-4">
          <div className="rounded-xl bg-emerald-50 p-4 text-center">
            <p className="text-2xl font-bold text-emerald-600">{successCount}</p>
            <p className="text-xs text-emerald-700">ناجح</p>
          </div>
          <div className="rounded-xl bg-red-50 p-4 text-center">
            <p className="text-2xl font-bold text-red-600">{failCount}</p>
            <p className="text-xs text-red-700">راسب</p>
          </div>
          <div className="rounded-xl bg-primary-50 p-4 text-center">
            <p className="text-2xl font-bold text-primary-600">{classAverage}</p>
            <p className="text-xs text-primary-700">متوسط الصف</p>
          </div>
        </div>
      )}

      {/* Students Grades */}
      {loading ? (
        <div className="flex items-center justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-4 border-primary-600 border-t-transparent" /></div>
      ) : students.length > 0 ? (
        <div className="rounded-xl border border-gray-100 bg-white shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-right py-3 px-4 font-semibold text-gray-600">#</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-600">اسم الطالب</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-600">العلامة (من 100)</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-600">الحالة</th>
                </tr>
              </thead>
              <tbody>
                {students.map((s, i) => {
                  const isPass = s.mark !== null && s.mark !== undefined && s.mark >= 50;
                  const isFail = s.mark !== null && s.mark !== undefined && s.mark < 50;
                  return (
                    <tr key={s.student_id} className={`border-b border-gray-50 hover:bg-gray-50 transition-colors ${isFail ? 'bg-red-50/30' : ''}`}>
                      <td className="py-3 px-4 text-gray-400">{i + 1}</td>
                      <td className="py-3 px-4 font-medium text-gray-900">{s.name}</td>
                      <td className="py-3 px-4">
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={s.mark === null || s.mark === undefined ? '' : s.mark}
                          onChange={(e) => handleMarkChange(i, e.target.value)}
                          className="w-20 rounded-lg border border-gray-200 px-3 py-1.5 text-center text-sm focus:border-primary-400 outline-none"
                          dir="ltr"
                        />
                      </td>
                      <td className="py-3 px-4 text-center">
                        {s.mark === null || s.mark === undefined ? (
                          <span className="text-gray-400 text-xs">-</span>
                        ) : isPass ? (
                          <span className="text-emerald-600 text-xs font-medium">ناجح</span>
                        ) : (
                          <span className="text-red-600 text-xs font-medium">راسب</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="p-4 border-t">
            <button onClick={handleSave} disabled={saving} className="w-full inline-flex items-center justify-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-5 py-3 rounded-xl text-sm font-medium transition-colors disabled:opacity-50">
              <Save className="h-4 w-4" /> {saving ? 'جاري الحفظ...' : 'حفظ العلامات'}
            </button>
          </div>
        </div>
      ) : loaded && students.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-gray-400 rounded-xl border border-gray-100 bg-white">
          <BarChart3 className="h-12 w-12 mb-3" />
          <p className="font-medium">لا يوجد طلاب في هذا الصف</p>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-16 text-gray-400 rounded-xl border border-gray-100 bg-white">
          <FileText className="h-12 w-12 mb-3" />
          <p className="font-medium">اختر الصف والمادة ثم اضغط تحميل الطلاب</p>
        </div>
      )}
    </div>
  );
}
