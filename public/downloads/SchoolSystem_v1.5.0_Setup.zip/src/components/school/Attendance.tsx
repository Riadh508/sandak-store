'use client';

import { useState, useEffect } from 'react';
import {
  ClipboardCheck,
  Save,
  CalendarDays,
  Users,
} from 'lucide-react';

interface StudentAttendance {
  id: number;
  name: string;
  grade: string;
  section: string;
  status: string;
  notes: string;
  attendance_id?: number;
  student_id: number;
}

const GRADES = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر', 'الحادي عشر', 'الثاني عشر'];
const SECTIONS = ['أ', 'ب', 'ج', 'د'];
const STATUSES = [
  { value: 'present', label: 'حاضر', color: 'bg-emerald-500 text-white' },
  { value: 'absent', label: 'غائب', color: 'bg-red-500 text-white' },
  { value: 'late', label: 'متأخر', color: 'bg-amber-500 text-white' },
  { value: 'none', label: 'لم يحدد', color: 'bg-gray-200 text-gray-500' },
];

export default function Attendance() {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [grade, setGrade] = useState('الأول');
  const [section, setSection] = useState('أ');
  const [students, setStudents] = useState<StudentAttendance[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loaded, setLoaded] = useState(false);

  const fetchAttendance = () => {
    setLoading(true);
    const params = new URLSearchParams({ date, grade, section });
    fetch(`/api/school/attendance?${params}`)
      .then((r) => r.json())
      .then((data) => { setStudents(data); setLoading(false); setLoaded(true); })
      .catch(() => setLoading(false));
  };

  const handleStatusChange = (index: number, status: string) => {
    setStudents((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], status };
      return updated;
    });
  };

  const handleNotesChange = (index: number, notes: string) => {
    setStudents((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], notes };
      return updated;
    });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const records = students.map((s) => ({
        student_id: s.student_id || s.id,
        status: s.status,
        notes: s.notes,
      }));
      const res = await fetch('/api/school/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ date, records }),
      });
      if (res.ok) {
        alert('تم حفظ الحضور بنجاح');
      }
    } finally { setSaving(false); }
  };

  const handleMarkAll = (status: string) => {
    setStudents((prev) => prev.map((s) => ({ ...s, status })));
  };

  const presentCount = students.filter((s) => s.status === 'present').length;
  const absentCount = students.filter((s) => s.status === 'absent').length;
  const lateCount = students.filter((s) => s.status === 'late').length;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">تسجيل الحضور</h2>
        <p className="text-sm text-gray-500 mt-1">تسجيل حضور وغياب الطلاب</p>
      </div>

      {/* Filters */}
      <div className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">التاريخ</label>
            <div className="relative">
              <CalendarDays className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="rounded-lg border border-gray-200 py-2.5 pr-10 pl-4 text-sm focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">الصف</label>
            <select value={grade} onChange={(e) => setGrade(e.target.value)} className="rounded-lg border border-gray-200 py-2.5 px-4 text-sm focus:border-primary-400 outline-none">
              {GRADES.map((g) => <option key={g} value={g}>{g}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">الشعبة</label>
            <select value={section} onChange={(e) => setSection(e.target.value)} className="rounded-lg border border-gray-200 py-2.5 px-4 text-sm focus:border-primary-400 outline-none">
              {SECTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <button onClick={fetchAttendance} className="inline-flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-lg text-sm font-medium transition-colors">
            <ClipboardCheck className="h-4 w-4" /> تحميل الطلاب
          </button>
        </div>
      </div>

      {/* Summary & Quick Actions */}
      {loaded && students.length > 0 && (
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex gap-4 text-sm">
            <span className="text-emerald-600 font-medium">حاضر: {presentCount}</span>
            <span className="text-red-500 font-medium">غائب: {absentCount}</span>
            <span className="text-amber-600 font-medium">متأخر: {lateCount}</span>
          </div>
          <div className="flex gap-2">
            <button onClick={() => handleMarkAll('present')} className="text-xs bg-emerald-100 text-emerald-700 px-3 py-1.5 rounded-lg hover:bg-emerald-200 font-medium">تحديد الكل حاضر</button>
            <button onClick={() => handleMarkAll('absent')} className="text-xs bg-red-100 text-red-700 px-3 py-1.5 rounded-lg hover:bg-red-200 font-medium">تحديد الكل غائب</button>
          </div>
        </div>
      )}

      {/* Students List */}
      {loading ? (
        <div className="flex items-center justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-4 border-primary-600 border-t-transparent" /></div>
      ) : students.length === 0 && loaded ? (
        <div className="flex flex-col items-center justify-center py-16 text-gray-400 rounded-xl border border-gray-100 bg-white">
          <Users className="h-12 w-12 mb-3" />
          <p className="font-medium">لا يوجد طلاب في هذا الصف</p>
        </div>
      ) : students.length > 0 ? (
        <div className="space-y-2">
          {students.map((s, i) => (
            <div key={s.student_id || s.id} className="rounded-xl border border-gray-100 bg-white p-4 shadow-sm flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-3">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-100 text-sm font-bold text-primary-700">{i + 1}</span>
                <div>
                  <p className="font-medium text-gray-900">{s.name}</p>
                  <p className="text-xs text-gray-400">{s.grade} - {s.section}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 flex-wrap">
                <input placeholder="ملاحظات..." value={s.notes} onChange={(e) => handleNotesChange(i, e.target.value)} className="rounded-lg border border-gray-200 px-3 py-1.5 text-xs w-32 focus:border-primary-400 outline-none" />
                <div className="flex gap-1">
                  {STATUSES.map((st) => (
                    <button key={st.value} onClick={() => handleStatusChange(i, st.value)} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${s.status === st.value ? st.color : 'bg-gray-50 text-gray-400 hover:bg-gray-100'}`}>
                      {st.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ))}
          <button onClick={handleSave} disabled={saving} className="w-full inline-flex items-center justify-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-5 py-3 rounded-xl text-sm font-medium transition-colors disabled:opacity-50 mt-4">
            <Save className="h-4 w-4" /> {saving ? 'جاري الحفظ...' : 'حفظ الحضور'}
          </button>
        </div>
      ) : !loaded && (
        <div className="flex flex-col items-center justify-center py-16 text-gray-400 rounded-xl border border-gray-100 bg-white">
          <CalendarDays className="h-12 w-12 mb-3" />
          <p className="font-medium">اختر الصف والتاريخ ثم اضغط تحميل الطلاب</p>
        </div>
      )}
    </div>
  );
}
