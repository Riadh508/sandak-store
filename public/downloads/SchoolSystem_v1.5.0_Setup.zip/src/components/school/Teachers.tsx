'use client';

import { useState, useEffect, useCallback } from 'react';
import {
  Users,
  Plus,
  Search,
  Pencil,
  Trash2,
  X,
  BookOpen,
} from 'lucide-react';

interface Teacher {
  id: number;
  name: string;
  subject: string;
  phone: string;
  email: string;
  assignedGrades?: string[];
}

const GRADES = ['الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر', 'الحادي عشر', 'الثاني عشر'];

const emptyForm = { name: '', subject: '', phone: '', email: '', assignedGrades: [] as string[] };

export default function Teachers() {
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [editId, setEditId] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [selectedGrades, setSelectedGrades] = useState<string[]>([]);

  const fetchTeachers = useCallback(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    fetch(`/api/school/teachers?${params}`)
      .then((r) => r.json())
      .then((data) => { setTeachers(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [search]);

  useEffect(() => { fetchTeachers(); }, [fetchTeachers]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const body = { ...form, assignedGrades: selectedGrades };
      const method = editId ? 'PUT' : 'POST';
      if (editId) (body as any).id = editId;
      const res = await fetch('/api/school/teachers', { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (res.ok) {
        setShowForm(false);
        setForm(emptyForm);
        setSelectedGrades([]);
        setEditId(null);
        fetchTeachers();
      }
    } finally { setSubmitting(false); }
  };

  const handleEdit = async (teacher: Teacher) => {
    let teacherData = teacher;
    if (!teacher.assignedGrades) {
      const res = await fetch(`/api/school/teachers?id=${teacher.id}`);
      teacherData = await res.json();
    }
    setEditId(teacherData.id);
    setForm({ name: teacherData.name, subject: teacherData.subject, phone: teacherData.phone || '', email: teacherData.email || '', assignedGrades: [] });
    setSelectedGrades(teacherData.assignedGrades || []);
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('هل أنت متأكد من حذف هذا المعلم؟')) return;
    await fetch(`/api/school/teachers?id=${id}`, { method: 'DELETE' });
    fetchTeachers();
  };

  const toggleGrade = (grade: string) => {
    setSelectedGrades((prev) => prev.includes(grade) ? prev.filter((g) => g !== grade) : [...prev, grade]);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">إدارة المعلمين</h2>
          <p className="text-sm text-gray-500 mt-1">{teachers.length} معلم</p>
        </div>
        <button onClick={() => { setForm(emptyForm); setEditId(null); setSelectedGrades([]); setShowForm(true); }} className="inline-flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-colors">
          <Plus className="h-4 w-4" /> إضافة معلم
        </button>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
        <input placeholder="بحث بالاسم..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full rounded-lg border border-gray-200 bg-white py-2.5 pr-10 pl-4 text-sm focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none" />
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => setShowForm(false)}>
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b">
              <h3 className="text-lg font-bold text-gray-900">{editId ? 'تعديل المعلم' : 'إضافة معلم جديد'}</h3>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-600"><X className="h-5 w-5" /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">اسم المعلم *</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full rounded-lg border border-gray-200 px-4 py-2.5 text-sm focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">المادة *</label>
                <input required value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className="w-full rounded-lg border border-gray-200 px-4 py-2.5 text-sm focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">الهاتف</label>
                  <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} dir="ltr" className="w-full rounded-lg border border-gray-200 px-4 py-2.5 text-sm focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
                  <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} dir="ltr" type="email" className="w-full rounded-lg border border-gray-200 px-4 py-2.5 text-sm focus:border-primary-400 focus:ring-2 focus:ring-primary-100 outline-none" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">الصفوف المسندة</label>
                <div className="flex flex-wrap gap-2">
                  {GRADES.map((g) => (
                    <button key={g} type="button" onClick={() => toggleGrade(g)} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${selectedGrades.includes(g) ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                      {g}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 rounded-lg border border-gray-200 px-4 py-2.5 text-sm font-medium text-gray-600 hover:bg-gray-50">إلغاء</button>
                <button type="submit" disabled={submitting} className="flex-1 rounded-lg bg-primary-600 hover:bg-primary-700 text-white px-4 py-2.5 text-sm font-medium disabled:opacity-50">
                  {editId ? 'تحديث' : 'إضافة'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Teachers List */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {loading ? (
          <div className="col-span-full flex items-center justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-4 border-primary-600 border-t-transparent" /></div>
        ) : teachers.length === 0 ? (
          <div className="col-span-full flex flex-col items-center justify-center py-16 text-gray-400">
            <Users className="h-12 w-12 mb-3" />
            <p className="font-medium">لا يوجد معلمين</p>
          </div>
        ) : (
          teachers.map((t) => (
            <div key={t.id} className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-100">
                  <BookOpen className="h-5 w-5 text-primary-600" />
                </div>
                <div className="flex gap-1">
                  <button onClick={() => handleEdit(t)} className="p-1.5 rounded-md text-blue-600 hover:bg-blue-50"><Pencil className="h-4 w-4" /></button>
                  <button onClick={() => handleDelete(t.id)} className="p-1.5 rounded-md text-red-500 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
                </div>
              </div>
              <h4 className="font-bold text-gray-900">{t.name}</h4>
              <p className="text-sm text-primary-600 font-medium mt-1">{t.subject}</p>
              <div className="mt-3 space-y-1 text-xs text-gray-500">
                {t.phone && <p dir="ltr">📱 {t.phone}</p>}
                {t.email && <p dir="ltr">📧 {t.email}</p>}
              </div>
              {t.assignedGrades && t.assignedGrades.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-3">
                  {t.assignedGrades.map((g) => (
                    <span key={g} className="bg-purple-50 text-primary-700 text-[10px] font-medium px-2 py-0.5 rounded-full">{g}</span>
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
