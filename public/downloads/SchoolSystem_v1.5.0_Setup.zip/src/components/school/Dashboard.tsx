'use client';

import { useState, useEffect } from 'react';
import {
  Users,
  GraduationCap,
  BookOpen,
  ClipboardCheck,
  TrendingUp,
  UserCheck,
  UserX,
  Clock,
} from 'lucide-react';

interface DashboardStats {
  totalStudents: number;
  totalTeachers: number;
  totalClasses: number;
  attendanceRate: number;
  totalPresentToday: number;
  totalAbsentToday: number;
  totalLateToday: number;
  totalRecordedToday: number;
  studentsByGrade: { grade: string; section: string; count: number }[];
  recentStudents: { id: number; name: string; grade: string; section: string; enrolled_at: string }[];
  subjectAverages: { subject: string; exam_type: string; avg_mark: number; max_mark: number; min_mark: number; count: number }[];
  attendanceTrend: { date: string; present: number; absent: number; late: number; total: number }[];
  today: string;
}

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/school/dashboard')
      .then((res) => res.json())
      .then((data) => {
        setStats(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary-600 border-t-transparent" />
      </div>
    );
  }

  if (!stats) {
    return <div className="text-center py-20 text-gray-500">فشل في تحميل البيانات</div>;
  }

  const statCards = [
    { label: 'إجمالي الطلاب', value: stats.totalStudents, icon: GraduationCap, color: 'bg-purple-100 text-purple-600' },
    { label: 'إجمالي المعلمين', value: stats.totalTeachers, icon: Users, color: 'bg-blue-100 text-blue-600' },
    { label: 'الفصول الدراسية', value: stats.totalClasses, icon: BookOpen, color: 'bg-emerald-100 text-emerald-600' },
    { label: 'نسبة الحضور', value: `${stats.attendanceRate}%`, icon: ClipboardCheck, color: 'bg-amber-100 text-amber-600' },
  ];

  const todayCards = [
    { label: 'حاضرون', value: stats.totalPresentToday, icon: UserCheck, color: 'text-emerald-600' },
    { label: 'غائبون', value: stats.totalAbsentToday, icon: UserX, color: 'text-red-600' },
    { label: 'متأخرون', value: stats.totalLateToday, icon: Clock, color: 'text-amber-600' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">لوحة التحكم</h2>
        <p className="text-sm text-gray-500 mt-1">نظرة عامة على المدرسة - {stats.today}</p>
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {statCards.map((card) => (
          <div key={card.label} className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-gray-500">{card.label}</p>
                <p className="mt-1 text-2xl font-bold text-gray-900">{card.value}</p>
              </div>
              <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${card.color}`}>
                <card.icon className="h-5 w-5" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Today's Attendance */}
      <div className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">حضور اليوم</h3>
        <div className="grid grid-cols-3 gap-4">
          {todayCards.map((card) => (
            <div key={card.label} className="text-center p-4 rounded-lg bg-gray-50">
              <card.icon className={`h-6 w-6 mx-auto mb-2 ${card.color}`} />
              <p className="text-xl font-bold text-gray-900">{card.value}</p>
              <p className="text-xs text-gray-500 mt-1">{card.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Students by Grade */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">الطلاب حسب الصف</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {stats.studentsByGrade.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-4">لا توجد بيانات</p>
            ) : (
              stats.studentsByGrade.map((g) => (
                <div key={`${g.grade}-${g.section}`} className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                  <span className="font-medium text-gray-700">الصف {g.grade} - {g.section}</span>
                  <span className="bg-primary-100 text-primary-700 text-sm font-bold px-3 py-1 rounded-full">{g.count}</span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Students */}
        <div className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">آخر الطلاب المسجلين</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {stats.recentStudents.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-4">لا توجد بيانات</p>
            ) : (
              stats.recentStudents.map((s) => (
                <div key={s.id} className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                  <div>
                    <p className="font-medium text-gray-700">{s.name}</p>
                    <p className="text-xs text-gray-400">الصف {s.grade} - {s.section}</p>
                  </div>
                  <span className="text-xs text-gray-400">{s.enrolled_at?.split('T')[0]}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Subject Averages */}
      {stats.subjectAverages.length > 0 && (
        <div className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">متوسط العلامات حسب المادة</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-right py-3 px-4 font-semibold text-gray-600">المادة</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-600">نوع الامتحان</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-600">المتوسط</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-600">الأعلى</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-600">الأدنى</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-600">عدد الطلاب</th>
                </tr>
              </thead>
              <tbody>
                {stats.subjectAverages.map((s, i) => (
                  <tr key={i} className="border-b border-gray-50 hover:bg-gray-50">
                    <td className="py-3 px-4 font-medium text-gray-700">{s.subject}</td>
                    <td className="py-3 px-4 text-gray-500">{s.exam_type}</td>
                    <td className="py-3 px-4 text-center font-bold text-primary-600">{s.avg_mark?.toFixed(1)}</td>
                    <td className="py-3 px-4 text-center text-emerald-600">{s.max_mark}</td>
                    <td className="py-3 px-4 text-center text-red-500">{s.min_mark}</td>
                    <td className="py-3 px-4 text-center text-gray-500">{s.count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Attendance Trend */}
      {stats.attendanceTrend.length > 0 && (
        <div className="rounded-xl border border-gray-100 bg-white p-5 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">اتجاه الحضور (آخر 7 أيام)</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-right py-3 px-4 font-semibold text-gray-600">التاريخ</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-600">حاضر</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-600">غائب</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-600">متأخر</th>
                  <th className="text-center py-3 px-4 font-semibold text-gray-600">الإجمالي</th>
                </tr>
              </thead>
              <tbody>
                {stats.attendanceTrend.map((t) => (
                  <tr key={t.date} className="border-b border-gray-50 hover:bg-gray-50">
                    <td className="py-3 px-4 font-medium text-gray-700">{t.date}</td>
                    <td className="py-3 px-4 text-center text-emerald-600">{t.present}</td>
                    <td className="py-3 px-4 text-center text-red-500">{t.absent}</td>
                    <td className="py-3 px-4 text-center text-amber-600">{t.late}</td>
                    <td className="py-3 px-4 text-center font-bold text-gray-700">{t.total}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
