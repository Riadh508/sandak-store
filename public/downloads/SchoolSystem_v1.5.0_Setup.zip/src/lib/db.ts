import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'data', 'school.db');
const DIR = path.dirname(DB_PATH);

let db: Database | null = null;

const CREATE_TABLES_SQL = `
  CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    grade TEXT NOT NULL,
    section TEXT NOT NULL,
    phone TEXT,
    guardian_name TEXT,
    guardian_phone TEXT,
    enrolled_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS teachers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    subject TEXT NOT NULL,
    phone TEXT,
    email TEXT
  );

  CREATE TABLE IF NOT EXISTS teacher_grades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    teacher_id INTEGER NOT NULL,
    grade TEXT NOT NULL,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    status TEXT DEFAULT 'present',
    notes TEXT,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS grades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    subject TEXT NOT NULL,
    exam_type TEXT NOT NULL,
    mark REAL,
    max_mark REAL DEFAULT 100,
    date TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_students_grade ON students(grade, section);
  CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date);
  CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance(student_id);
  CREATE INDEX IF NOT EXISTS idx_grades_student ON grades(student_id);
  CREATE INDEX IF NOT EXISTS idx_grades_subject ON grades(subject);
`;

export async function getDb(): Promise<Database> {
  if (!db) {
    if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });

    const SQL = await initSqlJs();

    if (fs.existsSync(DB_PATH)) {
      const buf = fs.readFileSync(DB_PATH);
      db = new SQL.Database(buf);
    } else {
      db = new SQL.Database();
      db.run(CREATE_TABLES_SQL);
      saveDb();
    }
  }
  return db;
}

export default getDb;

export function saveDb(): void {
  if (!db) return;
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

export async function getAll<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T[]> {
  const database = await getDb();
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  const results: T[] = [];
  while (stmt.step()) {
    results.push(stmt.getAsObject() as T);
  }
  stmt.free();
  return results;
}

export async function getOne<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T | null> {
  const database = await getDb();
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  let result: T | null = null;
  if (stmt.step()) {
    result = stmt.getAsObject() as T;
  }
  stmt.free();
  return result;
}

export async function run(sql: string, params?: unknown[]): Promise<number> {
  const database = await getDb();
  database.run(sql, params);
  saveDb();
  const res = database.exec('SELECT last_insert_rowid()');
  return res.length > 0 && res[0].values.length > 0 ? Number(res[0].values[0][0]) : 0;
}

export function getLastInsertId(database: Database): number {
  const res = database.exec('SELECT last_insert_rowid()');
  return res.length > 0 && res[0].values.length > 0 ? Number(res[0].values[0][0]) : 0;
}

export function dbRun(database: Database, sql: string, params?: unknown[]): void {
  database.run(sql, params);
}

export function dbAll<T = Record<string, unknown>>(database: Database, sql: string, params?: unknown[]): T[] {
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  const results: T[] = [];
  while (stmt.step()) {
    results.push(stmt.getAsObject() as T);
  }
  stmt.free();
  return results;
}

export function dbGet<T = Record<string, unknown>>(database: Database, sql: string, params?: unknown[]): T | null {
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  let result: T | null = null;
  if (stmt.step()) {
    result = stmt.getAsObject() as T;
  }
  stmt.free();
  return result;
}

export async function transaction<T>(fn: (database: Database) => T): Promise<T> {
  const database = await getDb();
  try {
    database.run('BEGIN');
    const result = fn(database);
    database.run('COMMIT');
    saveDb();
    return result;
  } catch (error) {
    database.run('ROLLBACK');
    throw error;
  }
}
