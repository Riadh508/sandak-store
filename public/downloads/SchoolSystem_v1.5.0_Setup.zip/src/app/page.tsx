'use client';

import { useState } from 'react';
import {
  LayoutDashboard,
  GraduationCap,
  Users,
  ClipboardCheck,
  BarChart3,
  FileBarChart,
  School,
} from 'lucide-react';
import Dashboard from '@/components/school/Dashboard';
import Students from '@/components/school/Students';
import Teachers from '@/components/school/Teachers';
import Attendance from '@/components/school/Attendance';
import Grades from '@/components/school/Grades';
import Reports from '@/components/school/Reports';

const tabs = [
  { id: 'dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
  { id: 'students', label: 'الطلاب', icon: GraduationCap },
  { id: 'teachers', label: 'المعلمون', icon: Users },
  { id: 'attendance', label: 'الحضور', icon: ClipboardCheck },
  { id: 'grades', label: 'العلامات', icon: BarChart3 },
  { id: 'reports', label: 'التقارير', icon: FileBarChart },
];

export default function HomePage() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'students': return <Students />;
      case 'teachers': return <Teachers />;
      case 'attendance': return <Attendance />;
      case 'grades': return <Grades />;
      case 'reports': return <Reports />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary-600 to-primary-500">
                <School className="h-5 w-5 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold leading-tight text-primary-700">نظام إدارة المدرسة</span>
                <span className="text-[10px] leading-tight text-muted-foreground">إدارة شاملة للعملية التعليمية</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar - Desktop */}
        <aside className="hidden lg:block w-64 border-l bg-white">
          <nav className="p-4 space-y-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-primary-50 text-primary-700 shadow-sm'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                <tab.icon className={`h-5 w-5 ${activeTab === tab.id ? 'text-primary-600' : 'text-gray-400'}`} />
                {tab.label}
              </button>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          {/* Mobile Tabs */}
          <div className="lg:hidden border-b bg-white sticky top-16 z-40">
            <div className="flex overflow-x-auto px-2 py-2 gap-1 scrollbar-hide">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-1.5 whitespace-nowrap rounded-lg px-3 py-2 text-xs font-medium transition-all shrink-0 ${
                    activeTab === tab.id
                      ? 'bg-primary-600 text-white shadow-sm'
                      : 'text-gray-500 bg-gray-100 hover:bg-gray-200'
                  }`}
                >
                  <tab.icon className="h-3.5 w-3.5" />
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="p-4 sm:p-6 max-w-6xl mx-auto animate-fade-in" key={activeTab}>
            {renderContent()}
          </div>
        </main>
      </div>

      {/* Footer */}
      <footer className="border-t bg-white py-4 text-center text-xs text-gray-400">
        نظام إدارة المدرسة © {new Date().getFullYear()} — جميع الحقوق محفوظة
      </footer>
    </div>
  );
}
