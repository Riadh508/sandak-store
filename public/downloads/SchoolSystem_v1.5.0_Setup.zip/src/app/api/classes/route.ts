import { NextResponse } from 'next/server';
import { getAll, run } from '@/lib/db';

export async function GET() {
  try {
    const classes = await getAll('SELECT * FROM classes ORDER BY name ASC');
    return NextResponse.json(classes);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch classes' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const insertId = await run('INSERT INTO classes (name, teacher_id) VALUES (?, ?)', [body.name, body.teacher_id || null]);
    const cls = await import('@/lib/db').then(m => m.getOne('SELECT * FROM classes WHERE id = ?', [insertId]));
    return NextResponse.json(cls, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to create class';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, ...data } = body;
    await run('UPDATE classes SET name = ?, teacher_id = ? WHERE id = ?', [data.name, data.teacher_id || null, id]);
    const cls = await import('@/lib/db').then(m => m.getOne('SELECT * FROM classes WHERE id = ?', [id]));
    return NextResponse.json(cls);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to update class';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });
    await run('DELETE FROM classes WHERE id = ?', [id]);
    return NextResponse.json({ success: true });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to delete class';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
