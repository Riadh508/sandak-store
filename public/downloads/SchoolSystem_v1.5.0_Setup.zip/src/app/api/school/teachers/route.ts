import { NextRequest, NextResponse } from 'next/server';
import getDb, { getAll, getOne, run, dbRun, dbGet, dbAll, transaction, getLastInsertId } from '@/lib/schoolDb';

// GET /api/school/teachers?search=&id=
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const id = searchParams.get('id') || '';

    if (id) {
      const teacher = await getOne<any>('SELECT * FROM teachers WHERE id = ?', [id]);
      if (!teacher) {
        return NextResponse.json({ error: 'المعلم غير موجود' }, { status: 404 });
      }
      const assignedGrades = await getAll<{ grade: string }>('SELECT grade FROM teacher_grades WHERE teacher_id = ?', [id]);
      return NextResponse.json({ ...teacher, assignedGrades: assignedGrades.map(g => g.grade) });
    }

    let query = 'SELECT * FROM teachers WHERE 1=1';
    const params: unknown[] = [];

    if (search) {
      query += ' AND name LIKE ?';
      params.push(`%${search}%`);
    }

    query += ' ORDER BY name';

    const teachers = await getAll(query, params);
    return NextResponse.json(teachers);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

// POST /api/school/teachers
export async function POST(request: NextRequest) {
  try {
    const data = await request.json();

    const { name, subject, phone, email, assignedGrades } = data;

    if (!name || !subject) {
      return NextResponse.json({ error: 'يرجى تعبئة جميع الحقول المطلوبة' }, { status: 400 });
    }

    const result = await transaction((database) => {
      dbRun(database,
        'INSERT INTO teachers (name, subject, phone, email) VALUES (?, ?, ?, ?)',
        [name, subject, phone || '', email || '']
      );

      const teacherId = getLastInsertId(database);

      if (assignedGrades && assignedGrades.length > 0) {
        for (const grade of assignedGrades) {
          dbRun(database, 'INSERT INTO teacher_grades (teacher_id, grade) VALUES (?, ?)', [teacherId, grade]);
        }
      }

      return dbGet(database, 'SELECT * FROM teachers WHERE id = ?', [teacherId]);
    });

    return NextResponse.json(result, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

// PUT /api/school/teachers
export async function PUT(request: NextRequest) {
  try {
    const data = await request.json();

    const { id, name, subject, phone, email, assignedGrades } = data;

    if (!id || !name || !subject) {
      return NextResponse.json({ error: 'يرجى تعبئة جميع الحقول المطلوبة' }, { status: 400 });
    }

    await transaction((database) => {
      dbRun(database,
        'UPDATE teachers SET name = ?, subject = ?, phone = ?, email = ? WHERE id = ?',
        [name, subject, phone || '', email || '', id]
      );

      // Update assigned grades
      dbRun(database, 'DELETE FROM teacher_grades WHERE teacher_id = ?', [id]);
      if (assignedGrades && assignedGrades.length > 0) {
        for (const grade of assignedGrades) {
          dbRun(database, 'INSERT INTO teacher_grades (teacher_id, grade) VALUES (?, ?)', [id, grade]);
        }
      }
    });

    const teacher = await getOne('SELECT * FROM teachers WHERE id = ?', [id]);
    return NextResponse.json(teacher);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

// DELETE /api/school/teachers?id=1
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'يرجى تحديد المعلم' }, { status: 400 });
    }

    await transaction((database) => {
      dbRun(database, 'DELETE FROM teacher_grades WHERE teacher_id = ?', [id]);
      dbRun(database, 'DELETE FROM teachers WHERE id = ?', [id]);
    });

    return NextResponse.json({ message: 'تم حذف المعلم بنجاح' });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
