import { NextRequest, NextResponse } from 'next/server';
import getDb, { getAll, transaction, dbRun, dbGet } from '@/lib/schoolDb';

// GET /api/school/attendance?date=&grade=&section=&studentId=
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const date = searchParams.get('date') || '';
    const grade = searchParams.get('grade') || '';
    const section = searchParams.get('section') || '';
    const studentId = searchParams.get('studentId') || '';

    if (studentId) {
      // Get attendance history for a specific student
      const startDate = searchParams.get('startDate') || '';
      const endDate = searchParams.get('endDate') || '';

      let query = 'SELECT a.*, s.name as student_name, s.grade, s.section FROM attendance a JOIN students s ON a.student_id = s.id WHERE a.student_id = ?';
      const params: unknown[] = [studentId];

      if (startDate) {
        query += ' AND a.date >= ?';
        params.push(startDate);
      }
      if (endDate) {
        query += ' AND a.date <= ?';
        params.push(endDate);
      }

      query += ' ORDER BY a.date DESC';

      const records = await getAll(query, params);
      return NextResponse.json(records);
    }

    if (date && grade) {
      // Get attendance for a specific date and grade
      let query = `
        SELECT s.id, s.name, s.grade, s.section,
          COALESCE(a.status, 'none') as status, COALESCE(a.notes, '') as notes, a.id as attendance_id
        FROM students s
        LEFT JOIN attendance a ON s.id = a.student_id AND a.date = ?
        WHERE s.grade = ?
      `;
      const params: unknown[] = [date, grade];

      if (section) {
        query += ' AND s.section = ?';
        params.push(section);
      }

      query += ' ORDER BY s.section, s.name';

      const students = await getAll(query, params);
      return NextResponse.json(students);
    }

    // Get all attendance records
    let query = 'SELECT a.*, s.name as student_name, s.grade, s.section FROM attendance a JOIN students s ON a.student_id = s.id WHERE 1=1';
    const params: unknown[] = [];

    if (date) {
      query += ' AND a.date = ?';
      params.push(date);
    }

    query += ' ORDER BY a.date DESC LIMIT 100';

    const records = await getAll(query, params);
    return NextResponse.json(records);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

// POST /api/school/attendance - Bulk save attendance
export async function POST(request: NextRequest) {
  try {
    const { date, records } = await request.json();

    if (!date || !records || !Array.isArray(records)) {
      return NextResponse.json({ error: 'بيانات غير صالحة' }, { status: 400 });
    }

    await transaction((database) => {
      for (const item of records) {
        if (item.status === 'none') {
          dbRun(database, 'DELETE FROM attendance WHERE student_id = ? AND date = ?', [item.student_id, date]);
        } else {
          dbRun(database,
            'INSERT INTO attendance (student_id, date, status, notes) VALUES (?, ?, ?, ?) ON CONFLICT(student_id, date) DO UPDATE SET status = excluded.status, notes = excluded.notes',
            [item.student_id, date, item.status, item.notes || '']
          );
        }
      }
    });

    return NextResponse.json({ message: 'تم حفظ الحضور بنجاح' });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
