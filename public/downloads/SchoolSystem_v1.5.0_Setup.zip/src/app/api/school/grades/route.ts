import { NextRequest, NextResponse } from 'next/server';
import getDb, { getAll, getOne, run, transaction, dbRun, dbGet, getLastInsertId } from '@/lib/schoolDb';

// GET /api/school/grades?subject=&grade=&studentId=&examType=
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const subject = searchParams.get('subject') || '';
    const grade = searchParams.get('grade') || '';
    const studentId = searchParams.get('studentId') || '';
    const examType = searchParams.get('examType') || '';

    if (studentId) {
      // Get grades for a specific student
      let query = 'SELECT g.*, s.name as student_name, s.grade, s.section FROM grades g JOIN students s ON g.student_id = s.id WHERE g.student_id = ?';
      const params: unknown[] = [studentId];

      if (subject) {
        query += ' AND g.subject = ?';
        params.push(subject);
      }

      query += ' ORDER BY g.subject, g.exam_type, g.date DESC';

      const grades = await getAll(query, params);
      return NextResponse.json(grades);
    }

    if (grade && subject) {
      // Get grades for a specific grade and subject
      const query = `
        SELECT s.id as student_id, s.name, s.grade, s.section,
          g.id as grade_id, g.mark, g.max_mark, g.exam_type, g.date
        FROM students s
        LEFT JOIN grades g ON s.id = g.student_id AND g.subject = ? AND g.exam_type = ?
        WHERE s.grade = ?
        ORDER BY s.section, s.name
      `;
      const grades = await getAll(query, [grade, examType || 'اختبار نهائي', grade]);
      return NextResponse.json(grades);
    }

    // Get all grades
    let query = 'SELECT g.*, s.name as student_name, s.grade, s.section FROM grades g JOIN students s ON g.student_id = s.id WHERE 1=1';
    const params: unknown[] = [];

    if (subject) {
      query += ' AND g.subject = ?';
      params.push(subject);
    }
    if (grade) {
      query += ' AND s.grade = ?';
      params.push(grade);
    }

    query += ' ORDER BY g.subject, s.name LIMIT 500';

    const grades = await getAll(query, params);
    return NextResponse.json(grades);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

// POST /api/school/grades - Bulk save grades
export async function POST(request: NextRequest) {
  try {
    const { subject, examType, records, date } = await request.json();

    if (!subject || !examType || !records || !Array.isArray(records)) {
      return NextResponse.json({ error: 'بيانات غير صالحة' }, { status: 400 });
    }

    await transaction((database) => {
      for (const item of records) {
        if (item.mark === null || item.mark === '' || item.mark === undefined) {
          if (item.grade_id) {
            dbRun(database, 'DELETE FROM grades WHERE id = ?', [item.grade_id]);
          }
        } else {
          if (item.grade_id) {
            dbRun(database, 'UPDATE grades SET mark = ?, max_mark = ?, date = ? WHERE id = ?',
              [Number(item.mark), Number(item.max_mark) || 100, date || new Date().toISOString().split('T')[0], item.grade_id]);
          } else {
            dbRun(database,
              'INSERT INTO grades (student_id, subject, exam_type, mark, max_mark, date) VALUES (?, ?, ?, ?, ?, ?)',
              [item.student_id, subject, examType, Number(item.mark), Number(item.max_mark) || 100, date || new Date().toISOString().split('T')[0]]);
          }
        }
      }
    });

    return NextResponse.json({ message: 'تم حفظ العلامات بنجاح' });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

// DELETE /api/school/grades?id=1
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'يرجى تحديد العلامة' }, { status: 400 });
    }

    await run('DELETE FROM grades WHERE id = ?', [id]);
    return NextResponse.json({ message: 'تم حذف العلامة بنجاح' });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
