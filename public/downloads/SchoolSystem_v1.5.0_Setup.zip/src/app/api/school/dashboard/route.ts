import { NextResponse } from 'next/server';
import getDb, { getOne, getAll } from '@/lib/schoolDb';

export async function GET() {
  try {
    const today = new Date().toISOString().split('T')[0];

    // Total students
    const totalStudents = ((await getOne<{ count: number }>('SELECT COUNT(*) as count FROM students'))?.count) || 0;

    // Total teachers
    const totalTeachers = ((await getOne<{ count: number }>('SELECT COUNT(*) as count FROM teachers'))?.count) || 0;

    // Total classes
    const totalClasses = ((await getOne<{ count: number }>('SELECT COUNT(DISTINCT grade || section) as count FROM students'))?.count) || 0;

    // Today's attendance
    const totalPresentToday = ((await getOne<{ count: number }>("SELECT COUNT(DISTINCT student_id) as count FROM attendance WHERE date = ? AND status = 'present'", [today]))?.count) || 0;
    const totalRecordedToday = ((await getOne<{ count: number }>('SELECT COUNT(DISTINCT student_id) as count FROM attendance WHERE date = ?', [today]))?.count) || 0;
    const attendanceRate = totalRecordedToday > 0 ? Math.round((totalPresentToday / totalRecordedToday) * 100) : 0;

    // Absent today
    const totalAbsentToday = ((await getOne<{ count: number }>("SELECT COUNT(DISTINCT student_id) as count FROM attendance WHERE date = ? AND status = 'absent'", [today]))?.count) || 0;
    const totalLateToday = ((await getOne<{ count: number }>("SELECT COUNT(DISTINCT student_id) as count FROM attendance WHERE date = ? AND status = 'late'", [today]))?.count) || 0;

    // Students per grade
    const studentsByGrade = await getAll<any>(`
      SELECT grade, section, COUNT(*) as count
      FROM students
      GROUP BY grade, section
      ORDER BY grade, section
    `);

    // Recent students (last 5)
    const recentStudents = await getAll<any>('SELECT * FROM students ORDER BY enrolled_at DESC LIMIT 5');

    // Grade averages by subject
    const subjectAverages = await getAll<any>(`
      SELECT subject, exam_type, AVG(mark) as avg_mark, MAX(mark) as max_mark, MIN(mark) as min_mark, COUNT(*) as count
      FROM grades
      GROUP BY subject, exam_type
      ORDER BY subject
    `);

    // Monthly attendance trend (last 7 days)
    const attendanceTrend = await getAll<any>(`
      SELECT date,
        SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present,
        SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent,
        SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late,
        COUNT(DISTINCT student_id) as total
      FROM attendance
      WHERE date >= date('now', '-7 days')
      GROUP BY date
      ORDER BY date
    `);

    return NextResponse.json({
      totalStudents,
      totalTeachers,
      totalClasses,
      attendanceRate,
      totalPresentToday,
      totalAbsentToday,
      totalLateToday,
      totalRecordedToday,
      studentsByGrade,
      recentStudents,
      subjectAverages,
      attendanceTrend,
      today,
    });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Dashboard error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
