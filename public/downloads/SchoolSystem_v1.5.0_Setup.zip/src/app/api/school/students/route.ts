import { NextRequest, NextResponse } from 'next/server';
import getDb, { getAll, getOne, run, dbRun, dbGet, transaction, getLastInsertId } from '@/lib/schoolDb';

// GET /api/school/students?search=&grade=&section=
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const grade = searchParams.get('grade') || '';
    const section = searchParams.get('section') || '';
    const id = searchParams.get('id') || '';

    if (id) {
      const student = await getOne<any>('SELECT * FROM students WHERE id = ?', [id]);
      if (!student) {
        return NextResponse.json({ error: 'الطالب غير موجود' }, { status: 404 });
      }
      return NextResponse.json(student);
    }

    let query = 'SELECT * FROM students WHERE 1=1';
    const params: unknown[] = [];

    if (search) {
      query += ' AND name LIKE ?';
      params.push(`%${search}%`);
    }
    if (grade) {
      query += ' AND grade = ?';
      params.push(grade);
    }
    if (section) {
      query += ' AND section = ?';
      params.push(section);
    }

    query += ' ORDER BY grade, section, name';

    const students = await getAll(query, params);
    return NextResponse.json(students);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

// POST /api/school/students
export async function POST(request: NextRequest) {
  try {
    const data = await request.json();

    const { name, grade, section, phone, guardian_name, guardian_phone } = data;

    if (!name || !grade || !section) {
      return NextResponse.json({ error: 'يرجى تعبئة جميع الحقول المطلوبة' }, { status: 400 });
    }

    const insertId = await run(
      'INSERT INTO students (name, grade, section, phone, guardian_name, guardian_phone) VALUES (?, ?, ?, ?, ?, ?)',
      [name, grade, section, phone || '', guardian_name || '', guardian_phone || '']
    );

    const student = await getOne('SELECT * FROM students WHERE id = ?', [insertId]);
    return NextResponse.json(student, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

// PUT /api/school/students
export async function PUT(request: NextRequest) {
  try {
    const data = await request.json();

    const { id, name, grade, section, phone, guardian_name, guardian_phone } = data;

    if (!id || !name || !grade || !section) {
      return NextResponse.json({ error: 'يرجى تعبئة جميع الحقول المطلوبة' }, { status: 400 });
    }

    await run(
      'UPDATE students SET name = ?, grade = ?, section = ?, phone = ?, guardian_name = ?, guardian_phone = ? WHERE id = ?',
      [name, grade, section, phone || '', guardian_name || '', guardian_phone || '', id]
    );

    const student = await getOne('SELECT * FROM students WHERE id = ?', [id]);
    return NextResponse.json(student);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

// DELETE /api/school/students?id=1
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'يرجى تحديد الطالب' }, { status: 400 });
    }

    await run('DELETE FROM students WHERE id = ?', [id]);
    return NextResponse.json({ message: 'تم حذف الطالب بنجاح' });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
