import { NextRequest, NextResponse } from 'next/server';
import { getAll, run } from '@/lib/db';

export async function POST(req: NextRequest) {
  const body = await req.json();
  const records = [];
  for (const item of body.records) {
    const insertId = await run(
      'INSERT INTO attendance (student_id, date, status, notes) VALUES (?, ?, ?, ?)',
      [item.studentId, item.date, item.status, item.notes || '']
    );
    const record = await import('@/lib/db').then(m => m.getOne('SELECT * FROM attendance WHERE id = ?', [insertId]));
    records.push(record);
  }
  return NextResponse.json(records);
}

export async function GET() {
  const attendance = await getAll('SELECT * FROM attendance ORDER BY id DESC');
  return NextResponse.json(attendance);
}
