import { NextResponse } from 'next/server';
import { getAll, run } from '@/lib/db';

export async function GET() {
  try {
    const teachers = await getAll('SELECT * FROM teachers ORDER BY name ASC');
    return NextResponse.json(teachers);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch teachers' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const insertId = await run('INSERT INTO teachers (name, subject, phone, email) VALUES (?, ?, ?, ?)', [body.name, body.subject, body.phone || '', body.email || '']);
    const teacher = await import('@/lib/db').then(m => m.getOne('SELECT * FROM teachers WHERE id = ?', [insertId]));
    return NextResponse.json(teacher, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to create teacher';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, ...data } = body;
    await run('UPDATE teachers SET name = ?, subject = ?, phone = ?, email = ? WHERE id = ?', [data.name, data.subject, data.phone || '', data.email || '', id]);
    const teacher = await import('@/lib/db').then(m => m.getOne('SELECT * FROM teachers WHERE id = ?', [id]));
    return NextResponse.json(teacher);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to update teacher';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });
    await run('DELETE FROM teachers WHERE id = ?', [id]);
    return NextResponse.json({ success: true });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to delete teacher';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
