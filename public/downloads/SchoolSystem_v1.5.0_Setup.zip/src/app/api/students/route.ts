import { NextRequest, NextResponse } from 'next/server';
import { getAll, run } from '@/lib/db';

export async function GET() {
  const students = await getAll('SELECT * FROM students ORDER BY id DESC');
  return NextResponse.json(students);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const insertId = await run(
    'INSERT INTO students (name, grade, section, phone, guardian_name) VALUES (?, ?, ?, ?, ?)',
    [body.name, body.grade, body.section, body.phone || '', body.guardian || '']
  );
  const student = await import('@/lib/db').then(m => m.getOne('SELECT * FROM students WHERE id = ?', [insertId]));
  return NextResponse.json(student);
}

export async function PUT(req: NextRequest) {
  const body = await req.json();
  await run(
    'UPDATE students SET name = ?, grade = ?, section = ?, phone = ?, guardian_name = ? WHERE id = ?',
    [body.name, body.grade, body.section, body.phone || '', body.guardian || '', body.id]
  );
  const student = await import('@/lib/db').then(m => m.getOne('SELECT * FROM students WHERE id = ?', [body.id]));
  return NextResponse.json(student);
}

export async function DELETE(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const id = parseInt(searchParams.get('id') || '0');
  await run('DELETE FROM students WHERE id = ?', [id]);
  return NextResponse.json({ success: true });
}
