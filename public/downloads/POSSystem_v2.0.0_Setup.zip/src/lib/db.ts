import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'data', 'pos.db');
const DIR = path.dirname(DB_PATH);

let db: Database | null = null;

const CREATE_TABLES_SQL = `
  CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    created_at TEXT DEFAULT (datetime('now','localtime'))
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL NOT NULL DEFAULT 0,
    cost REAL NOT NULL DEFAULT 0,
    stock INTEGER NOT NULL DEFAULT 0,
    category_id INTEGER,
    barcode TEXT UNIQUE,
    created_at TEXT DEFAULT (datetime('now','localtime')),
    FOREIGN KEY (category_id) REFERENCES categories(id)
  );

  CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    total REAL NOT NULL DEFAULT 0,
    discount REAL NOT NULL DEFAULT 0,
    discount_type TEXT DEFAULT 'percentage',
    tax_rate REAL NOT NULL DEFAULT 0.15,
    tax REAL NOT NULL DEFAULT 0,
    net_total REAL NOT NULL DEFAULT 0,
    payment_method TEXT DEFAULT 'cash',
    items_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now','localtime'))
  );

  CREATE TABLE IF NOT EXISTS sale_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sale_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    product_name TEXT NOT NULL,
    price REAL NOT NULL,
    cost REAL NOT NULL DEFAULT 0,
    qty INTEGER NOT NULL DEFAULT 1,
    total REAL NOT NULL,
    FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
  );

  CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
  CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
  CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(created_at);
  CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id);
`;

const SEED_CATEGORIES = [
  'مشروبات',
  'مواد غذائية',
  'حلويات',
  'منظفات',
  'عناية شخصية',
  'أدوات مكتبية',
  'إلكترونيات',
  'ملابس',
  'أدوات منزلية',
  'أخرى',
];

const SEED_PRODUCTS = [
  ['ماء معدني 500مل', 1.5, 0.8, 200, 1, '6281001000011'],
  ['بيبسي 330مل', 3.5, 2.5, 150, 1, '6281001000022'],
  ['كولا 330مل', 3.5, 2.5, 150, 1, '6281001000033'],
  ['عصير برتقال 1ل', 6.0, 4.0, 80, 1, '6281001000044'],
  ['شاي أخضر 20كيس', 8.0, 5.5, 60, 1, '6281001000055'],
  ['حليب طازج 1ل', 5.5, 3.8, 50, 1, '6281001000066'],
  ['أرز بسمتي 5كج', 25.0, 18.0, 40, 2, '6281001000077'],
  ['سكر أبيض 1كج', 4.5, 3.2, 100, 2, '6281001000088'],
  ['زيت ذرة 1.5ل', 12.0, 8.5, 60, 2, '6281001000099'],
  ['معجون طماطم 400ج', 2.5, 1.5, 120, 2, '6281001000100'],
  ['شوكولاتة جالكسي', 7.0, 4.5, 90, 3, '6281001000111'],
  ['بسكويت أوريو', 5.0, 3.0, 100, 3, '6281001000122'],
  ['كيك شوكولاتة', 3.5, 2.0, 80, 3, '6281001000133'],
  ['وافل 6قطع', 4.0, 2.5, 70, 3, '6281001000144'],
  ['مثلجات فانيلا', 2.0, 1.0, 150, 3, '6281001000155'],
  ['صابون غسيل 1كج', 9.0, 6.0, 50, 4, '6281001000166'],
  ['منظف أرضيات 1ل', 7.5, 5.0, 40, 4, '6281001000177'],
  ['صابون يد ليكوييد', 4.5, 2.8, 60, 4, '6281001000188'],
  ['شامبو 400مل', 15.0, 9.0, 35, 5, '6281001000199'],
  ['معجون أسنان 120مل', 8.0, 4.5, 45, 5, '6281001000200'],
  ['أقلام حبر 10قطع', 12.0, 7.0, 30, 6, '6281001000211'],
  ['دفتر ملاحظات', 3.0, 1.5, 100, 6, '6281001000222'],
  ['سماعات بلوتوث', 45.0, 25.0, 15, 7, '6281001000233'],
  ['شاحن USB-C', 18.0, 8.0, 25, 7, '6281001000244'],
  ['تيشيرت قطني', 35.0, 18.0, 20, 8, '6281001000255'],
  ['أكواب ورقية 50قطعة', 8.0, 4.5, 40, 9, '6281001000266'],
];

export async function getDb(): Promise<Database> {
  if (!db) {
    if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });

    const SQL = await initSqlJs();

    if (fs.existsSync(DB_PATH)) {
      const buf = fs.readFileSync(DB_PATH);
      db = new SQL.Database(buf);
    } else {
      db = new SQL.Database();
      db.run(CREATE_TABLES_SQL);

      // Seed categories
      const catCount = dbGetHelper(db, 'SELECT COUNT(*) as count FROM categories') as { count: number } | null;
      if (!catCount || catCount.count === 0) {
        for (const cat of SEED_CATEGORIES) {
          db.run('INSERT INTO categories (name) VALUES (?)', [cat]);
        }
      }

      // Seed products
      const prodCount = dbGetHelper(db, 'SELECT COUNT(*) as count FROM products') as { count: number } | null;
      if (!prodCount || prodCount.count === 0) {
        for (const p of SEED_PRODUCTS) {
          db.run('INSERT INTO products (name, price, cost, stock, category_id, barcode) VALUES (?, ?, ?, ?, ?, ?)', p);
        }
      }

      saveDb();
    }
  }
  return db;
}

function dbGetHelper(database: Database, sql: string, params?: unknown[]): Record<string, unknown> | null {
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  let result: Record<string, unknown> | null = null;
  if (stmt.step()) {
    result = stmt.getAsObject();
  }
  stmt.free();
  return result;
}

export function saveDb(): void {
  if (!db) return;
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

export async function getAll<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T[]> {
  const database = await getDb();
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  const results: T[] = [];
  while (stmt.step()) {
    results.push(stmt.getAsObject() as T);
  }
  stmt.free();
  return results;
}

export async function getOne<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T | null> {
  const database = await getDb();
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  let result: T | null = null;
  if (stmt.step()) {
    result = stmt.getAsObject() as T;
  }
  stmt.free();
  return result;
}

export async function run(sql: string, params?: unknown[]): Promise<number> {
  const database = await getDb();
  database.run(sql, params);
  saveDb();
  const res = database.exec('SELECT last_insert_rowid()');
  return res.length > 0 && res[0].values.length > 0 ? Number(res[0].values[0][0]) : 0;
}

export function getLastInsertId(database: Database): number {
  const res = database.exec('SELECT last_insert_rowid()');
  return res.length > 0 && res[0].values.length > 0 ? Number(res[0].values[0][0]) : 0;
}

export function dbRun(database: Database, sql: string, params?: unknown[]): void {
  database.run(sql, params);
}

export function dbAll<T = Record<string, unknown>>(database: Database, sql: string, params?: unknown[]): T[] {
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  const results: T[] = [];
  while (stmt.step()) {
    results.push(stmt.getAsObject() as T);
  }
  stmt.free();
  return results;
}

export function dbGet<T = Record<string, unknown>>(database: Database, sql: string, params?: unknown[]): T | null {
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  let result: T | null = null;
  if (stmt.step()) {
    result = stmt.getAsObject() as T;
  }
  stmt.free();
  return result;
}

export async function transaction<T>(fn: (database: Database) => T): Promise<T> {
  const database = await getDb();
  try {
    database.run('BEGIN');
    const result = fn(database);
    database.run('COMMIT');
    saveDb();
    return result;
  } catch (error) {
    database.run('ROLLBACK');
    throw error;
  }
}
