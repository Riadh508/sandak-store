import { NextRequest, NextResponse } from 'next/server';
import { getAll, getOne, run } from '@/lib/db';

export async function GET() {
  try {
    const categories = await getAll('SELECT * FROM categories ORDER BY id ASC');
    return NextResponse.json(categories);
  } catch (error) {
    console.error('Error fetching categories:', error);
    return NextResponse.json({ error: 'فشل في جلب الفئات' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name } = await request.json();

    if (!name || !name.trim()) {
      return NextResponse.json({ error: 'اسم الفئة مطلوب' }, { status: 400 });
    }

    const existing = await getOne<{ id: number }>('SELECT id FROM categories WHERE name = ?', [name.trim()]);
    if (existing) {
      return NextResponse.json({ error: 'هذه الفئة موجودة بالفعل' }, { status: 409 });
    }

    const insertId = await run('INSERT INTO categories (name) VALUES (?)', [name.trim()]);
    const category = await getOne('SELECT * FROM categories WHERE id = ?', [insertId]);

    return NextResponse.json(category, { status: 201 });
  } catch (error) {
    console.error('Error creating category:', error);
    return NextResponse.json({ error: 'فشل في إنشاء الفئة' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { id, name } = await request.json();

    if (!id || !name || !name.trim()) {
      return NextResponse.json({ error: 'بيانات غير صالحة' }, { status: 400 });
    }

    const existing = await getOne<{ id: number }>('SELECT id FROM categories WHERE name = ? AND id != ?', [name.trim(), id]);
    if (existing) {
      return NextResponse.json({ error: 'هذه الفئة موجودة بالفعل' }, { status: 409 });
    }

    await run('UPDATE categories SET name = ? WHERE id = ?', [name.trim(), id]);
    const category = await getOne('SELECT * FROM categories WHERE id = ?', [id]);

    return NextResponse.json(category);
  } catch (error) {
    console.error('Error updating category:', error);
    return NextResponse.json({ error: 'فشل في تحديث الفئة' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'معرف الفئة مطلوب' }, { status: 400 });
    }

    // Check if category has products
    const products = await getOne<{ count: number }>('SELECT COUNT(*) as count FROM products WHERE category_id = ?', [id]);
    if (products && products.count > 0) {
      return NextResponse.json({ error: 'لا يمكن حذف فئة تحتوي على منتجات' }, { status: 400 });
    }

    await run('DELETE FROM categories WHERE id = ?', [id]);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting category:', error);
    return NextResponse.json({ error: 'فشل في حذف الفئة' }, { status: 500 });
  }
}
