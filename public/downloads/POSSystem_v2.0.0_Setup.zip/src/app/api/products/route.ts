import { NextRequest, NextResponse } from 'next/server';
import { getAll, getOne, run } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const categoryId = searchParams.get('category_id');
    const search = searchParams.get('search');
    const lowStock = searchParams.get('low_stock');

    let query = `
      SELECT p.*, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE 1=1
    `;
    const params: (string | number)[] = [];

    if (categoryId && categoryId !== 'all') {
      query += ' AND p.category_id = ?';
      params.push(Number(categoryId));
    }

    if (search) {
      query += ' AND (p.name LIKE ? OR p.barcode LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    if (lowStock === 'true') {
      query += ' AND p.stock <= 10';
    }

    query += ' ORDER BY p.name ASC';

    const products = await getAll(query, params);
    return NextResponse.json(products);
  } catch (error) {
    console.error('Error fetching products:', error);
    return NextResponse.json({ error: 'فشل في جلب المنتجات' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name, price, cost, stock, category_id, barcode } = await request.json();

    if (!name || !name.trim() || price === undefined) {
      return NextResponse.json({ error: 'الاسم والسعر مطلوبان' }, { status: 400 });
    }

    if (barcode) {
      const existing = await getOne<{ id: number }>('SELECT id FROM products WHERE barcode = ?', [barcode]);
      if (existing) {
        return NextResponse.json({ error: 'الباركود موجود بالفعل' }, { status: 409 });
      }
    }

    const insertId = await run(
      `INSERT INTO products (name, price, cost, stock, category_id, barcode)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        name.trim(),
        Number(price),
        Number(cost) || 0,
        Number(stock) || 0,
        category_id ? Number(category_id) : null,
        barcode?.trim() || null
      ]
    );

    const product = await getOne(`
      SELECT p.*, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.id = ?
    `, [insertId]);

    return NextResponse.json(product, { status: 201 });
  } catch (error) {
    console.error('Error creating product:', error);
    return NextResponse.json({ error: 'فشل في إنشاء المنتج' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { id, name, price, cost, stock, category_id, barcode } = await request.json();

    if (!id || !name || !name.trim() || price === undefined) {
      return NextResponse.json({ error: 'بيانات غير صالحة' }, { status: 400 });
    }

    if (barcode) {
      const existing = await getOne<{ id: number }>('SELECT id FROM products WHERE barcode = ? AND id != ?', [barcode.trim(), id]);
      if (existing) {
        return NextResponse.json({ error: 'الباركود موجود بالفعل' }, { status: 409 });
      }
    }

    await run(
      `UPDATE products SET name = ?, price = ?, cost = ?, stock = ?, category_id = ?, barcode = ?
       WHERE id = ?`,
      [
        name.trim(),
        Number(price),
        Number(cost) || 0,
        Number(stock) || 0,
        category_id ? Number(category_id) : null,
        barcode?.trim() || null,
        id
      ]
    );

    const product = await getOne(`
      SELECT p.*, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.id = ?
    `, [id]);

    return NextResponse.json(product);
  } catch (error) {
    console.error('Error updating product:', error);
    return NextResponse.json({ error: 'فشل في تحديث المنتج' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'معرف المنتج مطلوب' }, { status: 400 });
    }

    await run('DELETE FROM products WHERE id = ?', [id]);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting product:', error);
    return NextResponse.json({ error: 'فشل في حذف المنتج' }, { status: 500 });
  }
}
