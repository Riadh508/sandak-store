import { NextRequest, NextResponse } from 'next/server';
import { getAll, getOne, transaction, dbRun, dbGet, dbAll, getLastInsertId } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const from = searchParams.get('from');
    const to = searchParams.get('to');
    const limit = Number(searchParams.get('limit')) || 100;

    let query = 'SELECT * FROM sales WHERE 1=1';
    const params: string[] = [];

    if (from) {
      query += ' AND created_at >= ?';
      params.push(from);
    }
    if (to) {
      query += ' AND created_at <= ?';
      params.push(to);
    }

    query += ' ORDER BY created_at DESC LIMIT ?';
    params.push(String(limit));

    const sales = await getAll(query, params);

    // Get items for each sale
    const salesWithItems = await Promise.all(sales.map(async (sale) => {
      const saleId = (sale as Record<string, unknown>).id;
      const items = await getAll('SELECT * FROM sale_items WHERE sale_id = ?', [saleId]);
      return {
        ...(sale as Record<string, unknown>),
        items,
      };
    }));

    return NextResponse.json(salesWithItems);
  } catch (error) {
    console.error('Error fetching sales:', error);
    return NextResponse.json({ error: 'فشل في جلب المبيعات' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { items, discount, discount_type, tax_rate, payment_method } = await request.json();

    if (!items || items.length === 0) {
      return NextResponse.json({ error: 'السلة فارغة' }, { status: 400 });
    }

    const subtotal = items.reduce((sum: number, item: { price: number; qty: number }) => sum + (item.price * item.qty), 0);

    let discountAmount = 0;
    if (discount) {
      discountAmount = discount_type === 'percentage'
        ? subtotal * (Number(discount) / 100)
        : Number(discount);
      discountAmount = Math.min(discountAmount, subtotal);
    }

    const afterDiscount = subtotal - discountAmount;
    const taxAmount = afterDiscount * (Number(tax_rate) || 0.15);
    const netTotal = afterDiscount + taxAmount;

    const result = await transaction((database) => {
      // Insert sale
      dbRun(database, `
        INSERT INTO sales (total, discount, discount_type, tax_rate, tax, net_total, payment_method, items_count)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        subtotal,
        discountAmount,
        discount_type || 'percentage',
        Number(tax_rate) || 0.15,
        taxAmount,
        netTotal,
        payment_method || 'cash',
        items.length
      ]);

      const saleId = getLastInsertId(database);

      // Insert sale items and update stock
      for (const item of items) {
        dbRun(database, `
          INSERT INTO sale_items (sale_id, product_id, product_name, price, cost, qty, total)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [
          saleId,
          item.product_id,
          item.product_name,
          item.price,
          item.cost || 0,
          item.qty,
          item.price * item.qty
        ]);
        dbRun(database, 'UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?', [item.qty, item.product_id, item.qty]);
      }

      // Get complete sale with items
      const sale = dbGet<Record<string, unknown>>(database, 'SELECT * FROM sales WHERE id = ?', [saleId]);
      const saleItems = dbAll(database, 'SELECT * FROM sale_items WHERE sale_id = ?', [saleId]);

      return { ...sale, items: saleItems };
    });

    return NextResponse.json(result, { status: 201 });
  } catch (error) {
    console.error('Error creating sale:', error);
    return NextResponse.json({ error: 'فشل في إتمام العملية' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'معرف العملية مطلوب' }, { status: 400 });
    }

    await transaction((database) => {
      // Get sale items to restore stock
      const saleItems = dbAll<{ product_id: number; qty: number }>(database, 'SELECT * FROM sale_items WHERE sale_id = ?', [id]);

      // Restore stock for each item
      for (const item of saleItems) {
        dbRun(database, 'UPDATE products SET stock = stock + ? WHERE id = ?', [item.qty, item.product_id]);
      }

      // Delete sale items first (due to foreign key)
      dbRun(database, 'DELETE FROM sale_items WHERE sale_id = ?', [id]);
      // Delete sale
      dbRun(database, 'DELETE FROM sales WHERE id = ?', [id]);
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error refunding sale:', error);
    return NextResponse.json({ error: 'فشل في إلغاء العملية' }, { status: 500 });
  }
}
