import { NextResponse } from 'next/server';
import { getOne, getAll } from '@/lib/db';

export async function GET() {
  try {
    // Today's stats
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayStr = todayStart.toISOString().slice(0, 19).replace('T', ' ');

    const todaySales = (await getOne<{ total: number; items: number; count: number }>(
      'SELECT COALESCE(SUM(net_total), 0) as total, COALESCE(SUM(items_count), 0) as items, COUNT(*) as count FROM sales WHERE created_at >= ?',
      [todayStr]
    )) || { total: 0, items: 0, count: 0 };

    const todayTax = (await getOne<{ total: number }>(
      'SELECT COALESCE(SUM(tax), 0) as total FROM sales WHERE created_at >= ?',
      [todayStr]
    )) || { total: 0 };

    const todayRefunds = (await getOne<{ total: number }>(
      'SELECT COALESCE(SUM(discount), 0) as total FROM sales WHERE created_at >= ?',
      [todayStr]
    )) || { total: 0 };

    // This week stats
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    weekStart.setHours(0, 0, 0, 0);
    const weekStr = weekStart.toISOString().slice(0, 19).replace('T', ' ');

    const weekSales = (await getOne<{ total: number }>(
      'SELECT COALESCE(SUM(net_total), 0) as total FROM sales WHERE created_at >= ?',
      [weekStr]
    )) || { total: 0 };

    // This month stats
    const monthStart = new Date();
    monthStart.setDate(1);
    monthStart.setHours(0, 0, 0, 0);
    const monthStr = monthStart.toISOString().slice(0, 19).replace('T', ' ');

    const monthSales = (await getOne<{ total: number }>(
      'SELECT COALESCE(SUM(net_total), 0) as total FROM sales WHERE created_at >= ?',
      [monthStr]
    )) || { total: 0 };

    // Top selling products
    const topProducts = await getAll<{ product_name: string; total_qty: number; total_revenue: number }>(`
      SELECT si.product_name, SUM(si.qty) as total_qty, SUM(si.total) as total_revenue
      FROM sale_items si
      JOIN sales s ON si.sale_id = s.id
      WHERE s.created_at >= ?
      GROUP BY si.product_id, si.product_name
      ORDER BY total_qty DESC
      LIMIT 10
    `, [todayStr]);

    // Low stock products
    const lowStock = await getAll<Record<string, unknown>>(`
      SELECT p.*, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.stock <= 10
      ORDER BY p.stock ASC
      LIMIT 10
    `);

    // Revenue by day (last 7 days)
    const last7Days = await getAll<{ date: string; total: number; count: number }>(`
      SELECT DATE(created_at) as date, SUM(net_total) as total, COUNT(*) as count
      FROM sales
      WHERE created_at >= datetime('now', '-7 days', 'localtime')
      GROUP BY DATE(created_at)
      ORDER BY date ASC
    `);

    // Payment method breakdown today
    const paymentBreakdown = await getAll<{ payment_method: string; count: number; total: number }>(`
      SELECT payment_method, COUNT(*) as count, SUM(net_total) as total
      FROM sales
      WHERE created_at >= ?
      GROUP BY payment_method
    `, [todayStr]);

    // Total products and categories
    const productStats = (await getOne<{ total: number }>(
      'SELECT COUNT(*) as total FROM products'
    )) || { total: 0 };

    const categoryStats = (await getOne<{ total: number }>(
      'SELECT COUNT(*) as total FROM categories'
    )) || { total: 0 };

    return NextResponse.json({
      today: {
        revenue: todaySales.total,
        sales: todaySales.count,
        items: todaySales.items,
        tax: todayTax.total,
        discounts: todayRefunds.total,
      },
      week: { revenue: weekSales.total },
      month: { revenue: monthSales.total },
      topProducts,
      lowStock,
      revenueByDay: last7Days,
      paymentBreakdown,
      totalProducts: productStats.total,
      totalCategories: categoryStats.total,
    });
  } catch (error) {
    console.error('Error fetching dashboard:', error);
    return NextResponse.json({ error: 'فشل في جلب بيانات لوحة التحكم' }, { status: 500 });
  }
}
