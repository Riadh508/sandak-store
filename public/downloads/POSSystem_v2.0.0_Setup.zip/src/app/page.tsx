'use client';

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  ShoppingCart,
  Package,
  BarChart3,
  CreditCard,
  Search,
  Plus,
  Minus,
  Trash2,
  Edit3,
  Save,
  X,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  Receipt,
  Printer,
  RefreshCw,
  Download,
  Upload,
  ChevronDown,
  Store,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Hash,
  Tag,
  Layers,
  Banknote,
  Percent,
  XCircle,
  CheckCircle,
  Eye,
  Undo2,
} from 'lucide-react';

// ===== Types =====
interface Category {
  id: number;
  name: string;
  created_at?: string;
}

interface Product {
  id: number;
  name: string;
  price: number;
  cost: number;
  stock: number;
  category_id: number | null;
  category_name?: string;
  barcode: string | null;
  created_at?: string;
}

interface CartItem {
  product_id: number;
  product_name: string;
  price: number;
  cost: number;
  qty: number;
}

interface SaleItem {
  id: number;
  sale_id: number;
  product_id: number;
  product_name: string;
  price: number;
  cost: number;
  qty: number;
  total: number;
}

interface Sale {
  id: number;
  total: number;
  discount: number;
  discount_type: string;
  tax_rate: number;
  tax: number;
  net_total: number;
  payment_method: string;
  items_count: number;
  created_at: string;
  items?: SaleItem[];
}

interface DashboardData {
  today: { revenue: number; sales: number; items: number; tax: number; discounts: number };
  week: { revenue: number };
  month: { revenue: number };
  topProducts: Array<{ product_name: string; total_qty: number; total_revenue: number }>;
  lowStock: Product[];
  revenueByDay: Array<{ date: string; total: number; count: number }>;
  paymentBreakdown: Array<{ payment_method: string; count: number; total: number }>;
  totalProducts: number;
  totalCategories: number;
}

type TabId = 'pos' | 'products' | 'sales' | 'dashboard';

// ===== Helpers =====
function formatCurrency(amount: number): string {
  return amount.toFixed(2) + ' ر.س';
}

function formatDate(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateStr;
  }
}

function getDayName(dateStr: string): string {
  const days = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const d = new Date(dateStr);
  return days[d.getDay()];
}

// ===== Main Component =====
export default function POSSystem() {
  const [activeTab, setActiveTab] = useState<TabId>('pos');

  // Data states
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);

  // POS states
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [discountValue, setDiscountValue] = useState('');
  const [discountType, setDiscountType] = useState<'percentage' | 'fixed'>('percentage');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card'>('cash');
  const [showReceipt, setShowReceipt] = useState<Sale | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  // Products tab states
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productForm, setProductForm] = useState({
    name: '',
    price: '',
    cost: '',
    stock: '',
    category_id: '',
    barcode: '',
  });
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [categoryName, setCategoryName] = useState('');
  const [productSearch, setProductSearch] = useState('');
  const [productCategoryFilter, setProductCategoryFilter] = useState('all');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<{ type: 'product' | 'category'; id: number; name: string } | null>(null);

  // Sales tab states
  const [saleDateFrom, setSaleDateFrom] = useState('');
  const [saleDateTo, setSaleDateTo] = useState('');
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);
  const [showRefundConfirm, setShowRefundConfirm] = useState<number | null>(null);

  // Toast state
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // ===== Data Fetching =====
  const fetchCategories = useCallback(async () => {
    try {
      const res = await fetch('/api/categories');
      if (res.ok) setCategories(await res.json());
    } catch (e) {
      console.error('Failed to fetch categories', e);
    }
  }, []);

  const fetchProducts = useCallback(async (search?: string, categoryId?: string) => {
    try {
      let url = '/api/products';
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (categoryId && categoryId !== 'all') params.set('category_id', categoryId);
      if (params.toString()) url += '?' + params.toString();
      const res = await fetch(url);
      if (res.ok) setProducts(await res.json());
    } catch (e) {
      console.error('Failed to fetch products', e);
    }
  }, []);

  const fetchSales = useCallback(async (from?: string, to?: string) => {
    try {
      let url = '/api/sales?limit=200';
      const params = new URLSearchParams();
      if (from) params.set('from', from);
      if (to) params.set('to', to);
      if (params.toString()) url += '?' + params.toString();
      const res = await fetch(url);
      if (res.ok) setSales(await res.json());
    } catch (e) {
      console.error('Failed to fetch sales', e);
    }
  }, []);

  const fetchDashboard = useCallback(async () => {
    try {
      const res = await fetch('/api/dashboard');
      if (res.ok) setDashboard(await res.json());
    } catch (e) {
      console.error('Failed to fetch dashboard', e);
    }
  }, []);

  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  useEffect(() => {
    if (activeTab === 'pos') {
      fetchProducts(searchQuery || undefined, selectedCategory);
    } else if (activeTab === 'products') {
      fetchProducts(productSearch || undefined, productCategoryFilter);
    } else if (activeTab === 'sales') {
      fetchSales(saleDateFrom || undefined, saleDateTo || undefined);
    } else if (activeTab === 'dashboard') {
      fetchDashboard();
    }
  }, [activeTab, fetchProducts, fetchSales, fetchDashboard, searchQuery, selectedCategory, productSearch, productCategoryFilter, saleDateFrom, saleDateTo]);

  // Auto focus search on POS tab
  useEffect(() => {
    if (activeTab === 'pos' && searchRef.current) {
      setTimeout(() => searchRef.current?.focus(), 100);
    }
  }, [activeTab, selectedCategory]);

  // ===== Toast =====
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // ===== POS Functions =====
  const addToCart = (product: Product) => {
    if (product.stock <= 0) {
      showToast('المنتج غير متوفر في المخزون', 'error');
      return;
    }
    setCart(prev => {
      const existing = prev.find(item => item.product_id === product.id);
      if (existing) {
        if (existing.qty >= product.stock) {
          showToast('لا يمكن إضافة أكثر من المخزون المتاح', 'error');
          return prev;
        }
        return prev.map(item =>
          item.product_id === product.id ? { ...item, qty: item.qty + 1 } : item
        );
      }
      return [...prev, {
        product_id: product.id,
        product_name: product.name,
        price: product.price,
        cost: product.cost,
        qty: 1,
      }];
    });
  };

  const updateCartQty = (productId: number, newQty: number) => {
    if (newQty <= 0) {
      setCart(prev => prev.filter(item => item.product_id !== productId));
      return;
    }
    const product = products.find(p => p.id === productId);
    if (product && newQty > product.stock) {
      showToast('لا يمكن إضافة أكثر من المخزون المتاح', 'error');
      return;
    }
    setCart(prev => prev.map(item =>
      item.product_id === productId ? { ...item, qty: newQty } : item
    ));
  };

  const removeFromCart = (productId: number) => {
    setCart(prev => prev.filter(item => item.product_id !== productId));
  };

  const clearCart = () => {
    setCart([]);
    setDiscountValue('');
  };

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const discountAmount = discountValue
    ? discountType === 'percentage'
      ? subtotal * (Number(discountValue) / 100)
      : Number(discountValue)
    : 0;
  const afterDiscount = Math.max(0, subtotal - Math.min(discountAmount, subtotal));
  const taxRate = 0.15;
  const taxAmount = afterDiscount * taxRate;
  const netTotal = afterDiscount + taxAmount;

  const completeSale = async () => {
    if (cart.length === 0) {
      showToast('السلة فارغة', 'error');
      return;
    }

    try {
      const res = await fetch('/api/sales', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cart,
          discount: discountValue || 0,
          discount_type: discountType,
          tax_rate: taxRate,
          payment_method: paymentMethod,
        }),
      });

      if (res.ok) {
        const sale = await res.json();
        setShowReceipt(sale);
        showToast('تمت العملية بنجاح!', 'success');
        setCart([]);
        setDiscountValue('');
        fetchProducts(searchQuery || undefined, selectedCategory);
      } else {
        const data = await res.json();
        showToast(data.error || 'فشل في إتمام العملية', 'error');
      }
    } catch {
      showToast('خطأ في الاتصال', 'error');
    }
  };

  const handleBarcodeScan = (barcode: string) => {
    const product = products.find(p => p.barcode === barcode.trim());
    if (product) {
      addToCart(product);
      setSearchQuery('');
    }
  };

  // ===== Products CRUD =====
  const openAddProduct = () => {
    setEditingProduct(null);
    setProductForm({ name: '', price: '', cost: '', stock: '', category_id: '', barcode: '' });
    setShowProductModal(true);
  };

  const openEditProduct = (product: Product) => {
    setEditingProduct(product);
    setProductForm({
      name: product.name,
      price: String(product.price),
      cost: String(product.cost),
      stock: String(product.stock),
      category_id: product.category_id ? String(product.category_id) : '',
      barcode: product.barcode || '',
    });
    setShowProductModal(true);
  };

  const saveProduct = async () => {
    if (!productForm.name.trim() || !productForm.price) {
      showToast('الاسم والسعر مطلوبان', 'error');
      return;
    }

    try {
      const url = editingProduct ? '/api/products' : '/api/products';
      const method = editingProduct ? 'PUT' : 'POST';
      const body = editingProduct
        ? { ...productForm, id: editingProduct.id }
        : productForm;

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      if (res.ok) {
        showToast(editingProduct ? 'تم تحديث المنتج' : 'تم إضافة المنتج', 'success');
        setShowProductModal(false);
        fetchProducts(productSearch || undefined, productCategoryFilter);
      } else {
        const data = await res.json();
        showToast(data.error || 'فشل في حفظ المنتج', 'error');
      }
    } catch {
      showToast('خطأ في الاتصال', 'error');
    }
  };

  const deleteProduct = async (id: number) => {
    try {
      const res = await fetch(`/api/products?id=${id}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('تم حذف المنتج', 'success');
        fetchProducts(productSearch || undefined, productCategoryFilter);
      } else {
        showToast('فشل في حذف المنتج', 'error');
      }
    } catch {
      showToast('خطأ في الاتصال', 'error');
    }
    setShowDeleteConfirm(null);
  };

  // ===== Categories CRUD =====
  const saveCategory = async () => {
    if (!categoryName.trim()) {
      showToast('اسم الفئة مطلوب', 'error');
      return;
    }

    try {
      const method = editingCategory ? 'PUT' : 'POST';
      const body = editingCategory ? { id: editingCategory.id, name: categoryName } : { name: categoryName };

      const res = await fetch('/api/categories', {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      if (res.ok) {
        showToast(editingCategory ? 'تم تحديث الفئة' : 'تم إضافة الفئة', 'success');
        setShowCategoryModal(false);
        setCategoryName('');
        setEditingCategory(null);
        fetchCategories();
      } else {
        const data = await res.json();
        showToast(data.error || 'فشل في حفظ الفئة', 'error');
      }
    } catch {
      showToast('خطأ في الاتصال', 'error');
    }
  };

  const deleteCategory = async (id: number) => {
    try {
      const res = await fetch(`/api/categories?id=${id}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('تم حذف الفئة', 'success');
        fetchCategories();
      } else {
        const data = await res.json();
        showToast(data.error || 'فشل في حذف الفئة', 'error');
      }
    } catch {
      showToast('خطأ في الاتصال', 'error');
    }
    setShowDeleteConfirm(null);
  };

  // ===== Refund =====
  const refundSale = async (id: number) => {
    try {
      const res = await fetch(`/api/sales?id=${id}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('تم إلغاء العملية واسترداد المخزون', 'success');
        fetchSales(saleDateFrom || undefined, saleDateTo || undefined);
      } else {
        const data = await res.json();
        showToast(data.error || 'فشل في إلغاء العملية', 'error');
      }
    } catch {
      showToast('خطأ في الاتصال', 'error');
    }
    setShowRefundConfirm(null);
    setSelectedSale(null);
  };

  // ===== Export/Import =====
  const exportProducts = () => {
    const csv = products.map(p =>
      `${p.id},"${p.name}",${p.price},${p.cost},${p.stock},${p.category_id || ''},${p.barcode || ''}`
    ).join('\n');
    const header = 'المعرف,الاسم,السعر,التكلفة,المخزون,فئة,الباركود\n';
    const blob = new Blob(['\ufeff' + header + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `products_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('تم تصدير المنتجات', 'success');
  };

  // ===== Print Receipt =====
  const printReceipt = (sale: Sale) => {
    const itemsHtml = (sale.items || []).map(item =>
      `<tr>
        <td style="text-align:right;border-bottom:1px dashed #ccc;padding:4px 0;">${item.product_name}</td>
        <td style="text-align:center;border-bottom:1px dashed #ccc;padding:4px 0;">${item.qty}</td>
        <td style="text-align:left;border-bottom:1px dashed #ccc;padding:4px 0;">${(item.total).toFixed(2)}</td>
      </tr>`
    ).join('');

    const html = `<!DOCTYPE html><html dir="rtl"><head><meta charset="UTF-8">
      <style>body{font-family:Arial,sans-serif;font-size:14px;max-width:300px;margin:0 auto;padding:10px;}
      table{width:100%;border-collapse:collapse;}h2{text-align:center;margin-bottom:5px;}
      .divider{border-top:2px dashed #333;margin:10px 0;}</style></head><body>
      <h2>🧾 إيصال بيع</h2>
      <p style="text-align:center;color:#666;">نظام نقطة البيع</p>
      <div class="divider"></div>
      <p><strong>رقم العملية:</strong> #${sale.id}</p>
      <p><strong>التاريخ:</strong> ${formatDate(sale.created_at)}</p>
      <p><strong>طريقة الدفع:</strong> ${sale.payment_method === 'cash' ? 'نقدي' : 'بطاقة'}</p>
      <div class="divider"></div>
      <table><thead><tr><th style="text-align:right;">المنتج</th><th>الكمية</th><th style="text-align:left;">المبلغ</th></tr></thead>
      <tbody>${itemsHtml}</tbody></table>
      <div class="divider"></div>
      <table><tbody>
      <tr><td style="text-align:right;">المجموع الفرعي</td><td style="text-align:left;">${sale.total.toFixed(2)}</td></tr>
      ${sale.discount > 0 ? `<tr><td style="text-align:right;">الخصم</td><td style="text-align:left;">-${sale.discount.toFixed(2)}</td></tr>` : ''}
      <tr><td style="text-align:right;">الضريبة (${(sale.tax_rate * 100).toFixed(0)}%)</td><td style="text-align:left;">${sale.tax.toFixed(2)}</td></tr>
      <tr><td style="text-align:right;font-weight:bold;font-size:16px;">الإجمالي</td><td style="text-align:left;font-weight:bold;font-size:16px;">${sale.net_total.toFixed(2)} ر.س</td></tr>
      </tbody></table>
      <div class="divider"></div>
      <p style="text-align:center;color:#666;">شكراً لزيارتكم 🙏</p>
      <script>window.onload=function(){window.print();}</script></body></html>`;

    const win = window.open('', '_blank');
    if (win) {
      win.document.write(html);
      win.document.close();
    }
  };

  // ===== Chart Drawing (simple bar chart for revenue) =====
  const drawRevenueChart = (data: Array<{ date: string; total: number }>) => {
    if (!data.length) return null;
    const maxVal = Math.max(...data.map(d => d.total), 1);
    const barHeight = 32;
    const maxBarWidth = 280;

    return data.map((d, i) => {
      const width = (d.total / maxVal) * maxBarWidth;
      const dayLabel = getDayName(d.date);
      const dateLabel = d.date.slice(5);
      return (
        <div key={d.date} className="flex items-center gap-3 mb-2" style={{ animationDelay: `${i * 50}ms` }}>
          <div className="w-20 text-xs text-gray-500 flex-shrink-0 text-left">
            <div>{dayLabel}</div>
            <div>{dateLabel}</div>
          </div>
          <div className="flex-1 bg-gray-100 rounded-full h-8 relative overflow-hidden">
            <div
              className="h-full bg-gradient-to-l from-primary-500 to-primary-600 rounded-full transition-all duration-700 ease-out flex items-center justify-end px-2"
              style={{ width: `${Math.max(width, 20)}px` }}
            >
              <span className="text-[11px] text-white font-bold">{formatCurrency(d.total)}</span>
            </div>
          </div>
        </div>
      );
    });
  };

  // ============================================
  // TABS CONFIG
  // ============================================
  const tabs: { id: TabId; label: string; icon: React.ReactNode }[] = [
    { id: 'pos', label: 'نقطة البيع', icon: <Store className="w-5 h-5" /> },
    { id: 'products', label: 'المنتجات', icon: <Package className="w-5 h-5" /> },
    { id: 'sales', label: 'المبيعات', icon: <Receipt className="w-5 h-5" /> },
    { id: 'dashboard', label: 'لوحة التحكم', icon: <BarChart3 className="w-5 h-5" /> },
  ];

  // ============================================
  // RENDER POS TAB
  // ============================================
  const renderPOS = () => (
    <div className="flex h-[calc(100vh-64px)]">
      {/* Products Panel */}
      <div className="flex-1 flex flex-col bg-gray-50 overflow-hidden">
        {/* Search & Filter */}
        <div className="p-4 bg-white border-b border-gray-200">
          <div className="flex gap-3 mb-3">
            <div className="flex-1 relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                ref={searchRef}
                type="text"
                placeholder="بحث بالاسم أو الباركود..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  // Barcode detection
                  if (e.target.value.length >= 13) {
                    handleBarcodeScan(e.target.value);
                  }
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && searchQuery.length >= 8) {
                    handleBarcodeScan(searchQuery);
                  }
                }}
                className="w-full pr-10 pl-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
            </div>
          </div>
          {/* Category Pills */}
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                selectedCategory === 'all'
                  ? 'bg-primary-600 text-white shadow-md'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              الكل
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(String(cat.id))}
                className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  selectedCategory === String(cat.id)
                    ? 'bg-primary-600 text-white shadow-md'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {products.map((product) => (
              <button
                key={product.id}
                onClick={() => addToCart(product)}
                disabled={product.stock <= 0}
                className={`relative bg-white rounded-xl p-4 text-right border-2 transition-all duration-200 hover:shadow-lg hover:-translate-y-1 active:scale-95 ${
                  product.stock <= 0
                    ? 'border-red-200 opacity-50 cursor-not-allowed'
                    : product.stock <= 5
                    ? 'border-yellow-300 hover:border-primary-400'
                    : 'border-gray-100 hover:border-primary-400'
                }`}
              >
                {product.stock <= 5 && product.stock > 0 && (
                  <span className="absolute top-2 left-2 w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
                )}
                <h3 className="font-bold text-gray-800 text-sm mb-2 line-clamp-2 min-h-[2.5rem] leading-5">
                  {product.name}
                </h3>
                <div className="flex items-end justify-between mt-auto">
                  <span className="text-primary-600 font-bold text-lg">{formatCurrency(product.price)}</span>
                  <span className={`text-xs ${product.stock <= 5 ? 'text-yellow-600 font-semibold' : 'text-gray-400'}`}>
                    {product.stock <= 0 ? 'نفذ' : `${product.stock} قطعة`}
                  </span>
                </div>
                {product.category_name && (
                  <span className="inline-block mt-2 px-2 py-0.5 bg-gray-100 text-gray-500 text-[10px] rounded-full">
                    {product.category_name}
                  </span>
                )}
              </button>
            ))}
          </div>
          {products.length === 0 && (
            <div className="flex flex-col items-center justify-center h-40 text-gray-400">
              <Package className="w-12 h-12 mb-3" />
              <p>لا توجد منتجات</p>
            </div>
          )}
        </div>
      </div>

      {/* Cart Panel */}
      <div className="w-[380px] bg-white border-r border-gray-200 flex flex-col shadow-xl">
        {/* Cart Header */}
        <div className="p-4 bg-gray-900 text-white">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5" />
              <h2 className="font-bold text-lg">سلة المشتريات</h2>
            </div>
            {cart.length > 0 && (
              <span className="bg-primary-500 text-white text-xs px-2 py-1 rounded-full font-bold">
                {cart.reduce((s, i) => s + i.qty, 0)} منتج
              </span>
            )}
          </div>
        </div>

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto p-4">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-300">
              <ShoppingCart className="w-16 h-16 mb-3" />
              <p className="text-sm">السلة فارغة</p>
              <p className="text-xs mt-1">اضغط على منتج لإضافته</p>
            </div>
          ) : (
            <div className="space-y-3">
              {cart.map((item) => (
                <div key={item.product_id} className="bg-gray-50 rounded-xl p-3 animate-fade-in">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-semibold text-sm text-gray-800 flex-1 mr-2">{item.product_name}</h4>
                    <button onClick={() => removeFromCart(item.product_id)} className="text-red-400 hover:text-red-600 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 bg-white rounded-lg border border-gray-200">
                      <button
                        onClick={() => updateCartQty(item.product_id, item.qty - 1)}
                        className="w-8 h-8 flex items-center justify-center text-gray-500 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-8 text-center font-bold text-sm">{item.qty}</span>
                      <button
                        onClick={() => updateCartQty(item.product_id, item.qty + 1)}
                        className="w-8 h-8 flex items-center justify-center text-gray-500 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <span className="font-bold text-primary-600">{formatCurrency(item.price * item.qty)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Cart Footer */}
        {cart.length > 0 && (
          <div className="border-t border-gray-200 p-4 space-y-3">
            {/* Discount */}
            <div className="flex gap-2">
              <select
                value={discountType}
                onChange={(e) => setDiscountType(e.target.value as 'percentage' | 'fixed')}
                className="bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm"
              >
                <option value="percentage">%</option>
                <option value="fixed">ثابت</option>
              </select>
              <input
                type="number"
                placeholder="خصم"
                value={discountValue}
                onChange={(e) => setDiscountValue(e.target.value)}
                className="flex-1 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
            </div>

            {/* Totals */}
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between text-gray-500">
                <span>المجموع الفرعي</span>
                <span>{formatCurrency(subtotal)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-red-500">
                  <span>الخصم</span>
                  <span>-{formatCurrency(discountAmount)}</span>
                </div>
              )}
              <div className="flex justify-between text-gray-500">
                <span>الضريبة (15%)</span>
                <span>{formatCurrency(taxAmount)}</span>
              </div>
              <div className="flex justify-between text-lg font-bold text-gray-900 pt-2 border-t border-gray-200">
                <span>الإجمالي</span>
                <span className="text-primary-600">{formatCurrency(netTotal)}</span>
              </div>
            </div>

            {/* Payment Method */}
            <div className="flex gap-2">
              <button
                onClick={() => setPaymentMethod('cash')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all ${
                  paymentMethod === 'cash'
                    ? 'bg-emerald-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Banknote className="w-4 h-4" />
                نقدي
              </button>
              <button
                onClick={() => setPaymentMethod('card')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all ${
                  paymentMethod === 'card'
                    ? 'bg-emerald-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <CreditCard className="w-4 h-4" />
                بطاقة
              </button>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              <button
                onClick={clearCart}
                className="px-4 py-3 bg-gray-100 text-gray-600 rounded-xl text-sm font-medium hover:bg-gray-200 transition-colors"
              >
                <Trash2 className="w-4 h-4 inline ml-1" />
                إفراغ
              </button>
              <button
                onClick={completeSale}
                className="flex-1 py-3 bg-primary-600 text-white rounded-xl text-sm font-bold hover:bg-primary-700 transition-all active:scale-95 animate-pulse-glow"
              >
                <CheckCircle className="w-4 h-4 inline ml-1" />
                إتمام البيع — {formatCurrency(netTotal)}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  // ============================================
  // RENDER PRODUCTS TAB
  // ============================================
  const renderProducts = () => (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">إدارة المنتجات</h1>
          <p className="text-sm text-gray-500 mt-1">إضافة وتعديل وحذف المنتجات والفئات</p>
        </div>
        <div className="flex gap-2">
          <button onClick={exportProducts} className="flex items-center gap-2 px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors">
            <Download className="w-4 h-4" />
            تصدير
          </button>
          <button onClick={() => { setEditingCategory(null); setCategoryName(''); setShowCategoryModal(true); }} className="flex items-center gap-2 px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors">
            <Layers className="w-4 h-4" />
            إضافة فئة
          </button>
          <button onClick={openAddProduct} className="flex items-center gap-2 px-4 py-2.5 bg-primary-600 text-white rounded-xl text-sm font-bold hover:bg-primary-700 transition-colors shadow-md">
            <Plus className="w-4 h-4" />
            إضافة منتج
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-4 mb-6 shadow-sm border border-gray-100">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="بحث بالاسم أو الباركود..."
              value={productSearch}
              onChange={(e) => setProductSearch(e.target.value)}
              className="w-full pr-10 pl-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          <select
            value={productCategoryFilter}
            onChange={(e) => setProductCategoryFilter(e.target.value)}
            className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
          >
            <option value="all">كل الفئات</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
          </select>
          <button
            onClick={() => fetchProducts(productSearch || undefined, productCategoryFilter)}
            className="flex items-center gap-2 px-4 py-2.5 bg-gray-100 text-gray-600 rounded-xl text-sm hover:bg-gray-200 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            تحديث
          </button>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">#</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">المنتج</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">الباركود</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">الفئة</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">السعر</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">التكلفة</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">المخزون</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product, i) => (
                <tr key={product.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-sm text-gray-400">{i + 1}</td>
                  <td className="px-4 py-3">
                    <span className="font-medium text-gray-800 text-sm">{product.name}</span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-500 font-mono">{product.barcode || '—'}</td>
                  <td className="px-4 py-3">
                    {product.category_name ? (
                      <span className="inline-block px-2 py-0.5 bg-primary-50 text-primary-700 text-xs rounded-full">{product.category_name}</span>
                    ) : (
                      <span className="text-gray-400 text-xs">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3 font-bold text-primary-600 text-sm">{formatCurrency(product.price)}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{formatCurrency(product.cost)}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold ${
                      product.stock <= 0 ? 'bg-red-100 text-red-700' :
                      product.stock <= 5 ? 'bg-yellow-100 text-yellow-700' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {product.stock <= 0 && <AlertTriangle className="w-3 h-3" />}
                      {product.stock}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => openEditProduct(product)} className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition-colors">
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button onClick={() => setShowDeleteConfirm({ type: 'product', id: product.id, name: product.name })} className="p-2 text-red-400 hover:bg-red-50 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {products.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-12 text-center text-gray-400">
                    <Package className="w-10 h-10 mx-auto mb-2" />
                    لا توجد منتجات
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 text-xs text-gray-500">
          إجمالي المنتجات: {products.length}
        </div>
      </div>
    </div>
  );

  // ============================================
  // RENDER SALES TAB
  // ============================================
  const renderSales = () => (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">سجل المبيعات</h1>
          <p className="text-sm text-gray-500 mt-1">عرض وإدارة جميع عمليات البيع</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => fetchSales(saleDateFrom || undefined, saleDateTo || undefined)}
            className="flex items-center gap-2 px-4 py-2.5 bg-gray-100 text-gray-600 rounded-xl text-sm hover:bg-gray-200 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            تحديث
          </button>
        </div>
      </div>

      {/* Date Filters */}
      <div className="bg-white rounded-2xl p-4 mb-6 shadow-sm border border-gray-100">
        <div className="flex flex-col sm:flex-row gap-3 items-end">
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">من تاريخ</label>
            <input
              type="date"
              value={saleDateFrom}
              onChange={(e) => setSaleDateFrom(e.target.value)}
              className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">إلى تاريخ</label>
            <input
              type="date"
              value={saleDateTo}
              onChange={(e) => setSaleDateTo(e.target.value)}
              className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          <div className="flex gap-2">
            <button onClick={() => { setSaleDateFrom(''); setSaleDateTo(''); }} className="px-4 py-2.5 bg-gray-100 text-gray-600 rounded-xl text-sm hover:bg-gray-200 transition-colors">
              عرض الكل
            </button>
            <button onClick={() => {
              const today = new Date().toISOString().slice(0, 10);
              setSaleDateFrom(today);
              setSaleDateTo(today);
            }} className="px-4 py-2.5 bg-primary-50 text-primary-700 rounded-xl text-sm font-medium hover:bg-primary-100 transition-colors">
              اليوم
            </button>
          </div>
        </div>
      </div>

      {/* Sales List */}
      <div className="space-y-3">
        {sales.map((sale) => (
          <div key={sale.id} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary-50 rounded-xl flex items-center justify-center">
                  <Receipt className="w-6 h-6 text-primary-600" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-gray-800">عملية #{sale.id}</span>
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                      sale.payment_method === 'cash' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                    }`}>
                      {sale.payment_method === 'cash' ? <Banknote className="w-3 h-3" /> : <CreditCard className="w-3 h-3" />}
                      {sale.payment_method === 'cash' ? 'نقدي' : 'بطاقة'}
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 mt-0.5">{formatDate(sale.created_at)}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-left">
                  <p className="text-xs text-gray-500">{sale.items_count} منتج</p>
                  <p className="font-bold text-lg text-primary-600">{formatCurrency(sale.net_total)}</p>
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => setSelectedSale(sale)}
                    className="p-2 text-gray-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                    title="التفاصيل"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => printReceipt(sale)}
                    className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    title="طباعة"
                  >
                    <Printer className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setShowRefundConfirm(sale.id)}
                    className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    title="إلغاء واسترداد"
                  >
                    <Undo2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {sales.length === 0 && (
          <div className="bg-white rounded-2xl p-12 shadow-sm text-center text-gray-400">
            <Receipt className="w-12 h-12 mx-auto mb-3" />
            <p>لا توجد مبيعات</p>
          </div>
        )}
      </div>

      {/* Sales Summary */}
      {sales.length > 0 && (
        <div className="mt-6 bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-700 mb-3">ملخص</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="text-center">
              <p className="text-xs text-gray-500">عدد العمليات</p>
              <p className="font-bold text-lg text-gray-800">{sales.length}</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-500">إجمالي المبيعات</p>
              <p className="font-bold text-lg text-primary-600">{formatCurrency(sales.reduce((s, sale) => s + sale.net_total, 0))}</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-500">إجمالي الضريبة</p>
              <p className="font-bold text-lg text-gray-800">{formatCurrency(sales.reduce((s, sale) => s + sale.tax, 0))}</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-500">إجمالي الخصومات</p>
              <p className="font-bold text-lg text-red-500">{formatCurrency(sales.reduce((s, sale) => s + sale.discount, 0))}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  // ============================================
  // RENDER DASHBOARD TAB
  // ============================================
  const renderDashboard = () => {
    if (!dashboard) {
      return (
        <div className="flex items-center justify-center h-[60vh]">
          <div className="text-gray-400">
            <RefreshCw className="w-8 h-8 mx-auto mb-2 animate-spin" />
            <p>جاري تحميل البيانات...</p>
          </div>
        </div>
      );
    }

    return (
      <div className="p-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">لوحة التحكم</h1>
            <p className="text-sm text-gray-500 mt-1">نظرة عامة على أداء المتجر</p>
          </div>
          <button onClick={fetchDashboard} className="flex items-center gap-2 px-4 py-2.5 bg-gray-100 text-gray-600 rounded-xl text-sm hover:bg-gray-200 transition-colors">
            <RefreshCw className="w-4 h-4" />
            تحديث
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-emerald-600" />
              </div>
              <span className="text-xs text-gray-400">اليوم</span>
            </div>
            <p className="text-xs text-gray-500 font-medium">مبيعات اليوم</p>
            <p className="text-2xl font-bold text-gray-800 mt-1">{formatCurrency(dashboard.today.revenue)}</p>
            <div className="flex items-center gap-1 mt-2 text-xs text-emerald-600">
              <ArrowUpRight className="w-3 h-3" />
              <span>{dashboard.today.sales} عملية</span>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-blue-600" />
              </div>
              <span className="text-xs text-gray-400">هذا الأسبوع</span>
            </div>
            <p className="text-xs text-gray-500 font-medium">مبيعات الأسبوع</p>
            <p className="text-2xl font-bold text-gray-800 mt-1">{formatCurrency(dashboard.week.revenue)}</p>
          </div>

          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-purple-600" />
              </div>
              <span className="text-xs text-gray-400">هذا الشهر</span>
            </div>
            <p className="text-xs text-gray-500 font-medium">مبيعات الشهر</p>
            <p className="text-2xl font-bold text-gray-800 mt-1">{formatCurrency(dashboard.month.revenue)}</p>
          </div>

          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                <Package className="w-6 h-6 text-orange-600" />
              </div>
              <span className="text-xs text-gray-400">المخزون</span>
            </div>
            <p className="text-xs text-gray-500 font-medium">إجمالي المنتجات</p>
            <p className="text-2xl font-bold text-gray-800 mt-1">{dashboard.totalProducts}</p>
            <div className="flex items-center gap-1 mt-2 text-xs text-gray-500">
              <Layers className="w-3 h-3" />
              <span>{dashboard.totalCategories} فئة</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Revenue Chart */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-700 mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary-600" />
              الإيرادات (آخر 7 أيام)
            </h3>
            {dashboard.revenueByDay.length > 0 ? (
              <div>{drawRevenueChart(dashboard.revenueByDay)}</div>
            ) : (
              <div className="flex flex-col items-center justify-center h-32 text-gray-400">
                <BarChart3 className="w-8 h-8 mb-2" />
                <p className="text-sm">لا توجد بيانات</p>
              </div>
            )}
          </div>

          {/* Payment Breakdown */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-700 mb-4 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-primary-600" />
              طرق الدفع (اليوم)
            </h3>
            <div className="space-y-4">
              {dashboard.paymentBreakdown.length > 0 ? dashboard.paymentBreakdown.map((p) => (
                <div key={p.payment_method} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      p.payment_method === 'cash' ? 'bg-green-100' : 'bg-blue-100'
                    }`}>
                      {p.payment_method === 'cash' ? <Banknote className="w-5 h-5 text-green-600" /> : <CreditCard className="w-5 h-5 text-blue-600" />}
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">{p.payment_method === 'cash' ? 'نقدي' : 'بطاقة'}</p>
                      <p className="text-xs text-gray-500">{p.count} عملية</p>
                    </div>
                  </div>
                  <span className="font-bold text-primary-600">{formatCurrency(p.total)}</span>
                </div>
              )) : (
                <div className="flex flex-col items-center justify-center h-32 text-gray-400">
                  <p className="text-sm">لا توجد عمليات اليوم</p>
                </div>
              )}
            </div>

            {/* Quick Stats */}
            <div className="mt-6 pt-4 border-t border-gray-100 grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-xl p-3">
                <p className="text-xs text-gray-500">إجمالي الضريبة اليوم</p>
                <p className="font-bold text-gray-800">{formatCurrency(dashboard.today.tax)}</p>
              </div>
              <div className="bg-gray-50 rounded-xl p-3">
                <p className="text-xs text-gray-500">إجمالي الخصومات اليوم</p>
                <p className="font-bold text-red-500">{formatCurrency(dashboard.today.discounts)}</p>
              </div>
            </div>
          </div>

          {/* Top Products */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-700 mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary-600" />
              الأكثر مبيعاً (اليوم)
            </h3>
            <div className="space-y-3 max-h-72 overflow-y-auto">
              {dashboard.topProducts.length > 0 ? dashboard.topProducts.map((p, i) => (
                <div key={i} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                  <div className="flex items-center gap-3">
                    <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${
                      i === 0 ? 'bg-yellow-100 text-yellow-700' :
                      i === 1 ? 'bg-gray-100 text-gray-600' :
                      i === 2 ? 'bg-orange-100 text-orange-700' :
                      'bg-gray-50 text-gray-400'
                    }`}>
                      {i + 1}
                    </span>
                    <div>
                      <p className="font-medium text-sm text-gray-800">{p.product_name}</p>
                      <p className="text-xs text-gray-500">{p.total_qty} قطعة مباعة</p>
                    </div>
                  </div>
                  <span className="font-bold text-sm text-primary-600">{formatCurrency(p.total_revenue)}</span>
                </div>
              )) : (
                <div className="flex flex-col items-center justify-center h-32 text-gray-400">
                  <p className="text-sm">لا توجد مبيعات اليوم</p>
                </div>
              )}
            </div>
          </div>

          {/* Low Stock */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-700 mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-500" />
              تنبيهات المخزون المنخفض
            </h3>
            <div className="space-y-3 max-h-72 overflow-y-auto">
              {dashboard.lowStock.length > 0 ? dashboard.lowStock.map((p) => (
                <div key={p.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      p.stock <= 0 ? 'bg-red-100' : 'bg-yellow-100'
                    }`}>
                      <AlertTriangle className={`w-5 h-5 ${p.stock <= 0 ? 'text-red-500' : 'text-yellow-500'}`} />
                    </div>
                    <div>
                      <p className="font-medium text-sm text-gray-800">{p.name}</p>
                      <p className="text-xs text-gray-500">{p.category_name || '—'}</p>
                    </div>
                  </div>
                  <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold ${
                    p.stock <= 0 ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {p.stock <= 0 ? 'نفذ' : `${p.stock} قطعة`}
                  </span>
                </div>
              )) : (
                <div className="flex flex-col items-center justify-center h-32 text-green-500">
                  <CheckCircle className="w-8 h-8 mb-2" />
                  <p className="text-sm font-medium">جميع المنتجات متوفرة</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  // ============================================
  // MODALS
  // ============================================
  const renderProductModal = () => (
    showProductModal && (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowProductModal(false)}>
        <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl animate-fade-in" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center justify-between p-5 border-b border-gray-100">
            <h2 className="text-lg font-bold text-gray-800">
              {editingProduct ? 'تعديل منتج' : 'إضافة منتج جديد'}
            </h2>
            <button onClick={() => setShowProductModal(false)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="p-5 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                اسم المنتج <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={productForm.name}
                onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                placeholder="مثال: ماء معدني 500مل"
                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  سعر البيع <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={productForm.price}
                  onChange={(e) => setProductForm({ ...productForm, price: e.target.value })}
                  placeholder="0.00"
                  className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">التكلفة</label>
                <input
                  type="number"
                  step="0.01"
                  value={productForm.cost}
                  onChange={(e) => setProductForm({ ...productForm, cost: e.target.value })}
                  placeholder="0.00"
                  className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">المخزون</label>
                <input
                  type="number"
                  value={productForm.stock}
                  onChange={(e) => setProductForm({ ...productForm, stock: e.target.value })}
                  placeholder="0"
                  className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">الفئة</label>
                <select
                  value={productForm.category_id}
                  onChange={(e) => setProductForm({ ...productForm, category_id: e.target.value })}
                  className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
                >
                  <option value="">بدون فئة</option>
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">الباركود</label>
              <input
                type="text"
                value={productForm.barcode}
                onChange={(e) => setProductForm({ ...productForm, barcode: e.target.value })}
                placeholder="EAN-13 أو أي رمز"
                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 font-mono"
                dir="ltr"
              />
            </div>
          </div>
          <div className="flex gap-3 p-5 border-t border-gray-100">
            <button
              onClick={() => setShowProductModal(false)}
              className="flex-1 py-2.5 bg-gray-100 text-gray-600 rounded-xl text-sm font-medium hover:bg-gray-200 transition-colors"
            >
              إلغاء
            </button>
            <button
              onClick={saveProduct}
              className="flex-1 py-2.5 bg-primary-600 text-white rounded-xl text-sm font-bold hover:bg-primary-700 transition-colors flex items-center justify-center gap-2"
            >
              <Save className="w-4 h-4" />
              {editingProduct ? 'تحديث' : 'إضافة'}
            </button>
          </div>
        </div>
      </div>
    )
  );

  const renderCategoryModal = () => (
    showCategoryModal && (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowCategoryModal(false)}>
        <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl animate-fade-in" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center justify-between p-5 border-b border-gray-100">
            <h2 className="text-lg font-bold text-gray-800">
              {editingCategory ? 'تعديل فئة' : 'إضافة فئة جديدة'}
            </h2>
            <button onClick={() => setShowCategoryModal(false)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="p-5">
            <label className="block text-sm font-medium text-gray-700 mb-1">اسم الفئة</label>
            <input
              type="text"
              value={categoryName}
              onChange={(e) => setCategoryName(e.target.value)}
              placeholder="مثال: مشروبات"
              className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
              autoFocus
              onKeyDown={(e) => e.key === 'Enter' && saveCategory()}
            />
            {/* Existing categories list */}
            {categories.length > 0 && (
              <div className="mt-4">
                <p className="text-xs text-gray-500 mb-2">الفئات الحالية:</p>
                <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                  {categories.map((cat) => (
                    <div key={cat.id} className="flex items-center gap-1 bg-gray-50 rounded-lg px-3 py-1.5 text-xs">
                      <span>{cat.name}</span>
                      <button
                        onClick={() => { setEditingCategory(cat); setCategoryName(cat.name); }}
                        className="text-blue-500 hover:text-blue-700"
                      >
                        <Edit3 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => setShowDeleteConfirm({ type: 'category', id: cat.id, name: cat.name })}
                        className="text-red-400 hover:text-red-600"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div className="flex gap-3 p-5 border-t border-gray-100">
            <button
              onClick={() => setShowCategoryModal(false)}
              className="flex-1 py-2.5 bg-gray-100 text-gray-600 rounded-xl text-sm font-medium hover:bg-gray-200 transition-colors"
            >
              إلغاء
            </button>
            <button
              onClick={saveCategory}
              className="flex-1 py-2.5 bg-primary-600 text-white rounded-xl text-sm font-bold hover:bg-primary-700 transition-colors"
            >
              {editingCategory ? 'تحديث' : 'إضافة'}
            </button>
          </div>
        </div>
      </div>
    )
  );

  const renderSaleDetailModal = () => (
    selectedSale && (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setSelectedSale(null)}>
        <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl animate-fade-in max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center justify-between p-5 border-b border-gray-100">
            <div>
              <h2 className="text-lg font-bold text-gray-800">تفاصيل العملية #{selectedSale.id}</h2>
              <p className="text-xs text-gray-500">{formatDate(selectedSale.created_at)}</p>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => printReceipt(selectedSale)} className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition-colors">
                <Printer className="w-5 h-5" />
              </button>
              <button onClick={() => setSelectedSale(null)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
          <div className="p-5">
            {/* Payment Method */}
            <div className="flex items-center gap-2 mb-4">
              <span className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-sm font-medium ${
                selectedSale.payment_method === 'cash' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
              }`}>
                {selectedSale.payment_method === 'cash' ? <Banknote className="w-4 h-4" /> : <CreditCard className="w-4 h-4" />}
                {selectedSale.payment_method === 'cash' ? 'نقدي' : 'بطاقة'}
              </span>
            </div>

            {/* Items */}
            <div className="bg-gray-50 rounded-xl overflow-hidden mb-4">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="px-4 py-2 text-right text-xs font-semibold text-gray-500">المنتج</th>
                    <th className="px-4 py-2 text-center text-xs font-semibold text-gray-500">الكمية</th>
                    <th className="px-4 py-2 text-center text-xs font-semibold text-gray-500">السعر</th>
                    <th className="px-4 py-2 text-left text-xs font-semibold text-gray-500">المجموع</th>
                  </tr>
                </thead>
                <tbody>
                  {(selectedSale.items || []).map((item) => (
                    <tr key={item.id} className="border-b border-gray-100 last:border-0">
                      <td className="px-4 py-2 text-gray-800">{item.product_name}</td>
                      <td className="px-4 py-2 text-center text-gray-600">{item.qty}</td>
                      <td className="px-4 py-2 text-center text-gray-600">{formatCurrency(item.price)}</td>
                      <td className="px-4 py-2 text-left font-bold text-primary-600">{formatCurrency(item.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals */}
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-gray-500">
                <span>المجموع الفرعي</span>
                <span>{formatCurrency(selectedSale.total)}</span>
              </div>
              {selectedSale.discount > 0 && (
                <div className="flex justify-between text-red-500">
                  <span>الخصم</span>
                  <span>-{formatCurrency(selectedSale.discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-gray-500">
                <span>الضريبة ({(selectedSale.tax_rate * 100).toFixed(0)}%)</span>
                <span>{formatCurrency(selectedSale.tax)}</span>
              </div>
              <div className="flex justify-between text-lg font-bold text-gray-900 pt-2 border-t border-gray-200">
                <span>الإجمالي</span>
                <span className="text-primary-600">{formatCurrency(selectedSale.net_total)}</span>
              </div>
            </div>
          </div>
          <div className="p-5 border-t border-gray-100">
            <button
              onClick={() => setShowRefundConfirm(selectedSale.id)}
              className="w-full py-2.5 bg-red-50 text-red-600 rounded-xl text-sm font-medium hover:bg-red-100 transition-colors flex items-center justify-center gap-2"
            >
              <Undo2 className="w-4 h-4" />
              إلغاء العملية واسترداد المخزون
            </button>
          </div>
        </div>
      </div>
    )
  );

  const renderDeleteConfirm = () => (
    showDeleteConfirm && (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl animate-fade-in p-6 text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="w-8 h-8 text-red-500" />
          </div>
          <h3 className="text-lg font-bold text-gray-800 mb-2">تأكيد الحذف</h3>
          <p className="text-sm text-gray-500 mb-6">
            هل أنت متأكد من حذف {showDeleteConfirm.type === 'product' ? 'المنتج' : 'الفئة'} &ldquo;{showDeleteConfirm.name}&rdquo;؟
            {showDeleteConfirm.type === 'category' && (
              <span className="block mt-1 text-red-500">يجب أن لا تحتوي الفئة على منتجات</span>
            )}
          </p>
          <div className="flex gap-3">
            <button
              onClick={() => setShowDeleteConfirm(null)}
              className="flex-1 py-2.5 bg-gray-100 text-gray-600 rounded-xl text-sm font-medium hover:bg-gray-200 transition-colors"
            >
              إلغاء
            </button>
            <button
              onClick={() => {
                if (showDeleteConfirm.type === 'product') deleteProduct(showDeleteConfirm.id);
                else deleteCategory(showDeleteConfirm.id);
              }}
              className="flex-1 py-2.5 bg-red-500 text-white rounded-xl text-sm font-bold hover:bg-red-600 transition-colors"
            >
              حذف
            </button>
          </div>
        </div>
      </div>
    )
  );

  const renderRefundConfirm = () => (
    showRefundConfirm && (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl animate-fade-in p-6 text-center">
          <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Undo2 className="w-8 h-8 text-orange-500" />
          </div>
          <h3 className="text-lg font-bold text-gray-800 mb-2">تأكيد الإلغاء</h3>
          <p className="text-sm text-gray-500 mb-6">
            هل أنت متأكد من إلغاء العملية رقم #{showRefundConfirm}؟
            <br />
            <span className="text-orange-500 font-medium">سيتم استرداد المخزون تلقائياً</span>
          </p>
          <div className="flex gap-3">
            <button
              onClick={() => setShowRefundConfirm(null)}
              className="flex-1 py-2.5 bg-gray-100 text-gray-600 rounded-xl text-sm font-medium hover:bg-gray-200 transition-colors"
            >
              لا، تراجع
            </button>
            <button
              onClick={() => refundSale(showRefundConfirm)}
              className="flex-1 py-2.5 bg-orange-500 text-white rounded-xl text-sm font-bold hover:bg-orange-600 transition-colors"
            >
              نعم، إلغاء
            </button>
          </div>
        </div>
      </div>
    )
  );

  const renderReceiptModal = () => (
    showReceipt && (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setShowReceipt(null)}>
        <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl animate-fade-in" onClick={(e) => e.stopPropagation()}>
          <div className="p-6 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
            <h3 className="text-lg font-bold text-gray-800 mb-1">تمت العملية بنجاح!</h3>
            <p className="text-sm text-gray-500 mb-2">عملية #{showReceipt.id}</p>
            <p className="text-3xl font-bold text-primary-600 mb-4">{formatCurrency(showReceipt.net_total)}</p>
            <div className="flex justify-center gap-3">
              <button
                onClick={() => printReceipt(showReceipt)}
                className="flex items-center gap-2 px-5 py-2.5 bg-primary-600 text-white rounded-xl text-sm font-bold hover:bg-primary-700 transition-colors"
              >
                <Printer className="w-4 h-4" />
                طباعة الإيصال
              </button>
              <button
                onClick={() => setShowReceipt(null)}
                className="px-5 py-2.5 bg-gray-100 text-gray-600 rounded-xl text-sm font-medium hover:bg-gray-200 transition-colors"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  );

  // ============================================
  // MAIN RENDER
  // ============================================
  return (
    <div className="min-h-screen flex bg-gray-100" dir="rtl">
      {/* Sidebar */}
      <aside className="w-[72px] bg-gray-900 flex flex-col items-center py-4 fixed right-0 top-0 h-full z-40 shadow-xl">
        {/* Logo */}
        <div className="w-11 h-11 bg-primary-600 rounded-xl flex items-center justify-center mb-8 shadow-lg">
          <Store className="w-6 h-6 text-white" />
        </div>

        {/* Navigation */}
        <nav className="flex-1 flex flex-col items-center gap-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              title={tab.label}
              className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-200 group relative ${
                activeTab === tab.id
                  ? 'bg-primary-600 text-white shadow-lg shadow-primary-600/30'
                  : 'text-gray-400 hover:bg-gray-800 hover:text-gray-200'
              }`}
            >
              {tab.icon}
              {/* Tooltip */}
              <span className="absolute right-full mr-3 px-3 py-1.5 bg-gray-800 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none shadow-lg">
                {tab.label}
              </span>
            </button>
          ))}
        </nav>

        {/* Bottom */}
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-px bg-gray-700 mb-2" />
          <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center">
            <span className="text-xs font-bold text-gray-400">POS</span>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 mr-[72px]">
        {/* Top Bar */}
        <header className="h-16 bg-white border-b border-gray-200 flex items-center px-6 fixed left-0 right-[72px] top-0 z-30">
          <div className="flex items-center gap-3">
            <div className="w-2 h-8 bg-primary-600 rounded-full" />
            <div>
              <h1 className="font-bold text-gray-800">{tabs.find(t => t.id === activeTab)?.label}</h1>
              <p className="text-[10px] text-gray-400">{new Date().toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
            </div>
          </div>
          <div className="mr-auto flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 text-xs text-gray-400 bg-gray-50 px-3 py-2 rounded-lg">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              متصل
            </div>
          </div>
        </header>

        {/* Tab Content */}
        <div className="mt-16">
          {activeTab === 'pos' && renderPOS()}
          {activeTab === 'products' && renderProducts()}
          {activeTab === 'sales' && renderSales()}
          {activeTab === 'dashboard' && renderDashboard()}
        </div>
      </main>

      {/* Modals */}
      {renderProductModal()}
      {renderCategoryModal()}
      {renderSaleDetailModal()}
      {renderDeleteConfirm()}
      {renderRefundConfirm()}
      {renderReceiptModal()}

      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-6 left-6 z-50 flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-medium shadow-lg animate-fade-in ${
          toast.type === 'success' ? 'bg-green-500 text-white' :
          toast.type === 'error' ? 'bg-red-500 text-white' :
          'bg-blue-500 text-white'
        }`}>
          {toast.type === 'success' && <CheckCircle className="w-4 h-4" />}
          {toast.type === 'error' && <XCircle className="w-4 h-4" />}
          {toast.message}
        </div>
      )}
    </div>
  );
}
