import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'data', 'invoices.db');
const DIR = path.dirname(DB_PATH);

let db: Database | null = null;

const CREATE_TABLES_SQL = `
  CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    address TEXT,
    tax_number TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    number TEXT UNIQUE NOT NULL,
    client_id INTEGER,
    subtotal REAL DEFAULT 0,
    discount REAL DEFAULT 0,
    discount_type TEXT DEFAULT 'fixed',
    tax_rate REAL DEFAULT 15,
    tax_amount REAL DEFAULT 0,
    total REAL DEFAULT 0,
    status TEXT DEFAULT 'pending',
    notes TEXT,
    due_date TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS invoice_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER NOT NULL,
    description TEXT NOT NULL,
    quantity INTEGER DEFAULT 1,
    unit_price REAL DEFAULT 0,
    total REAL DEFAULT 0,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );
`;

const DEFAULT_SETTINGS = [
  ['company_name', 'شركة البرمجيات المتقدمة'],
  ['company_address', 'صنعاء، اليمن'],
  ['company_phone', '+967 1 234 567'],
  ['company_email', 'info@example.com'],
  ['tax_rate', '15'],
  ['invoice_prefix', 'INV'],
  ['default_payment_terms', '30'],
  ['invoice_start_number', '1'],
];

export async function getDb(): Promise<Database> {
  if (!db) {
    if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });

    const SQL = await initSqlJs();

    if (fs.existsSync(DB_PATH)) {
      const buf = fs.readFileSync(DB_PATH);
      db = new SQL.Database(buf);
    } else {
      db = new SQL.Database();
      db.run(CREATE_TABLES_SQL);

      // Insert default settings
      for (const [key, value] of DEFAULT_SETTINGS) {
        db.run('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', [key, value]);
      }

      saveDb();
    }
  }
  return db;
}

export default getDb;

export function saveDb(): void {
  if (!db) return;
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

export async function getAll<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T[]> {
  const database = await getDb();
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  const results: T[] = [];
  while (stmt.step()) {
    results.push(stmt.getAsObject() as T);
  }
  stmt.free();
  return results;
}

export async function getOne<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T | null> {
  const database = await getDb();
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  let result: T | null = null;
  if (stmt.step()) {
    result = stmt.getAsObject() as T;
  }
  stmt.free();
  return result;
}

export async function run(sql: string, params?: unknown[]): Promise<number> {
  const database = await getDb();
  database.run(sql, params);
  saveDb();
  const res = database.exec('SELECT last_insert_rowid()');
  return res.length > 0 && res[0].values.length > 0 ? Number(res[0].values[0][0]) : 0;
}

export function getLastInsertId(database: Database): number {
  const res = database.exec('SELECT last_insert_rowid()');
  return res.length > 0 && res[0].values.length > 0 ? Number(res[0].values[0][0]) : 0;
}

export function dbRun(database: Database, sql: string, params?: unknown[]): void {
  database.run(sql, params);
}

export function dbAll<T = Record<string, unknown>>(database: Database, sql: string, params?: unknown[]): T[] {
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  const results: T[] = [];
  while (stmt.step()) {
    results.push(stmt.getAsObject() as T);
  }
  stmt.free();
  return results;
}

export function dbGet<T = Record<string, unknown>>(database: Database, sql: string, params?: unknown[]): T | null {
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  let result: T | null = null;
  if (stmt.step()) {
    result = stmt.getAsObject() as T;
  }
  stmt.free();
  return result;
}

export async function transaction<T>(fn: (database: Database) => T): Promise<T> {
  const database = await getDb();
  try {
    database.run('BEGIN');
    const result = fn(database);
    database.run('COMMIT');
    saveDb();
    return result;
  } catch (error) {
    database.run('ROLLBACK');
    throw error;
  }
}
