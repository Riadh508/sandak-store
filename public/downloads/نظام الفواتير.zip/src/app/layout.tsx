import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'نظام الفواتير - Invoice System',
  description: 'نظام احترافي لإنشاء وإدارة الفواتير باللغة العربية',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl">
      <body className="antialiased">
        {children}
      </body>
    </html>
  );
}
