import { NextResponse } from 'next/server';
import getDb, { getAll, getOne, transaction, dbRun, dbGet, dbAll, getLastInsertId } from '@/lib/invoiceDb';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const clientId = searchParams.get('client_id');
    const from = searchParams.get('from');
    const to = searchParams.get('to');
    const limit = parseInt(searchParams.get('limit') || '50');
    const dashboard = searchParams.get('dashboard') === 'true';

    let query = `
      SELECT i.*, c.name as client_name, c.phone as client_phone
      FROM invoices i
      LEFT JOIN clients c ON i.client_id = c.id
    `;
    const conditions: string[] = [];
    const params: unknown[] = [];

    if (status) {
      conditions.push('i.status = ?');
      params.push(status);
    }
    if (clientId) {
      conditions.push('i.client_id = ?');
      params.push(clientId);
    }
    if (from) {
      conditions.push('i.created_at >= ?');
      params.push(from);
    }
    if (to) {
      conditions.push('i.created_at <= ?');
      params.push(to + ' 23:59:59');
    }

    if (conditions.length > 0) {
      query += ' WHERE ' + conditions.join(' AND ');
    }

    query += ' ORDER BY i.created_at DESC LIMIT ?';
    params.push(limit);

    const invoices = await getAll<any>(query, params);

    // Attach items for each invoice
    const invoicesWithItems = await Promise.all(invoices.map(async (invoice) => {
      const items = await getAll('SELECT * FROM invoice_items WHERE invoice_id = ?', [invoice.id]);
      return { ...invoice, items };
    }));

    // Dashboard stats
    if (dashboard) {
      const stats: Record<string, number> = {};

      const totalInvoices = await getOne<{ count: number }>('SELECT COUNT(*) as count FROM invoices');
      stats.total_count = totalInvoices?.count || 0;

      const totalAmount = await getOne<{ sum: number }>('SELECT COALESCE(SUM(total), 0) as sum FROM invoices');
      stats.total_amount = totalAmount?.sum || 0;

      const paidAmount = await getOne<{ sum: number }>("SELECT COALESCE(SUM(total), 0) as sum FROM invoices WHERE status = 'paid'");
      stats.paid_amount = paidAmount?.sum || 0;

      const pendingAmount = await getOne<{ sum: number }>("SELECT COALESCE(SUM(total), 0) as sum FROM invoices WHERE status = 'pending'");
      stats.pending_amount = pendingAmount?.sum || 0;

      const overdueAmount = await getOne<{ sum: number }>("SELECT COALESCE(SUM(total), 0) as sum FROM invoices WHERE status = 'overdue'");
      stats.overdue_amount = overdueAmount?.sum || 0;

      const monthStart = new Date();
      monthStart.setDate(1);
      monthStart.setHours(0, 0, 0, 0);
      const monthStartStr = monthStart.toISOString().split('T')[0];

      const revenueMonth = await getOne<{ sum: number }>('SELECT COALESCE(SUM(total), 0) as sum FROM invoices WHERE status = ? AND created_at >= ?', ['paid', monthStartStr]);
      stats.revenue_this_month = revenueMonth?.sum || 0;

      const clientsCount = await getOne<{ count: number }>('SELECT COUNT(*) as count FROM clients');
      stats.clients_count = clientsCount?.count || 0;

      return NextResponse.json({ invoices: invoicesWithItems, stats });
    }

    return NextResponse.json(invoicesWithItems);
  } catch (error) {
    console.error('Error fetching invoices:', error);
    return NextResponse.json({ error: 'فشل في جلب الفواتير' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { client_id, items, discount, discount_type, tax_rate, notes, due_date } = body;

    const result = await transaction((database) => {
      // Generate invoice number
      const prefix = (dbGet<{ value: string }>(database, 'SELECT value FROM settings WHERE key = ?', ['invoice_prefix']))?.value || 'INV';
      const startNum = parseInt((dbGet<{ value: string }>(database, 'SELECT value FROM settings WHERE key = ?', ['invoice_start_number']))?.value || '1');

      const lastInvoice = dbGet<{ number: string }>(database, "SELECT number FROM invoices WHERE number LIKE ? ORDER BY id DESC LIMIT 1", [`${prefix}%`]);
      let nextNum = startNum;
      if (lastInvoice) {
        const parts = lastInvoice.number.split('-');
        nextNum = (parseInt(parts[parts.length - 1]) || 0) + 1;
      }
      const invoiceNumber = `${prefix}-${String(nextNum).padStart(4, '0')}`;

      // Calculate totals
      const subtotal = items.reduce((sum: number, item: any) => sum + item.quantity * item.unit_price, 0);
      const discountAmount = discount_type === 'percentage' ? (subtotal * discount) / 100 : discount;
      const afterDiscount = subtotal - discountAmount;
      const taxAmount = (afterDiscount * tax_rate) / 100;
      const total = afterDiscount + taxAmount;

      // Insert invoice
      dbRun(database, `
        INSERT INTO invoices (number, client_id, subtotal, discount, discount_type, tax_rate, tax_amount, total, status, notes, due_date)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)
      `, [
        invoiceNumber, client_id || null, subtotal, discount || 0, discount_type || 'fixed',
        tax_rate || 15, taxAmount, total, notes || null, due_date || null
      ]);
      const invoiceId = getLastInsertId(database);

      // Insert items
      for (const item of items) {
        const itemTotal = item.quantity * item.unit_price;
        dbRun(database,
          'INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, total) VALUES (?, ?, ?, ?, ?)',
          [invoiceId, item.description, item.quantity, item.unit_price, itemTotal]
        );
      }

      return { id: invoiceId, number: invoiceNumber };
    });

    return NextResponse.json(result, { status: 201 });
  } catch (error: any) {
    console.error('Error creating invoice:', error);
    if (error.message?.includes('UNIQUE')) {
      return NextResponse.json({ error: 'رقم الفاتورة موجود مسبقاً' }, { status: 400 });
    }
    return NextResponse.json({ error: 'فشل في إنشاء الفاتورة' }, { status: 500 });
  }
}
