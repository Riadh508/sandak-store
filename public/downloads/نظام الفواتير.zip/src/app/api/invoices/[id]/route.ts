import { NextResponse } from 'next/server';
import getDb, { getOne, transaction, dbRun, dbGet, dbAll } from '@/lib/invoiceDb';

export async function GET(request: Request) {
  try {
    const id = request.url.split('/').filter(Boolean).pop();

    const invoice = await getOne<any>(`
      SELECT i.*, c.name as client_name, c.phone as client_phone, c.email as client_email,
             c.address as client_address, c.tax_number as client_tax_number
      FROM invoices i
      LEFT JOIN clients c ON i.client_id = c.id
      WHERE i.id = ?
    `, [id]);

    if (!invoice) {
      return NextResponse.json({ error: 'الفاتورة غير موجودة' }, { status: 404 });
    }

    const items = await import('@/lib/invoiceDb').then(m => m.getAll('SELECT * FROM invoice_items WHERE invoice_id = ?', [invoice.id]));
    invoice.items = items;

    return NextResponse.json(invoice);
  } catch (error) {
    console.error('Error fetching invoice:', error);
    return NextResponse.json({ error: 'فشل في جلب الفاتورة' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const id = parseInt(request.url.split('/').filter(Boolean).pop() || '0');
    const body = await request.json();

    const { client_id, items, discount, discount_type, tax_rate, notes, due_date, status } = body;

    const subtotal = items.reduce((sum: number, item: any) => sum + item.quantity * item.unit_price, 0);
    const discountAmount = discount_type === 'percentage' ? (subtotal * discount) / 100 : discount;
    const afterDiscount = subtotal - discountAmount;
    const taxAmount = (afterDiscount * tax_rate) / 100;
    const total = afterDiscount + taxAmount;

    await transaction((database) => {
      dbRun(database, `
        UPDATE invoices SET client_id = ?, subtotal = ?, discount = ?, discount_type = ?,
        tax_rate = ?, tax_amount = ?, total = ?, notes = ?, due_date = ?, status = ? WHERE id = ?
      `, [client_id || null, subtotal, discount || 0, discount_type || 'fixed', tax_rate || 15, taxAmount, total, notes || null, due_date || null, status || 'pending', id]);

      dbRun(database, 'DELETE FROM invoice_items WHERE invoice_id = ?', [id]);

      for (const item of items) {
        const itemTotal = item.quantity * item.unit_price;
        dbRun(database,
          'INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, total) VALUES (?, ?, ?, ?, ?)',
          [id, item.description, item.quantity, item.unit_price, itemTotal]
        );
      }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error updating invoice:', error);
    return NextResponse.json({ error: 'فشل في تحديث الفاتورة' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const id = parseInt(request.url.split('/').filter(Boolean).pop() || '0');

    await transaction((database) => {
      dbRun(database, 'DELETE FROM invoice_items WHERE invoice_id = ?', [id]);
      dbRun(database, 'DELETE FROM invoices WHERE id = ?', [id]);
    });

    return NextResponse.json({ success: true, message: 'تم حذف الفاتورة بنجاح' });
  } catch (error) {
    console.error('Error deleting invoice:', error);
    return NextResponse.json({ error: 'فشل في حذف الفاتورة' }, { status: 500 });
  }
}
