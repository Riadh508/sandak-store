import { NextResponse } from 'next/server';
import { getAll, getOne, run } from '@/lib/db';

export async function GET() {
  try {
    const clients = await getAll('SELECT * FROM clients ORDER BY name ASC');
    // Get invoice counts for each client
    const clientsWithCounts = await Promise.all(clients.map(async (client: any) => {
      const count = ((await getOne<{ count: number }>('SELECT COUNT(*) as count FROM invoices WHERE client_id = ?', [client.id]))?.count) || 0;
      return { ...client, _count: { invoices: count } };
    }));
    return NextResponse.json(clientsWithCounts);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch clients' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const insertId = await run(
      'INSERT INTO clients (name, phone, email, address, tax_number) VALUES (?, ?, ?, ?, ?)',
      [body.name, body.phone || '', body.email || '', body.address || '', body.tax_number || '']
    );
    const client = await getOne('SELECT * FROM clients WHERE id = ?', [insertId]);
    return NextResponse.json(client, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to create client';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, ...data } = body;
    await run(
      'UPDATE clients SET name = ?, phone = ?, email = ?, address = ?, tax_number = ? WHERE id = ?',
      [data.name, data.phone || '', data.email || '', data.address || '', data.tax_number || '', id]
    );
    const client = await getOne('SELECT * FROM clients WHERE id = ?', [id]);
    return NextResponse.json(client);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to update client';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });
    // Check for invoices
    const invoiceCount = ((await getOne<{ count: number }>('SELECT COUNT(*) as count FROM invoices WHERE client_id = ?', [id]))?.count) || 0;
    if (invoiceCount > 0) {
      return NextResponse.json({ error: 'Cannot delete client with invoices' }, { status: 400 });
    }
    await run('DELETE FROM clients WHERE id = ?', [id]);
    return NextResponse.json({ success: true });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to delete client';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
