'use client';

import { useState } from 'react';
import { Toaster } from 'sonner';
import {
  LayoutDashboard,
  FileText,
  List,
  Receipt,
} from 'lucide-react';
import { InvoiceDashboard } from '@/InvoiceDashboard';

const tabs = [
  { id: 'dashboard', label: 'لوحة الفواتير', icon: LayoutDashboard },
];

export default function HomePage() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Toaster position="top-center" richColors dir="rtl" />

      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary-600 to-teal-500">
                <Receipt className="h-5 w-5 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold leading-tight text-primary-700">نظام الفواتير</span>
                <span className="text-[10px] leading-tight text-muted-foreground">إنشاء وإدارة فواتيرك بسهولة</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium transition-all ${
                  activeTab === 'dashboard'
                    ? 'bg-primary-600 text-white shadow-sm'
                    : 'text-gray-500 bg-gray-100 hover:bg-gray-200'
                }`}
              >
                <LayoutDashboard className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">لوحة التحكم</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <InvoiceDashboard onBack={() => setActiveTab('dashboard')} />
      </main>

      {/* Footer */}
      <footer className="border-t bg-white py-4 text-center text-xs text-gray-400 print:hidden">
        نظام الفواتير © {new Date().getFullYear()} — جميع الحقوق محفوظة
      </footer>
    </div>
  );
}
