'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import {
  FileText,
  Plus,
  DollarSign,
  Clock,
  CheckCircle,
  AlertTriangle,
  ArrowRight,
  Printer,
  Pencil,
  Trash2,
  Eye,
  Search,
  Filter,
  TrendingUp,
  Receipt,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { InvoiceForm } from './InvoiceForm';
import { InvoiceView } from './InvoiceView';

// Types
interface InvoiceItem {
  id?: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
  sortOrder?: number;
}

interface Invoice {
  id: string;
  invoiceNumber: string;
  clientName: string;
  clientPhone?: string;
  clientEmail?: string;
  clientAddress?: string;
  date: string;
  dueDate: string;
  status: string;
  taxRate: number;
  discount: number;
  discountType: string;
  notes?: string;
  subtotal: number;
  taxAmount: number;
  total: number;
  items: InvoiceItem[];
  createdAt: string;
  updatedAt: string;
}

interface InvoiceStats {
  totalInvoices: number;
  totalRevenue: number;
  pendingCount: number;
  paidCount: number;
  overdueCount: number;
}

type ViewMode = 'dashboard' | 'list' | 'create' | 'edit' | 'view';

interface InvoiceDashboardProps {
  onBack: () => void;
}

export function InvoiceDashboard({ onBack }: InvoiceDashboardProps) {
  const [view, setView] = useState<ViewMode>('dashboard');
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [stats, setStats] = useState<InvoiceStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [invoiceToDelete, setInvoiceToDelete] = useState<string | null>(null);

  const fetchInvoices = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/invoices');
      const data = await res.json();
      if (data.success) {
        setInvoices(data.data);
        setStats(data.stats);
      }
    } catch (error) {
      console.error('Error fetching invoices:', error);
      toast.error('فشل في جلب الفواتير');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchInvoices();
  }, [fetchInvoices]);

  const handleCreateInvoice = async (invoiceData: Record<string, unknown>) => {
    try {
      const res = await fetch('/api/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(invoiceData),
      });
      const data = await res.json();
      if (data.success) {
        toast.success('تم إنشاء الفاتورة بنجاح');
        fetchInvoices();
        setView('list');
      } else {
        toast.error(data.error || 'فشل في إنشاء الفاتورة');
      }
    } catch {
      toast.error('فشل في إنشاء الفاتورة');
    }
  };

  const handleUpdateInvoice = async (id: string, invoiceData: Record<string, unknown>) => {
    try {
      const res = await fetch(`/api/invoices/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(invoiceData),
      });
      const data = await res.json();
      if (data.success) {
        toast.success('تم تحديث الفاتورة بنجاح');
        fetchInvoices();
        setView('list');
      } else {
        toast.error(data.error || 'فشل في تحديث الفاتورة');
      }
    } catch {
      toast.error('فشل في تحديث الفاتورة');
    }
  };

  const handleMarkAsPaid = async (id: string) => {
    try {
      const res = await fetch(`/api/invoices/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'paid' }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success('تم تحديث حالة الفاتورة إلى مدفوعة');
        fetchInvoices();
        setSelectedInvoice((prev) => (prev ? { ...prev, status: 'paid' } : null));
      }
    } catch {
      toast.error('فشل في تحديث حالة الفاتورة');
    }
  };

  const handleDeleteInvoice = async () => {
    if (!invoiceToDelete) return;
    try {
      const res = await fetch(`/api/invoices/${invoiceToDelete}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (data.success) {
        toast.success('تم حذف الفاتورة بنجاح');
        fetchInvoices();
        setDeleteDialogOpen(false);
        setInvoiceToDelete(null);
        setView('list');
      } else {
        toast.error(data.error || 'فشل في حذف الفاتورة');
      }
    } catch {
      toast.error('فشل في حذف الفاتورة');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const filteredInvoices = invoices.filter((inv) => {
    const matchesStatus = filterStatus === 'all' || inv.status === filterStatus;
    const matchesSearch =
      searchQuery === '' ||
      inv.clientName.includes(searchQuery) ||
      inv.invoiceNumber.includes(searchQuery) ||
      (inv.clientEmail && inv.clientEmail.includes(searchQuery));
    return matchesStatus && matchesSearch;
  });

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return (
          <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200">
            <CheckCircle className="ml-1 h-3 w-3" />
            مدفوعة
          </Badge>
        );
      case 'pending':
        return (
          <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200">
            <Clock className="ml-1 h-3 w-3" />
            قيد الانتظار
          </Badge>
        );
      case 'overdue':
        return (
          <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-red-200">
            <AlertTriangle className="ml-1 h-3 w-3" />
            متأخرة
          </Badge>
        );
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  // ---------- RENDER FUNCTIONS ----------

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">لوحة الفواتير</h2>
          <p className="text-sm text-gray-500">إدارة و متابعة جميع فواتيرك</p>
        </div>
        <Button
          onClick={() => setView('create')}
          className="bg-blue-600 hover:bg-blue-700 gap-2"
        >
          <Plus className="h-4 w-4" />
          إنشاء فاتورة جديدة
        </Button>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Card className="border-0 shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-500">إجمالي الفواتير</p>
                  <p className="mt-1 text-2xl font-bold text-gray-900">{stats.totalInvoices}</p>
                </div>
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-100">
                  <FileText className="h-5 w-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-500">إجمالي الإيرادات</p>
                  <p className="mt-1 text-xl font-bold text-emerald-600">
                    {formatCurrency(stats.totalRevenue)}
                  </p>
                </div>
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100">
                  <TrendingUp className="h-5 w-5 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-500">قيد الانتظار</p>
                  <p className="mt-1 text-2xl font-bold text-amber-600">{stats.pendingCount}</p>
                </div>
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-100">
                  <Clock className="h-5 w-5 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-500">متأخرة</p>
                  <p className="mt-1 text-2xl font-bold text-red-600">{stats.overdueCount}</p>
                </div>
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-red-100">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Recent Invoices */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg font-semibold text-gray-900">أحدث الفواتير</CardTitle>
          <Button variant="ghost" onClick={() => setView('list')} className="gap-1 text-sm text-blue-600">
            عرض الكل
            <ArrowRight className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-10">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-blue-600 border-t-transparent" />
            </div>
          ) : invoices.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 text-gray-400">
              <Receipt className="h-12 w-12 mb-3" />
              <p className="font-medium">لا توجد فواتير بعد</p>
              <p className="text-sm mt-1">أنشئ أول فاتورة للبدء</p>
              <Button
                onClick={() => setView('create')}
                className="mt-4 bg-blue-600 hover:bg-blue-700 gap-2"
              >
                <Plus className="h-4 w-4" />
                إنشاء فاتورة
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {invoices.slice(0, 5).map((invoice) => (
                <div
                  key={invoice.id}
                  className="flex items-center justify-between rounded-xl border border-gray-100 p-4 hover:bg-gray-50 transition-colors cursor-pointer"
                  onClick={() => {
                    setSelectedInvoice(invoice);
                    setView('view');
                  }}
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50">
                      <Receipt className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900 text-sm">{invoice.invoiceNumber}</p>
                      <p className="text-xs text-gray-500">{invoice.clientName}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {getStatusBadge(invoice.status)}
                    <p className="font-semibold text-gray-900 text-sm">{formatCurrency(invoice.total)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );

  const renderList = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" onClick={() => setView('dashboard')} className="gap-1">
            <ArrowRight className="h-4 w-4" />
            رجوع
          </Button>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">جميع الفواتير</h2>
            <p className="text-sm text-gray-500">{invoices.length} فاتورة</p>
          </div>
        </div>
        <Button onClick={() => setView('create')} className="bg-blue-600 hover:bg-blue-700 gap-2">
          <Plus className="h-4 w-4" />
          إنشاء فاتورة
        </Button>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="بحث بالاسم، رقم الفاتورة..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {[
            { value: 'all', label: 'الكل' },
            { value: 'pending', label: 'قيد الانتظار' },
            { value: 'paid', label: 'مدفوعة' },
            { value: 'overdue', label: 'متأخرة' },
          ].map((filter) => (
            <Button
              key={filter.value}
              variant={filterStatus === filter.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilterStatus(filter.value)}
              className={
                filterStatus === filter.value
                  ? 'bg-blue-600 hover:bg-blue-700 text-white'
                  : ''
              }
            >
              {filter.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Invoice List */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-blue-600 border-t-transparent" />
        </div>
      ) : filteredInvoices.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-gray-400">
          <Filter className="h-12 w-12 mb-3" />
          <p className="font-medium">لا توجد نتائج</p>
          <p className="text-sm mt-1">جرب تغيير معايير البحث أو الفلتر</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredInvoices.map((invoice) => (
            <motion.div
              key={invoice.id}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-xl border border-gray-100 bg-white p-4 hover:shadow-md transition-all"
            >
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                {/* Invoice Info */}
                <div
                  className="flex items-center gap-3 cursor-pointer flex-1"
                  onClick={() => {
                    setSelectedInvoice(invoice);
                    setView('view');
                  }}
                >
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 shrink-0">
                    <Receipt className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-semibold text-gray-900 text-sm">{invoice.invoiceNumber}</p>
                      {getStatusBadge(invoice.status)}
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5">
                      {invoice.clientName} • {formatDate(invoice.date)}
                    </p>
                  </div>
                </div>

                {/* Price + Actions */}
                <div className="flex items-center gap-4 sm:gap-3">
                  <div className="text-left">
                    <p className="font-bold text-gray-900">{formatCurrency(invoice.total)}</p>
                    <p className="text-[11px] text-gray-400">الإجمالي</p>
                  </div>
                  <Separator orientation="vertical" className="h-8 bg-gray-200" />
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-blue-600 hover:bg-blue-50"
                      onClick={() => {
                        setSelectedInvoice(invoice);
                        setView('view');
                      }}
                      title="عرض"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-gray-500 hover:bg-gray-50"
                      onClick={() => {
                        setSelectedInvoice(invoice);
                        setView('edit');
                      }}
                      title="تعديل"
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    {invoice.status !== 'paid' && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-emerald-600 hover:bg-emerald-50"
                        onClick={() => handleMarkAsPaid(invoice.id)}
                        title="تحديد كمدفوعة"
                      >
                        <CheckCircle className="h-4 w-4" />
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-red-500 hover:bg-red-50"
                      onClick={() => {
                        setInvoiceToDelete(invoice.id);
                        setDeleteDialogOpen(true);
                      }}
                      title="حذف"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );

  const renderCreate = () => (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" onClick={() => setView('dashboard')} className="gap-1">
          <ArrowRight className="h-4 w-4" />
          رجوع
        </Button>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">إنشاء فاتورة جديدة</h2>
          <p className="text-sm text-gray-500">أدخل بيانات الفاتورة و البنود</p>
        </div>
      </div>
      <InvoiceForm onSubmit={handleCreateInvoice} loading={false} />
    </div>
  );

  const renderEdit = () => (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" onClick={() => setView('list')} className="gap-1">
          <ArrowRight className="h-4 w-4" />
          رجوع
        </Button>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">تعديل الفاتورة</h2>
          <p className="text-sm text-gray-500">
            {selectedInvoice?.invoiceNumber}
          </p>
        </div>
      </div>
      {selectedInvoice && (
        <InvoiceForm
          onSubmit={(data) => handleUpdateInvoice(selectedInvoice.id, data)}
          loading={false}
          initialData={selectedInvoice}
        />
      )}
    </div>
  );

  const renderView = () => (
    <div className="space-y-4">
      {/* Header - Hidden on print */}
      <div className="flex items-center justify-between print:hidden">
        <div className="flex items-center gap-3">
          <Button variant="ghost" onClick={() => setView('list')} className="gap-1">
            <ArrowRight className="h-4 w-4" />
            رجوع
          </Button>
          <h2 className="text-xl font-bold text-gray-900">تفاصيل الفاتورة</h2>
        </div>
        <div className="flex gap-2">
          {selectedInvoice && selectedInvoice.status !== 'paid' && (
            <Button
              onClick={() => handleMarkAsPaid(selectedInvoice.id)}
              className="bg-emerald-600 hover:bg-emerald-700 gap-2"
            >
              <CheckCircle className="h-4 w-4" />
              تحديد كمدفوعة
            </Button>
          )}
          <Button variant="outline" onClick={handlePrint} className="gap-2">
            <Printer className="h-4 w-4" />
            طباعة
          </Button>
          {selectedInvoice && (
            <>
              <Button
                variant="outline"
                onClick={() => setView('edit')}
                className="gap-2"
              >
                <Pencil className="h-4 w-4" />
                تعديل
              </Button>
              <Button
                variant="outline"
                className="gap-2 text-red-600 hover:bg-red-50 border-red-200"
                onClick={() => {
                  setInvoiceToDelete(selectedInvoice.id);
                  setDeleteDialogOpen(true);
                }}
              >
                <Trash2 className="h-4 w-4" />
                حذف
              </Button>
            </>
          )}
        </div>
      </div>
      {selectedInvoice && (
        <InvoiceView invoice={selectedInvoice} formatDate={formatDate} formatCurrency={formatCurrency} />
      )}
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header - Hidden on print */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md print:hidden">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            <button
              onClick={onBack}
              className="flex items-center gap-2 transition-transform hover:scale-105"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600 to-blue-500">
                <Receipt className="h-5 w-5 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold leading-tight text-blue-700">نظام الفواتير</span>
                <span className="text-[10px] leading-tight text-muted-foreground">سندك لإدارة الفواتير</span>
              </div>
            </button>

            <div className="flex items-center gap-2">
              {view === 'dashboard' && (
                <Button onClick={() => setView('create')} className="bg-blue-600 hover:bg-blue-700 gap-2">
                  <Plus className="h-4 w-4" />
                  <span className="hidden sm:inline">فاتورة جديدة</span>
                </Button>
              )}
              <Button variant="outline" size="icon" onClick={onBack} className="border-gray-200">
                <ArrowRight className="h-5 w-5 text-gray-600" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="container mx-auto px-4 py-6 max-w-5xl">
          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {view === 'dashboard' && renderDashboard()}
              {view === 'list' && renderList()}
              {view === 'create' && renderCreate()}
              {view === 'edit' && renderEdit()}
              {view === 'view' && renderView()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف الفاتورة</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف هذه الفاتورة؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteInvoice}
              className="bg-red-600 hover:bg-red-700"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
