'use client';

import { useState, useCallback } from 'react';
import { toast } from 'sonner';
import {
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Plus,
  Trash2,
  Percent,
  DollarSign,
  FileText,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

interface InvoiceFormData {
  clientName: string;
  clientPhone: string;
  clientEmail: string;
  clientAddress: string;
  date: string;
  dueDate: string;
  taxRate: number;
  discount: number;
  discountType: string;
  notes: string;
  items: InvoiceItem[];
}

interface InvoiceFormProps {
  onSubmit: (data: Record<string, unknown>) => void;
  loading: boolean;
  initialData?: {
    invoiceNumber: string;
    clientName: string;
    clientPhone?: string;
    clientEmail?: string;
    clientAddress?: string;
    date: string;
    dueDate: string;
    taxRate: number;
    discount: number;
    discountType: string;
    notes?: string;
    items: { id?: string; description: string; quantity: number; unitPrice: number; total: number; sortOrder?: number }[];
  } | null;
}

const emptyItem = (): InvoiceItem => ({
  id: crypto.randomUUID(),
  description: '',
  quantity: 1,
  unitPrice: 0,
  total: 0,
});

export function InvoiceForm({ onSubmit, loading, initialData }: InvoiceFormProps) {
  const today = new Date().toISOString().split('T')[0];
  const dueDateDefault = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  const [formData, setFormData] = useState<InvoiceFormData>({
    clientName: initialData?.clientName || '',
    clientPhone: initialData?.clientPhone || '',
    clientEmail: initialData?.clientEmail || '',
    clientAddress: initialData?.clientAddress || '',
    date: initialData ? initialData.date.split('T')[0] : today,
    dueDate: initialData ? initialData.dueDate.split('T')[0] : dueDateDefault,
    taxRate: initialData?.taxRate ?? 15,
    discount: initialData?.discount ?? 0,
    discountType: initialData?.discountType || 'fixed',
    notes: initialData?.notes || '',
    items: initialData?.items?.length
      ? initialData.items.map((item, i) => ({
          id: item.id || crypto.randomUUID(),
          description: item.description,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          total: item.quantity * item.unitPrice,
        }))
      : [emptyItem()],
  });

  const updateItem = useCallback(
    (index: number, field: keyof InvoiceItem, value: string | number) => {
      setFormData((prev) => {
        const newItems = [...prev.items];
        const item = { ...newItems[index] };
        (item as Record<string, unknown>)[field] = value;
        if (field === 'quantity' || field === 'unitPrice') {
          item.total = item.quantity * item.unitPrice;
        }
        newItems[index] = item;
        return { ...prev, items: newItems };
      });
    },
    []
  );

  const addItem = () => {
    setFormData((prev) => ({ ...prev, items: [...prev.items, emptyItem()] }));
  };

  const removeItem = (index: number) => {
    if (formData.items.length <= 1) {
      toast.error('يجب أن تحتوي الفاتورة على بند واحد على الأقل');
      return;
    }
    setFormData((prev) => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index),
    }));
  };

  const subtotal = formData.items.reduce((sum, item) => sum + item.total, 0);
  let discountAmount = 0;
  if (formData.discountType === 'percentage') {
    discountAmount = subtotal * (formData.discount / 100);
  } else {
    discountAmount = formData.discount || 0;
  }
  const taxableAmount = subtotal - discountAmount;
  const taxAmount = taxableAmount * ((formData.taxRate || 0) / 100);
  const total = taxableAmount + taxAmount;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.clientName.trim()) {
      toast.error('يرجى إدخال اسم العميل');
      return;
    }
    if (!formData.dueDate) {
      toast.error('يرجى إدخال تاريخ الاستحقاق');
      return;
    }
    const validItems = formData.items.filter((item) => item.description.trim() !== '');
    if (validItems.length === 0) {
      toast.error('يرجى إضافة بند واحد على الأقل');
      return;
    }
    if (validItems.some((item) => item.unitPrice <= 0)) {
      toast.error('يرجى إدخال سعر صالح لجميع البنود');
      return;
    }

    onSubmit({
      ...formData,
      items: validItems,
      subtotal,
      taxAmount: Math.round(taxAmount * 100) / 100,
      total: Math.round(total * 100) / 100,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Client Info */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-lg">
            <User className="h-5 w-5 text-blue-600" />
            بيانات العميل
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="clientName" className="text-sm font-medium">
                اسم العميل <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <User className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input
                  id="clientName"
                  placeholder="أدخل اسم العميل"
                  value={formData.clientName}
                  onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                  className="pr-10"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="clientPhone" className="text-sm font-medium">
                رقم الهاتف
              </Label>
              <div className="relative">
                <Phone className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input
                  id="clientPhone"
                  placeholder="+967 7XX XXX XXX"
                  value={formData.clientPhone}
                  onChange={(e) => setFormData({ ...formData, clientPhone: e.target.value })}
                  className="pr-10"
                  dir="ltr"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="clientEmail" className="text-sm font-medium">
                البريد الإلكتروني
              </Label>
              <div className="relative">
                <Mail className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input
                  id="clientEmail"
                  type="email"
                  placeholder="example@email.com"
                  value={formData.clientEmail}
                  onChange={(e) => setFormData({ ...formData, clientEmail: e.target.value })}
                  className="pr-10"
                  dir="ltr"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="clientAddress" className="text-sm font-medium">
                العنوان
              </Label>
              <div className="relative">
                <MapPin className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input
                  id="clientAddress"
                  placeholder="مدينة، شارع، رقم المبنى"
                  value={formData.clientAddress}
                  onChange={(e) => setFormData({ ...formData, clientAddress: e.target.value })}
                  className="pr-10"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Invoice Details */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-lg">
            <FileText className="h-5 w-5 text-blue-600" />
            تفاصيل الفاتورة
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="date" className="text-sm font-medium">
                تاريخ الفاتورة
              </Label>
              <div className="relative">
                <Calendar className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="pr-10"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="dueDate" className="text-sm font-medium">
                تاريخ الاستحقاق <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Calendar className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input
                  id="dueDate"
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                  className="pr-10"
                  required
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Items */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-lg">
              <FileText className="h-5 w-5 text-blue-600" />
              بنود الفاتورة
            </CardTitle>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={addItem}
              className="gap-1 border-blue-200 text-blue-600 hover:bg-blue-50"
            >
              <Plus className="h-4 w-4" />
              إضافة بند
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Items Header - Desktop */}
          <div className="hidden sm:grid sm:grid-cols-12 gap-3 text-xs font-medium text-gray-500 pb-2 border-b">
            <div className="col-span-5">الوصف</div>
            <div className="col-span-2 text-center">الكمية</div>
            <div className="col-span-2 text-center">سعر الوحدة</div>
            <div className="col-span-2 text-center">الإجمالي</div>
            <div className="col-span-1"></div>
          </div>

          {formData.items.map((item, index) => (
            <div
              key={item.id}
              className="grid grid-cols-1 gap-3 rounded-xl border border-gray-100 bg-gray-50/50 p-3 sm:grid-cols-12 sm:gap-3 sm:items-center sm:bg-transparent sm:p-0 sm:border-0"
            >
              {/* Description */}
              <div className="sm:col-span-5">
                <label className="block text-xs font-medium text-gray-500 mb-1 sm:hidden">الوصف</label>
                <Input
                  placeholder="وصف البند..."
                  value={item.description}
                  onChange={(e) => updateItem(index, 'description', e.target.value)}
                  className="bg-white"
                />
              </div>
              {/* Quantity */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-gray-500 mb-1 sm:hidden">الكمية</label>
                <Input
                  type="number"
                  min="1"
                  value={item.quantity}
                  onChange={(e) => updateItem(index, 'quantity', parseInt(e.target.value) || 0)}
                  className="bg-white text-center"
                />
              </div>
              {/* Unit Price */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-gray-500 mb-1 sm:hidden">سعر الوحدة</label>
                <Input
                  type="number"
                  min="0"
                  step="0.01"
                  value={item.unitPrice}
                  onChange={(e) => updateItem(index, 'unitPrice', parseFloat(e.target.value) || 0)}
                  className="bg-white text-center"
                  dir="ltr"
                />
              </div>
              {/* Total */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-gray-500 mb-1 sm:hidden">الإجمالي</label>
                <div className="flex h-9 items-center justify-center rounded-md border bg-gray-100 text-sm font-semibold text-gray-700">
                  {formatCurrency(item.total)}
                </div>
              </div>
              {/* Delete */}
              <div className="sm:col-span-1 flex justify-center">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-red-400 hover:bg-red-50 hover:text-red-600"
                  onClick={() => removeItem(index)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Tax, Discount, Notes */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Percent className="h-5 w-5 text-blue-600" />
              الضريبة والخصم
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">نسبة الضريبة (%)</Label>
                <div className="relative">
                  <Percent className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                  <Input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={formData.taxRate}
                    onChange={(e) => setFormData({ ...formData, taxRate: parseFloat(e.target.value) || 0 })}
                    className="pr-10 text-center"
                    dir="ltr"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium">نوع الخصم</Label>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant={formData.discountType === 'fixed' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setFormData({ ...formData, discountType: 'fixed' })}
                    className={
                      formData.discountType === 'fixed'
                        ? 'bg-blue-600 hover:bg-blue-700 text-white flex-1'
                        : 'flex-1'
                    }
                  >
                    <DollarSign className="ml-1 h-3 w-3" />
                    مبلغ
                  </Button>
                  <Button
                    type="button"
                    variant={formData.discountType === 'percentage' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setFormData({ ...formData, discountType: 'percentage' })}
                    className={
                      formData.discountType === 'percentage'
                        ? 'bg-blue-600 hover:bg-blue-700 text-white flex-1'
                        : 'flex-1'
                    }
                  >
                    <Percent className="ml-1 h-3 w-3" />
                    نسبة
                  </Button>
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium">
                قيمة الخصم
                {formData.discountType === 'percentage' && ' (%)'}
              </Label>
              <Input
                type="number"
                min="0"
                step="0.01"
                value={formData.discount}
                onChange={(e) => setFormData({ ...formData, discount: parseFloat(e.target.value) || 0 })}
                placeholder="0"
                dir="ltr"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg">الملخص المالي</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">المجموع الفرعي</span>
              <span className="font-medium">{formatCurrency(subtotal)}</span>
            </div>
            {formData.discount > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">
                  الخصم
                  {formData.discountType === 'percentage' &&
                    ` (${formData.discount}%)`}
                </span>
                <span className="font-medium text-red-600">-{formatCurrency(discountAmount)}</span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">الضريبة ({formData.taxRate}%)</span>
              <span className="font-medium">{formatCurrency(taxAmount)}</span>
            </div>
            <Separator />
            <div className="flex justify-between text-lg font-bold">
              <span>الإجمالي</span>
              <span className="text-blue-600">{formatCurrency(total)}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Notes */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg">ملاحظات</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="أضف ملاحظات أو شروط دفع..."
            value={formData.notes}
            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            rows={3}
            className="resize-none"
          />
        </CardContent>
      </Card>

      {/* Submit */}
      <div className="flex justify-end gap-3">
        <Button
          type="submit"
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700 gap-2 px-8"
        >
          {loading ? (
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
          ) : (
            <FileText className="h-4 w-4" />
          )}
          {initialData ? 'تحديث الفاتورة' : 'إنشاء الفاتورة'}
        </Button>
      </div>
    </form>
  );
}
