'use client';

import {
  Receipt,
  CheckCircle,
  Clock,
  AlertTriangle,
  Phone,
  Mail,
  MapPin,
  Building2,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

interface InvoiceItem {
  id?: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
  sortOrder?: number;
}

interface Invoice {
  id: string;
  invoiceNumber: string;
  clientName: string;
  clientPhone?: string;
  clientEmail?: string;
  clientAddress?: string;
  date: string;
  dueDate: string;
  status: string;
  taxRate: number;
  discount: number;
  discountType: string;
  notes?: string;
  subtotal: number;
  taxAmount: number;
  total: number;
  items: InvoiceItem[];
}

interface InvoiceViewProps {
  invoice: Invoice;
  formatDate: (dateStr: string) => string;
  formatCurrency: (amount: number) => string;
}

export function InvoiceView({ invoice, formatDate, formatCurrency }: InvoiceViewProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-3 py-1 text-sm font-medium text-emerald-700">
            <CheckCircle className="h-3.5 w-3.5" />
            مدفوعة
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-3 py-1 text-sm font-medium text-amber-700">
            <Clock className="h-3.5 w-3.5" />
            قيد الانتظار
          </span>
        );
      case 'overdue':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-3 py-1 text-sm font-medium text-red-700">
            <AlertTriangle className="h-3.5 w-3.5" />
            متأخرة
          </span>
        );
      default:
        return null;
    }
  };

  // Calculate discount amount
  let discountAmount = 0;
  if (invoice.discountType === 'percentage') {
    discountAmount = invoice.subtotal * (invoice.discount / 100);
  } else {
    discountAmount = invoice.discount || 0;
  }

  return (
    <div
      className="mx-auto max-w-3xl rounded-2xl bg-white shadow-lg print:shadow-none print:rounded-none print:border-0"
      dir="rtl"
    >
      {/* Invoice Header */}
      <div className="rounded-t-2xl bg-gradient-to-l from-blue-600 to-blue-500 p-6 text-white sm:p-8 print:rounded-t-none">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/20 backdrop-blur-sm">
              <Receipt className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">فاتورة</h1>
              <p className="text-sm text-blue-100">{invoice.invoiceNumber}</p>
            </div>
          </div>
          <div className="text-left">
            {getStatusBadge(invoice.status)}
          </div>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3">
          <div>
            <p className="text-xs text-blue-200">تاريخ الإصدار</p>
            <p className="mt-0.5 text-sm font-medium">{formatDate(invoice.date)}</p>
          </div>
          <div>
            <p className="text-xs text-blue-200">تاريخ الاستحقاق</p>
            <p className="mt-0.5 text-sm font-medium">{formatDate(invoice.dueDate)}</p>
          </div>
        </div>
      </div>

      {/* Company & Client Info */}
      <div className="p-6 sm:p-8">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          {/* Company Info */}
          <div className="rounded-xl bg-blue-50/60 p-5">
            <div className="flex items-center gap-2 mb-3">
              <Building2 className="h-4 w-4 text-blue-600" />
              <p className="text-sm font-semibold text-blue-800">معلومات الشركة</p>
            </div>
            <div className="space-y-1.5">
              <p className="font-bold text-gray-900">متجر سندك</p>
              <p className="text-sm text-gray-600">للبرمجيات والمنتجات الرقمية</p>
              <div className="flex items-center gap-1.5 text-sm text-gray-500">
                <Phone className="h-3.5 w-3.5" />
                <span dir="ltr">00967770240572</span>
              </div>
              <div className="flex items-center gap-1.5 text-sm text-gray-500">
                <Mail className="h-3.5 w-3.5" />
                <span dir="ltr">info@sandak.com</span>
              </div>
              <div className="flex items-center gap-1.5 text-sm text-gray-500">
                <MapPin className="h-3.5 w-3.5" />
                <span>صنعاء - اليمن</span>
              </div>
            </div>
          </div>

          {/* Client Info */}
          <div className="rounded-xl bg-gray-50 p-5">
            <div className="flex items-center gap-2 mb-3">
              <Building2 className="h-4 w-4 text-gray-600" />
              <p className="text-sm font-semibold text-gray-800">معلومات العميل</p>
            </div>
            <div className="space-y-1.5">
              <p className="font-bold text-gray-900">{invoice.clientName}</p>
              {invoice.clientPhone && (
                <div className="flex items-center gap-1.5 text-sm text-gray-500">
                  <Phone className="h-3.5 w-3.5" />
                  <span dir="ltr">{invoice.clientPhone}</span>
                </div>
              )}
              {invoice.clientEmail && (
                <div className="flex items-center gap-1.5 text-sm text-gray-500">
                  <Mail className="h-3.5 w-3.5" />
                  <span dir="ltr">{invoice.clientEmail}</span>
                </div>
              )}
              {invoice.clientAddress && (
                <div className="flex items-center gap-1.5 text-sm text-gray-500">
                  <MapPin className="h-3.5 w-3.5" />
                  <span>{invoice.clientAddress}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Items Table */}
        <div className="mt-8">
          <div className="rounded-xl border border-gray-200 overflow-hidden">
            {/* Table Header */}
            <div className="hidden sm:grid sm:grid-cols-12 gap-4 bg-gray-50 px-5 py-3 text-xs font-semibold text-gray-600">
              <div className="col-span-1 text-center">#</div>
              <div className="col-span-5">الوصف</div>
              <div className="col-span-2 text-center">الكمية</div>
              <div className="col-span-2 text-center">سعر الوحدة</div>
              <div className="col-span-2 text-center">الإجمالي</div>
            </div>

            {/* Table Rows */}
            {invoice.items.map((item, index) => (
              <div key={item.id || index}>
                <div className="grid grid-cols-1 gap-2 px-5 py-3 sm:grid-cols-12 sm:gap-4 sm:items-center border-b border-gray-100 last:border-0">
                  <div className="hidden sm:flex sm:col-span-1 justify-center">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-100 text-xs font-medium text-blue-700">
                      {index + 1}
                    </span>
                  </div>
                  <div className="sm:col-span-5">
                    <span className="sm:hidden text-xs text-gray-400 ml-1">#{index + 1} - </span>
                    <span className="text-sm text-gray-900">{item.description}</span>
                  </div>
                  <div className="sm:col-span-2 sm:text-center text-sm text-gray-600">
                    <span className="sm:hidden text-xs text-gray-400 ml-1">الكمية: </span>
                    {item.quantity}
                  </div>
                  <div className="sm:col-span-2 sm:text-center text-sm text-gray-600">
                    <span className="sm:hidden text-xs text-gray-400 ml-1">السعر: </span>
                    {formatCurrency(item.unitPrice)}
                  </div>
                  <div className="sm:col-span-2 sm:text-center text-sm font-semibold text-gray-900">
                    <span className="sm:hidden text-xs text-gray-400 ml-1">المجموع: </span>
                    {formatCurrency(item.total)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Totals */}
        <div className="mt-6 flex justify-end">
          <div className="w-full max-w-xs space-y-2 rounded-xl border border-gray-200 bg-gray-50 p-4">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">المجموع الفرعي</span>
              <span className="font-medium">{formatCurrency(invoice.subtotal)}</span>
            </div>
            {invoice.discount > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">
                  الخصم
                  {invoice.discountType === 'percentage' &&
                    ` (${invoice.discount}%)`}
                </span>
                <span className="font-medium text-red-600">
                  -{formatCurrency(discountAmount)}
                </span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">ضريبة القيمة المضافة ({invoice.taxRate}%)</span>
              <span className="font-medium">{formatCurrency(invoice.taxAmount)}</span>
            </div>
            <Separator />
            <div className="flex justify-between text-lg font-bold">
              <span>الإجمالي شامل الضريبة</span>
              <span className="text-blue-600">{formatCurrency(invoice.total)}</span>
            </div>
          </div>
        </div>

        {/* Notes */}
        {invoice.notes && (
          <div className="mt-6 rounded-xl border border-gray-200 bg-amber-50/50 p-4">
            <p className="text-sm font-semibold text-gray-700 mb-1">ملاحظات</p>
            <p className="text-sm text-gray-600 whitespace-pre-wrap">{invoice.notes}</p>
          </div>
        )}

        {/* Footer */}
        <div className="mt-8 text-center">
          <Separator className="mb-4" />
          <p className="text-xs text-gray-400">
            شكراً لتعاملكم معنا — متجر سندك للبرمجيات والمنتجات الرقمية
          </p>
          <p className="mt-1 text-xs text-gray-400" dir="ltr">
            sandak.com
          </p>
        </div>
      </div>
    </div>
  );
}
