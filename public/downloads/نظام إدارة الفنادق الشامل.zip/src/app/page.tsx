'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard, Bed, BookOpen, Users, Plus, Pencil, Trash2, X,
  Search, ChevronDown, ChevronUp, Check, AlertCircle, Loader2,
  Calendar, Phone, CreditCard, TrendingUp, Home, DoorOpen,
  UserCheck, DollarSign, ArrowUpDown, Eye, Filter
} from 'lucide-react';

// ==================== TYPES ====================
interface Room {
  id: number;
  number: string;
  type: string;
  price: number;
  status: string;
}

interface Booking {
  id: number;
  guest_name: string;
  guest_phone: string;
  room_number: string;
  check_in: string;
  check_out: string;
  nights: number;
  total_price: number;
  status: string;
  created_at: string;
}

interface Guest {
  guest_name: string;
  guest_phone: string;
  total_bookings: number;
  total_spent: number;
  last_visit: string;
}

interface DashboardStats {
  totalRooms: number;
  availableRooms: number;
  occupiedRooms: number;
  totalBookings: number;
  activeBookings: number;
  totalRevenue: number;
  todayCheckins: number;
  roomTypes: { type: string; count: number }[];
  recentBookings: Booking[];
  monthlyRevenue: { month: string; revenue: number; bookings: number }[];
}

type TabType = 'dashboard' | 'rooms' | 'bookings' | 'guests';

// ==================== MAIN COMPONENT ====================
export default function HotelManagementPage() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const tabs: { key: TabType; label: string; icon: React.ReactNode }[] = [
    { key: 'dashboard', label: 'لوحة التحكم', icon: <LayoutDashboard size={20} /> },
    { key: 'rooms', label: 'الغرف', icon: <Bed size={20} /> },
    { key: 'bookings', label: 'الحجوزات', icon: <BookOpen size={20} /> },
    { key: 'guests', label: 'الضيوف', icon: <Users size={20} /> },
  ];

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-navy-900 text-white transition-all duration-300 flex flex-col min-h-screen fixed right-0 top-0 bottom-0 z-30`}>
        {/* Logo */}
        <div className="p-4 border-b border-navy-700 flex items-center gap-3">
          <div className="w-10 h-10 bg-navy-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <Home size={22} className="text-blue-300" />
          </div>
          {sidebarOpen && (
            <div className="animate-fade-in">
              <h1 className="font-bold text-lg leading-tight">إدارة الفندق</h1>
              <p className="text-xs text-blue-300">Hotel Management</p>
            </div>
          )}
        </div>

        {/* Nav Items */}
        <nav className="flex-1 py-4">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`w-full flex items-center gap-3 px-4 py-3 transition-all duration-200 ${
                activeTab === tab.key
                  ? 'bg-navy-700 text-white border-l-4 border-blue-400'
                  : 'text-blue-200 hover:bg-navy-800 hover:text-white'
              }`}
            >
              <span className="flex-shrink-0">{tab.icon}</span>
              {sidebarOpen && <span className="animate-fade-in">{tab.label}</span>}
            </button>
          ))}
        </nav>

        {/* Toggle Sidebar */}
        <div className="p-4 border-t border-navy-700">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="w-full flex items-center justify-center gap-2 py-2 text-blue-200 hover:text-white transition-colors rounded-lg hover:bg-navy-800"
          >
            {sidebarOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
            {sidebarOpen && <span className="text-sm">طي القائمة</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'mr-64' : 'mr-20'}`}>
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4 sticky top-0 z-20">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-navy-900">
                {tabs.find(t => t.key === activeTab)?.label}
              </h2>
              <p className="text-sm text-gray-500">
                {activeTab === 'dashboard' && 'نظرة عامة على أداء الفندق'}
                {activeTab === 'rooms' && 'إدارة غرف الفندق'}
                {activeTab === 'bookings' && 'إدارة الحجوزات'}
                {activeTab === 'guests' && 'سجل الضيوف'}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-sm text-gray-500">
                {new Date().toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="p-6 animate-fade-in">
          {activeTab === 'dashboard' && <Dashboard />}
          {activeTab === 'rooms' && <RoomsTab />}
          {activeTab === 'bookings' && <BookingsTab />}
          {activeTab === 'guests' && <GuestsTab />}
        </div>
      </main>
    </div>
  );
}

// ==================== TOAST ====================
function Toast({ message, type, onClose }: { message: string; type: 'success' | 'error'; onClose: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className={`fixed top-4 left-4 z-50 px-4 py-3 rounded-lg shadow-lg flex items-center gap-2 animate-slide-in ${
      type === 'success' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'
    }`}>
      {type === 'success' ? <Check size={18} /> : <AlertCircle size={18} />}
      <span className="text-sm font-medium">{message}</span>
      <button onClick={onClose} className="mr-2 hover:opacity-80"><X size={14} /></button>
    </div>
  );
}

// ==================== DASHBOARD ====================
function Dashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchStats = useCallback(async () => {
    try {
      const res = await fetch('/api/dashboard');
      const data = await res.json();
      setStats(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchStats(); }, [fetchStats]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="animate-spin text-navy-600" size={40} />
      </div>
    );
  }

  if (!stats) return null;

  const statCards = [
    { label: 'إجمالي الغرف', value: stats.totalRooms, icon: <DoorOpen size={24} />, color: 'bg-blue-50 text-blue-700', iconBg: 'bg-blue-100' },
    { label: 'الغرف المتاحة', value: stats.availableRooms, icon: <Check size={24} />, color: 'bg-green-50 text-green-700', iconBg: 'bg-green-100' },
    { label: 'الغرف المشغولة', value: stats.occupiedRooms, icon: <Bed size={24} />, color: 'bg-red-50 text-red-700', iconBg: 'bg-red-100' },
    { label: 'إجمالي الحجوزات', value: stats.totalBookings, icon: <BookOpen size={24} />, color: 'bg-purple-50 text-purple-700', iconBg: 'bg-purple-100' },
    { label: 'الحجوزات النشطة', value: stats.activeBookings, icon: <Calendar size={24} />, color: 'bg-orange-50 text-orange-700', iconBg: 'bg-orange-100' },
    { label: 'وصولات اليوم', value: stats.todayCheckins, icon: <UserCheck size={24} />, color: 'bg-teal-50 text-teal-700', iconBg: 'bg-teal-100' },
  ];

  return (
    <div className="space-y-6">
      {/* Revenue Card */}
      <div className="bg-gradient-to-l from-navy-900 to-navy-700 text-white rounded-2xl p-6 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-blue-200 text-sm mb-1">إجمالي الإيرادات</p>
            <p className="text-4xl font-bold">
              {stats.totalRevenue.toLocaleString('ar-EG')} <span className="text-lg">ر.س</span>
            </p>
          </div>
          <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center">
            <DollarSign size={32} className="text-green-300" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-2 text-blue-200 text-sm">
          <TrendingUp size={16} />
          <span>إجمالي الإيرادات من الحجوزات المؤكدة والمكتملة</span>
        </div>
      </div>

      {/* Stat Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {statCards.map((card, i) => (
          <div key={i} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 card-hover">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 mb-1">{card.label}</p>
                <p className="text-3xl font-bold text-gray-900">{card.value}</p>
              </div>
              <div className={`w-12 h-12 rounded-xl ${card.iconBg} flex items-center justify-center text-gray-700`}>
                {card.icon}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Room Types */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-navy-900 mb-4 flex items-center gap-2">
            <ArrowUpDown size={20} />
            توزيع الغرف حسب النوع
          </h3>
          {stats.roomTypes.length === 0 ? (
            <p className="text-gray-400 text-center py-8">لا توجد غرف مسجلة بعد</p>
          ) : (
            <div className="space-y-3">
              {stats.roomTypes.map((rt, i) => (
                <div key={i} className="flex items-center justify-between">
                  <span className="text-gray-700 font-medium">{rt.type}</span>
                  <div className="flex items-center gap-3">
                    <div className="w-32 bg-gray-100 rounded-full h-2.5">
                      <div
                        className="bg-navy-600 h-2.5 rounded-full transition-all duration-500"
                        style={{ width: `${stats.totalRooms ? (rt.count / stats.totalRooms) * 100 : 0}%` }}
                      />
                    </div>
                    <span className="text-sm font-bold text-navy-700 w-8 text-left">{rt.count}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Bookings */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-navy-900 mb-4 flex items-center gap-2">
            <CreditCard size={20} />
            أحدث الحجوزات
          </h3>
          {stats.recentBookings.length === 0 ? (
            <p className="text-gray-400 text-center py-8">لا توجد حجوزات بعد</p>
          ) : (
            <div className="space-y-3 max-h-72 overflow-y-auto">
              {stats.recentBookings.map((b) => (
                <div key={b.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div>
                    <p className="font-semibold text-gray-800">{b.guest_name}</p>
                    <p className="text-xs text-gray-500">غرفة {b.room_number} - {b.nights} ليالي</p>
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-navy-700">{b.total_price.toLocaleString('ar-EG')} ر.س</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${getStatusBadge(b.status)}`}>
                      {getStatusLabel(b.status)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Monthly Revenue */}
      {stats.monthlyRevenue.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-navy-900 mb-4 flex items-center gap-2">
            <TrendingUp size={20} />
            الإيرادات الشهرية
          </h3>
          <div className="space-y-3">
            {stats.monthlyRevenue.map((m, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="font-medium text-gray-700">{m.month}</span>
                <div className="flex items-center gap-6">
                  <div className="text-sm text-gray-500">
                    <span className="font-bold text-gray-700">{m.bookings}</span> حجز
                  </div>
                  <div className="font-bold text-green-600">{m.revenue.toLocaleString('ar-EG')} ر.س</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ==================== ROOMS TAB ====================
function RoomsTab() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editRoom, setEditRoom] = useState<Room | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const [form, setForm] = useState({ number: '', type: 'standard', price: 0, status: 'available' });

  const roomTypes = [
    { value: 'standard', label: 'عادية' },
    { value: 'deluxe', label: 'ديلوكس' },
    { value: 'suite', label: 'جناح' },
    { value: 'royal', label: 'ملكية' },
    { value: 'family', label: 'عائلية' },
  ];

  const statusOptions = [
    { value: 'available', label: 'متاحة', color: 'badge-available' },
    { value: 'occupied', label: 'مشغولة', color: 'badge-occupied' },
    { value: 'maintenance', label: 'صيانة', color: 'badge-maintenance' },
  ];

  const fetchRooms = useCallback(async () => {
    try {
      const res = await fetch('/api/rooms');
      const data = await res.json();
      setRooms(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchRooms(); }, [fetchRooms]);

  const openCreate = () => {
    setEditRoom(null);
    setForm({ number: '', type: 'standard', price: 0, status: 'available' });
    setShowModal(true);
  };

  const openEdit = (room: Room) => {
    setEditRoom(room);
    setForm({ number: room.number, type: room.type, price: room.price, status: room.status });
    setShowModal(true);
  };

  const handleSave = async () => {
    try {
      if (editRoom) {
        await fetch('/api/bookings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: editRoom.id, ...form }) });
        await fetch('/api/rooms', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: editRoom.id, ...form }) });
      } else {
        await fetch('/api/rooms', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
      }
      setToast({ message: editRoom ? 'تم تحديث الغرفة بنجاح' : 'تم إنشاء الغرفة بنجاح', type: 'success' });
      setShowModal(false);
      fetchRooms();
    } catch (err) {
      setToast({ message: 'حدث خطأ أثناء الحفظ', type: 'error' });
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('هل أنت متأكد من حذف هذه الغرفة؟')) return;
    try {
      const res = await fetch(`/api/rooms?id=${id}`, { method: 'DELETE' });
      if (res.ok) {
        setToast({ message: 'تم حذف الغرفة بنجاح', type: 'success' });
        fetchRooms();
      } else {
        const data = await res.json();
        setToast({ message: data.error || 'فشل في حذف الغرفة', type: 'error' });
      }
    } catch (err) {
      setToast({ message: 'حدث خطأ أثناء الحذف', type: 'error' });
    }
  };

  const filteredRooms = filterStatus === 'all' ? rooms : rooms.filter(r => r.status === filterStatus);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'border-green-400 bg-green-50 hover:bg-green-100';
      case 'occupied': return 'border-red-400 bg-red-50 hover:bg-red-100';
      case 'maintenance': return 'border-yellow-400 bg-yellow-50 hover:bg-yellow-100';
      default: return 'border-gray-300 bg-gray-50';
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-navy-600" size={40} /></div>;
  }

  return (
    <div className="space-y-6">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${filterStatus === 'all' ? 'bg-navy-900 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
          >
            الكل ({rooms.length})
          </button>
          {statusOptions.map((s) => {
            const count = rooms.filter(r => r.status === s.value).length;
            return (
              <button
                key={s.value}
                onClick={() => setFilterStatus(s.value)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${filterStatus === s.value ? 'bg-navy-900 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
              >
                {s.label} ({count})
              </button>
            );
          })}
        </div>
        <button onClick={openCreate} className="flex items-center gap-2 bg-navy-900 text-white px-4 py-2.5 rounded-lg hover:bg-navy-800 transition-colors shadow-sm">
          <Plus size={18} />
          <span>إضافة غرفة</span>
        </button>
      </div>

      {/* Rooms Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {filteredRooms.map((room) => (
          <div key={room.id} className={`rounded-xl border-2 p-4 card-hover cursor-pointer ${getStatusColor(room.status)}`}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-2xl font-bold text-navy-900">{room.number}</span>
              <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${statusOptions.find(s => s.value === room.status)?.color || ''}`}>
                {statusOptions.find(s => s.value === room.status)?.label}
              </span>
            </div>
            <div className="space-y-1.5 text-sm">
              <p className="text-gray-600">النوع: <span className="font-medium text-gray-800">{roomTypes.find(t => t.value === room.type)?.label}</span></p>
              <p className="text-gray-600">السعر: <span className="font-bold text-green-700">{room.price.toLocaleString('ar-EG')} ر.س</span></p>
            </div>
            <div className="flex items-center gap-2 mt-4 pt-3 border-t border-gray-200/50">
              <button onClick={() => openEdit(room)} className="flex-1 flex items-center justify-center gap-1 py-1.5 text-xs rounded-lg bg-navy-900 text-white hover:bg-navy-800 transition-colors">
                <Pencil size={14} /> تعديل
              </button>
              <button onClick={() => handleDelete(room.id)} className="flex items-center justify-center gap-1 py-1.5 px-3 text-xs rounded-lg bg-red-100 text-red-700 hover:bg-red-200 transition-colors">
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        ))}
        {filteredRooms.length === 0 && (
          <div className="col-span-full text-center py-16 text-gray-400">
            <Bed size={48} className="mx-auto mb-3 opacity-30" />
            <p className="text-lg">لا توجد غرف مسجلة</p>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center modal-overlay" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 animate-fade-in" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h3 className="text-lg font-bold text-navy-900">{editRoom ? 'تعديل غرفة' : 'إضافة غرفة جديدة'}</h3>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">رقم الغرفة</label>
                <input type="text" value={form.number} onChange={e => setForm({ ...form, number: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-navy-500" placeholder="مثال: 101" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">نوع الغرفة</label>
                <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-navy-500 bg-white">
                  {roomTypes.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">السعر لليلة (ر.س)</label>
                <input type="number" value={form.price} onChange={e => setForm({ ...form, price: Number(e.target.value) })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-navy-500" placeholder="0" min="0" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">الحالة</label>
                <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-navy-500 bg-white">
                  {statusOptions.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                </select>
              </div>
            </div>
            <div className="flex items-center gap-3 p-5 border-t border-gray-100">
              <button onClick={handleSave} className="flex-1 bg-navy-900 text-white py-2.5 rounded-lg hover:bg-navy-800 font-medium transition-colors">
                {editRoom ? 'حفظ التعديلات' : 'إضافة الغرفة'}
              </button>
              <button onClick={() => setShowModal(false)} className="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50 transition-colors">
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ==================== BOOKINGS TAB ====================
function BookingsTab() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editBooking, setEditBooking] = useState<Booking | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const [form, setForm] = useState({
    guest_name: '', guest_phone: '', room_number: '', check_in: '', check_out: '', status: 'pending'
  });

  const bookingStatuses = [
    { value: 'pending', label: 'معلق', color: 'badge-pending' },
    { value: 'confirmed', label: 'مؤكد', color: 'badge-confirmed' },
    { value: 'completed', label: 'مكتمل', color: 'badge-completed' },
    { value: 'cancelled', label: 'ملغي', color: 'badge-cancelled' },
  ];

  const fetchData = useCallback(async () => {
    try {
      const [bRes, rRes] = await Promise.all([fetch('/api/bookings'), fetch('/api/rooms')]);
      setBookings(await bRes.json());
      setRooms(await rRes.json());
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const availableRooms = rooms.filter(r => r.status === 'available');

  const openCreate = () => {
    setEditBooking(null);
    setForm({ guest_name: '', guest_phone: '', room_number: '', check_in: '', check_out: '', status: 'pending' });
    setShowModal(true);
  };

  const openEdit = (b: Booking) => {
    setEditBooking(b);
    setForm({ guest_name: b.guest_name, guest_phone: b.guest_phone, room_number: b.room_number, check_in: b.check_in, check_out: b.check_out, status: b.status });
    setShowModal(true);
  };

  const handleSave = async () => {
    try {
      const url = editBooking ? '/api/bookings' : '/api/bookings';
      const method = editBooking ? 'PUT' : 'POST';
      const body = editBooking ? { id: editBooking.id, ...form } : form;
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const data = await res.json();
      if (!res.ok) {
        setToast({ message: data.error || 'حدث خطأ', type: 'error' });
        return;
      }
      setToast({ message: editBooking ? 'تم تحديث الحجز بنجاح' : 'تم إنشاء الحجز بنجاح', type: 'success' });
      setShowModal(false);
      fetchData();
    } catch (err) {
      setToast({ message: 'حدث خطأ أثناء الحفظ', type: 'error' });
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('هل أنت متأكد من حذف هذا الحجز؟')) return;
    try {
      await fetch(`/api/bookings?id=${id}`, { method: 'DELETE' });
      setToast({ message: 'تم حذف الحجز بنجاح', type: 'success' });
      fetchData();
    } catch (err) {
      setToast({ message: 'حدث خطأ أثناء الحذف', type: 'error' });
    }
  };

  const filteredBookings = bookings.filter(b => {
    const matchStatus = filterStatus === 'all' || b.status === filterStatus;
    const matchSearch = !searchQuery || b.guest_name.includes(searchQuery) || b.room_number.includes(searchQuery) || (b.guest_phone && b.guest_phone.includes(searchQuery));
    return matchStatus && matchSearch;
  });

  if (loading) {
    return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-navy-600" size={40} /></div>;
  }

  return (
    <div className="space-y-6">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative">
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
              className="pr-9 pl-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-navy-500 focus:border-navy-500 w-56"
              placeholder="بحث بالاسم أو الغرفة..."
            />
          </div>
          <div className="flex items-center gap-1">
            <button onClick={() => setFilterStatus('all')} className={`px-3 py-1.5 rounded-lg text-xs font-medium ${filterStatus === 'all' ? 'bg-navy-900 text-white' : 'bg-gray-100 text-gray-600'}`}>
              الكل
            </button>
            {bookingStatuses.map(s => (
              <button key={s.value} onClick={() => setFilterStatus(s.value)} className={`px-3 py-1.5 rounded-lg text-xs font-medium ${filterStatus === s.value ? 'bg-navy-900 text-white' : 'bg-gray-100 text-gray-600'}`}>
                {s.label}
              </button>
            ))}
          </div>
        </div>
        <button onClick={openCreate} className="flex items-center gap-2 bg-navy-900 text-white px-4 py-2.5 rounded-lg hover:bg-navy-800 transition-colors shadow-sm">
          <Plus size={18} />
          <span>حجز جديد</span>
        </button>
      </div>

      {/* Bookings Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto max-h-[calc(100vh-320px)] overflow-y-auto">
          <table className="w-full">
            <thead className="bg-navy-900 text-white sticky top-0 z-10">
              <tr>
                <th className="px-4 py-3 text-right text-sm font-medium">#</th>
                <th className="px-4 py-3 text-right text-sm font-medium">الضيف</th>
                <th className="px-4 py-3 text-right text-sm font-medium">الهاتف</th>
                <th className="px-4 py-3 text-right text-sm font-medium">الغرفة</th>
                <th className="px-4 py-3 text-right text-sm font-medium">الدخول</th>
                <th className="px-4 py-3 text-right text-sm font-medium">الخروج</th>
                <th className="px-4 py-3 text-right text-sm font-medium">الليالي</th>
                <th className="px-4 py-3 text-right text-sm font-medium">المبلغ</th>
                <th className="px-4 py-3 text-right text-sm font-medium">الحالة</th>
                <th className="px-4 py-3 text-center text-sm font-medium">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredBookings.map((b, i) => (
                <tr key={b.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-sm text-gray-500">{i + 1}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-navy-100 rounded-full flex items-center justify-center">
                        <UserCheck size={14} className="text-navy-600" />
                      </div>
                      <span className="font-medium text-gray-800">{b.guest_name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">{b.guest_phone || '-'}</td>
                  <td className="px-4 py-3">
                    <span className="px-2.5 py-1 bg-navy-100 text-navy-700 rounded-lg text-sm font-medium">{b.room_number}</span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">{b.check_in}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{b.check_out}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-700">{b.nights}</td>
                  <td className="px-4 py-3 text-sm font-bold text-green-700">{b.total_price.toLocaleString('ar-EG')} ر.س</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${bookingStatuses.find(s => s.value === b.status)?.color || ''}`}>
                      {bookingStatuses.find(s => s.value === b.status)?.label}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => openEdit(b)} className="p-1.5 text-navy-600 hover:bg-navy-50 rounded-lg transition-colors" title="تعديل">
                        <Pencil size={15} />
                      </button>
                      <button onClick={() => handleDelete(b.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="حذف">
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredBookings.length === 0 && (
            <div className="text-center py-12 text-gray-400">
              <Calendar size={40} className="mx-auto mb-3 opacity-30" />
              <p>لا توجد حجوزات</p>
            </div>
          )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center modal-overlay" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 animate-fade-in" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h3 className="text-lg font-bold text-navy-900">{editBooking ? 'تعديل حجز' : 'حجز جديد'}</h3>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
            </div>
            <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">اسم الضيف *</label>
                  <input type="text" value={form.guest_name} onChange={e => setForm({ ...form, guest_name: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-navy-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">رقم الهاتف</label>
                  <input type="text" value={form.guest_phone} onChange={e => setForm({ ...form, guest_phone: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-navy-500" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">الغرفة *</label>
                <select value={form.room_number} onChange={e => setForm({ ...form, room_number: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-navy-500 bg-white">
                  <option value="">اختر غرفة...</option>
                  {rooms.map(r => (
                    <option key={r.id} value={r.number} disabled={r.status === 'occupied' && !editBooking}>
                      {r.number} - {r.type} ({r.price} ر.س) {r.status === 'occupied' ? '✗' : ''}
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">تاريخ الدخول *</label>
                  <input type="date" value={form.check_in} onChange={e => setForm({ ...form, check_in: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-navy-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">تاريخ الخروج *</label>
                  <input type="date" value={form.check_out} onChange={e => setForm({ ...form, check_out: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-navy-500" />
                </div>
              </div>
              {form.check_in && form.check_out && form.room_number && (
                <div className="bg-navy-50 rounded-lg p-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">عدد الليالي:</span>
                    <span className="font-bold text-navy-700">{Math.max(0, Math.ceil((new Date(form.check_out).getTime() - new Date(form.check_in).getTime()) / (1000 * 60 * 60 * 24)))}</span>
                  </div>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-gray-600">السعر الإجمالي:</span>
                    <span className="font-bold text-green-700">
                      {(() => {
                        const nights = Math.max(0, Math.ceil((new Date(form.check_out).getTime() - new Date(form.check_in).getTime()) / (1000 * 60 * 60 * 24)));
                        const room = rooms.find(r => r.number === form.room_number);
                        return (nights * (room?.price || 0)).toLocaleString('ar-EG')} ر.س
                      </span>
                    </span>
                  </div>
                </div>
              )}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">حالة الحجز</label>
                <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-navy-500 bg-white">
                  {bookingStatuses.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                </select>
              </div>
            </div>
            <div className="flex items-center gap-3 p-5 border-t border-gray-100">
              <button onClick={handleSave} className="flex-1 bg-navy-900 text-white py-2.5 rounded-lg hover:bg-navy-800 font-medium transition-colors">
                {editBooking ? 'حفظ التعديلات' : 'إنشاء الحجز'}
              </button>
              <button onClick={() => setShowModal(false)} className="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50 transition-colors">
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ==================== GUESTS TAB ====================
function GuestsTab() {
  const [guests, setGuests] = useState<Guest[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  const fetchGuests = useCallback(async (query?: string) => {
    setLoading(true);
    try {
      const url = query ? `/api/guests?search=${encodeURIComponent(query)}` : '/api/guests';
      const res = await fetch(url);
      setGuests(await res.json());
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchGuests(); }, [fetchGuests]);

  const handleSearch = (val: string) => {
    setSearchQuery(val);
    fetchGuests(val);
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-navy-600" size={40} /></div>;
  }

  return (
    <div className="space-y-6">
      {/* Search */}
      <div className="flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text" value={searchQuery} onChange={e => handleSearch(e.target.value)}
            className="w-full pr-9 pl-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-navy-500 focus:border-navy-500"
            placeholder="بحث باسم الضيف أو رقم الهاتف..."
          />
        </div>
        <div className="text-sm text-gray-500">
          إجمالي الضيوف: <span className="font-bold text-navy-700">{guests.length}</span>
        </div>
      </div>

      {/* Guests Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {guests.map((g, i) => (
          <div key={i} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 card-hover">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-navy-100 rounded-full flex items-center justify-center">
                <Users size={22} className="text-navy-600" />
              </div>
              <div>
                <p className="font-bold text-gray-800 text-lg">{g.guest_name}</p>
                <p className="text-sm text-gray-500 flex items-center gap-1">
                  <Phone size={12} />
                  {g.guest_phone || 'غير محدد'}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-blue-50 rounded-lg p-3 text-center">
                <p className="text-xs text-blue-600 mb-1">الحجوزات</p>
                <p className="text-xl font-bold text-blue-700">{g.total_bookings}</p>
              </div>
              <div className="bg-green-50 rounded-lg p-3 text-center">
                <p className="text-xs text-green-600 mb-1">المصروفات</p>
                <p className="text-lg font-bold text-green-700">{(g.total_spent || 0).toLocaleString('ar-EG')}</p>
              </div>
              <div className="bg-purple-50 rounded-lg p-3 text-center">
                <p className="text-xs text-purple-600 mb-1">آخر زيارة</p>
                <p className="text-xs font-medium text-purple-700 mt-1">{g.last_visit ? new Date(g.last_visit).toLocaleDateString('ar-EG') : '-'}</p>
              </div>
            </div>
          </div>
        ))}
        {guests.length === 0 && (
          <div className="col-span-full text-center py-16 text-gray-400">
            <Users size={48} className="mx-auto mb-3 opacity-30" />
            <p className="text-lg">لا يوجد ضيوف مسجلون</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ==================== HELPERS ====================
function getStatusBadge(status: string): string {
  switch (status) {
    case 'pending': return 'bg-orange-100 text-orange-700';
    case 'confirmed': return 'bg-blue-100 text-blue-700';
    case 'completed': return 'bg-green-100 text-green-700';
    case 'cancelled': return 'bg-gray-100 text-gray-700';
    default: return 'bg-gray-100 text-gray-700';
  }
}

function getStatusLabel(status: string): string {
  switch (status) {
    case 'pending': return 'معلق';
    case 'confirmed': return 'مؤكد';
    case 'completed': return 'مكتمل';
    case 'cancelled': return 'ملغي';
    default: return status;
  }
}
