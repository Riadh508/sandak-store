import { NextResponse } from 'next/server';
import { getAll, getOne, run, transaction, dbRun, dbGet, getLastInsertId } from '@/lib/db';

export async function GET() {
  try {
    const reservations = await getAll('SELECT * FROM bookings ORDER BY created_at DESC');
    return NextResponse.json(reservations);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch reservations' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { guest_name, guest_phone, room_number, check_in, check_out, status } = body;

    const result = await transaction((database) => {
      dbRun(database,
        'INSERT INTO bookings (guest_name, guest_phone, room_number, check_in, check_out, status) VALUES (?, ?, ?, ?, ?, ?)',
        [guest_name || '', guest_phone || '', room_number || '', check_in, check_out, status || 'pending']
      );
      const id = getLastInsertId(database);
      if (status === 'confirmed' && room_number) {
        dbRun(database, "UPDATE rooms SET status = 'occupied' WHERE number = ?", [room_number]);
      }
      return dbGet(database, 'SELECT * FROM bookings WHERE id = ?', [id]);
    });
    return NextResponse.json(result, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to create reservation';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    await run(
      'UPDATE bookings SET guest_name = ?, guest_phone = ?, room_number = ?, check_in = ?, check_out = ?, status = ? WHERE id = ?',
      [data.guest_name || '', data.guest_phone || '', data.room_number || '', data.check_in, data.check_out, data.status || 'pending', id]
    );

    const reservation = await getOne('SELECT * FROM bookings WHERE id = ?', [id]);
    return NextResponse.json(reservation);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to update reservation';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });

    const booking = await getOne<any>('SELECT * FROM bookings WHERE id = ?', [id]);
    await transaction((database) => {
      dbRun(database, 'DELETE FROM bookings WHERE id = ?', [id]);
      if (booking && booking.room_number) {
        const otherActive = dbGet<{ id: number }>(
          database,
          "SELECT id FROM bookings WHERE room_number = ? AND status IN ('pending', 'confirmed')",
          [booking.room_number]
        );
        if (!otherActive) {
          dbRun(database, "UPDATE rooms SET status = 'available' WHERE number = ?", [booking.room_number]);
        }
      }
    });
    return NextResponse.json({ success: true });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to delete reservation';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
