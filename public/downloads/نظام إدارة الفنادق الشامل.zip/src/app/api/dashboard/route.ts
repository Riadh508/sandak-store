import { NextResponse } from 'next/server';
import { getOne, getAll } from '@/lib/db';

// GET dashboard stats
export async function GET() {
  try {
    // Total rooms
    const totalRooms = (await getOne<{ count: number }>('SELECT COUNT(*) as count FROM rooms'))?.count || 0;

    // Available rooms
    const availableRooms = (await getOne<{ count: number }>("SELECT COUNT(*) as count FROM rooms WHERE status = 'available'"))?.count || 0;

    // Occupied rooms
    const occupiedRooms = (await getOne<{ count: number }>("SELECT COUNT(*) as count FROM rooms WHERE status = 'occupied'"))?.count || 0;

    // Total bookings
    const totalBookings = (await getOne<{ count: number }>('SELECT COUNT(*) as count FROM bookings'))?.count || 0;

    // Active bookings
    const activeBookings = (await getOne<{ count: number }>("SELECT COUNT(*) as count FROM bookings WHERE status IN ('pending', 'confirmed')"))?.count || 0;

    // Total revenue
    const totalRevenue = (await getOne<{ total: number }>("SELECT COALESCE(SUM(total_price), 0) as total FROM bookings WHERE status IN ('confirmed', 'completed')"))?.total || 0;

    // Today's check-ins
    const today = new Date().toISOString().split('T')[0];
    const todayCheckins = (await getOne<{ count: number }>("SELECT COUNT(*) as count FROM bookings WHERE check_in = ? AND status IN ('pending', 'confirmed')", [today]))?.count || 0;

    // Room type distribution
    const roomTypes = await getAll<{ type: string; count: number }>('SELECT type, COUNT(*) as count FROM rooms GROUP BY type');

    // Recent bookings
    const recentBookings = await getAll(
      'SELECT * FROM bookings ORDER BY created_at DESC LIMIT 10'
    );

    // Monthly revenue (last 6 months)
    const monthlyRevenue = await getAll(
      `SELECT
        strftime('%Y-%m', check_in) as month,
        SUM(CASE WHEN status IN ('confirmed', 'completed') THEN total_price ELSE 0 END) as revenue,
        COUNT(*) as bookings
      FROM bookings
      WHERE check_in >= date('now', '-6 months')
      GROUP BY strftime('%Y-%m', check_in)
      ORDER BY month DESC`
    );

    return NextResponse.json({
      totalRooms,
      availableRooms,
      occupiedRooms,
      totalBookings,
      activeBookings,
      totalRevenue,
      todayCheckins,
      roomTypes,
      recentBookings,
      monthlyRevenue,
    });
  } catch (error) {
    return NextResponse.json({ error: 'فشل في جلب الإحصائيات' }, { status: 500 });
  }
}
