import { NextRequest, NextResponse } from 'next/server';
import { getAll } from '@/lib/db';

// GET guests (unique from bookings)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search');

    let guests;
    if (search) {
      guests = await getAll(
        `SELECT DISTINCT guest_name, guest_phone,
                COUNT(*) as total_bookings,
                SUM(CASE WHEN status != 'cancelled' THEN total_price ELSE 0 END) as total_spent,
                MAX(created_at) as last_visit
         FROM bookings
         WHERE guest_name LIKE ? OR guest_phone LIKE ?
         GROUP BY guest_name, guest_phone
         ORDER BY last_visit DESC`,
        [`%${search}%`, `%${search}%`]
      );
    } else {
      guests = await getAll(
        `SELECT DISTINCT guest_name, guest_phone,
                COUNT(*) as total_bookings,
                SUM(CASE WHEN status != 'cancelled' THEN total_price ELSE 0 END) as total_spent,
                MAX(created_at) as last_visit
         FROM bookings
         GROUP BY guest_name, guest_phone
         ORDER BY last_visit DESC`
      );
    }

    return NextResponse.json(guests);
  } catch (error) {
    return NextResponse.json({ error: 'فشل في جلب الضيوف' }, { status: 500 });
  }
}
