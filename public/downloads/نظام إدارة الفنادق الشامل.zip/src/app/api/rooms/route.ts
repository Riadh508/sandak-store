import { NextRequest, NextResponse } from 'next/server';
import { getDb, getAll, getOne, run, dbGet } from '@/lib/db';

// GET all rooms
export async function GET() {
  try {
    const rooms = await getAll('SELECT * FROM rooms ORDER BY CAST(number AS INTEGER)');
    return NextResponse.json(rooms);
  } catch (error) {
    return NextResponse.json({ error: 'فشل في جلب الغرف' }, { status: 500 });
  }
}

// POST create room
export async function POST(request: NextRequest) {
  try {
    const { number, type, price, status } = await request.json();

    if (!number || !type || !price) {
      return NextResponse.json({ error: 'جميع الحقول مطلوبة' }, { status: 400 });
    }

    const existing = await getOne<{ id: number }>('SELECT id FROM rooms WHERE number = ?', [number]);
    if (existing) {
      return NextResponse.json({ error: 'رقم الغرفة موجود بالفعل' }, { status: 400 });
    }

    const insertId = await run(
      'INSERT INTO rooms (number, type, price, status) VALUES (?, ?, ?, ?)',
      [number, type, price, status || 'available']
    );

    const room = await getOne('SELECT * FROM rooms WHERE id = ?', [insertId]);
    return NextResponse.json(room, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'فشل في إنشاء الغرفة' }, { status: 500 });
  }
}

// PUT update room
export async function PUT(request: NextRequest) {
  try {
    const { id, number, type, price, status } = await request.json();

    if (!id) {
      return NextResponse.json({ error: 'معرف الغرفة مطلوب' }, { status: 400 });
    }

    const existing = await getOne<{ number: string }>('SELECT number FROM rooms WHERE id = ?', [id]);
    if (existing && existing.number !== number) {
      const duplicate = await getOne<{ id: number }>('SELECT id FROM rooms WHERE number = ? AND id != ?', [number, id]);
      if (duplicate) {
        return NextResponse.json({ error: 'رقم الغرفة موجود بالفعل' }, { status: 400 });
      }
    }

    await run(
      'UPDATE rooms SET number = ?, type = ?, price = ?, status = ? WHERE id = ?',
      [number, type, price, status, id]
    );

    const room = await getOne('SELECT * FROM rooms WHERE id = ?', [id]);
    return NextResponse.json(room);
  } catch (error) {
    return NextResponse.json({ error: 'فشل في تحديث الغرفة' }, { status: 500 });
  }
}

// DELETE room
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'معرف الغرفة مطلوب' }, { status: 400 });
    }

    const activeBooking = await getOne<{ id: number }>(
      "SELECT id FROM bookings WHERE room_number = (SELECT number FROM rooms WHERE id = ?) AND status IN ('pending', 'confirmed')",
      [id]
    );

    if (activeBooking) {
      return NextResponse.json({ error: 'لا يمكن حذف غرفة بها حجوزات نشطة' }, { status: 400 });
    }

    await run('DELETE FROM rooms WHERE id = ?', [id]);
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'فشل في حذف الغرفة' }, { status: 500 });
  }
}
