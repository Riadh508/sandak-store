import { NextRequest, NextResponse } from 'next/server';
import { getDb, getAll, getOne, run, dbGet, dbRun, transaction } from '@/lib/db';

// GET all bookings
export async function GET() {
  try {
    const bookings = await getAll('SELECT * FROM bookings ORDER BY created_at DESC');
    return NextResponse.json(bookings);
  } catch (error) {
    return NextResponse.json({ error: 'فشل في جلب الحجوزات' }, { status: 500 });
  }
}

// POST create booking
export async function POST(request: NextRequest) {
  try {
    const { guest_name, guest_phone, room_number, check_in, check_out, status } = await request.json();

    if (!guest_name || !room_number || !check_in || !check_out) {
      return NextResponse.json({ error: 'جميع الحقول المطلوبة يجب ملؤها' }, { status: 400 });
    }

    // Check room availability
    const room = await getOne<any>('SELECT * FROM rooms WHERE number = ?', [room_number]);
    if (!room) {
      return NextResponse.json({ error: 'الغرفة غير موجودة' }, { status: 400 });
    }

    if (room.status !== 'available') {
      return NextResponse.json({ error: 'الغرفة غير متاحة حالياً' }, { status: 400 });
    }

    // Calculate nights
    const checkInDate = new Date(check_in);
    const checkOutDate = new Date(check_out);
    const nights = Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24));

    if (nights <= 0) {
      return NextResponse.json({ error: 'تاريخ الخروج يجب أن يكون بعد تاريخ الدخول' }, { status: 400 });
    }

    const total_price = nights * room.price;

    const booking = await transaction((database) => {
      dbRun(database,
        'INSERT INTO bookings (guest_name, guest_phone, room_number, check_in, check_out, nights, total_price, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [guest_name, guest_phone, room_number, check_in, check_out, nights, total_price, status || 'pending']
      );
      const insertId = getLastInsertId(database);

      // Update room status
      if (status === 'confirmed') {
        dbRun(database, "UPDATE rooms SET status = 'occupied' WHERE number = ?", [room_number]);
      }

      return dbGet(database, 'SELECT * FROM bookings WHERE id = ?', [insertId]);
    });

    return NextResponse.json(booking, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'فشل في إنشاء الحجز' }, { status: 500 });
  }
}

// PUT update booking
export async function PUT(request: NextRequest) {
  try {
    const { id, guest_name, guest_phone, room_number, check_in, check_out, status } = await request.json();

    if (!id) {
      return NextResponse.json({ error: 'معرف الحجز مطلوب' }, { status: 400 });
    }

    const oldBooking = await getOne<any>('SELECT * FROM bookings WHERE id = ?', [id]);
    if (!oldBooking) {
      return NextResponse.json({ error: 'الحجز غير موجود' }, { status: 404 });
    }

    // Calculate new nights and price
    const checkInDate = new Date(check_in);
    const checkOutDate = new Date(check_out);
    const nights = Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24));
    const room = await getOne<any>('SELECT price FROM rooms WHERE number = ?', [room_number]);
    const total_price = nights * (room ? room.price : 0);

    const booking = await transaction((database) => {
      dbRun(database,
        'UPDATE bookings SET guest_name = ?, guest_phone = ?, room_number = ?, check_in = ?, check_out = ?, nights = ?, total_price = ?, status = ? WHERE id = ?',
        [guest_name, guest_phone, room_number, check_in, check_out, nights, total_price, status, id]
      );

      // Free old room if room changed
      if (oldBooking.room_number !== room_number && oldBooking.status !== 'cancelled') {
        dbRun(database, "UPDATE rooms SET status = 'available' WHERE number = ?", [oldBooking.room_number]);
      }

      // Update new room status based on booking status
      if (status === 'confirmed' || status === 'pending') {
        dbRun(database, "UPDATE rooms SET status = 'occupied' WHERE number = ?", [room_number]);
      } else if (status === 'cancelled' || status === 'completed') {
        const otherActive = dbGet<{ id: number }>(
          database,
          "SELECT id FROM bookings WHERE room_number = ? AND status IN ('pending', 'confirmed') AND id != ?",
          [room_number, id]
        );
        if (!otherActive) {
          dbRun(database, "UPDATE rooms SET status = 'available' WHERE number = ?", [room_number]);
        }
      }

      return dbGet(database, 'SELECT * FROM bookings WHERE id = ?', [id]);
    });

    return NextResponse.json(booking);
  } catch (error) {
    return NextResponse.json({ error: 'فشل في تحديث الحجز' }, { status: 500 });
  }
}

// DELETE booking
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'معرف الحجز مطلوب' }, { status: 400 });
    }

    const booking = await getOne<any>('SELECT * FROM bookings WHERE id = ?', [id]);
    if (booking) {
      await transaction((database) => {
        dbRun(database, 'DELETE FROM bookings WHERE id = ?', [id]);

        // Free the room if no other active bookings
        const otherActive = dbGet<{ id: number }>(
          database,
          "SELECT id FROM bookings WHERE room_number = ? AND status IN ('pending', 'confirmed')",
          [booking.room_number]
        );
        if (!otherActive) {
          dbRun(database, "UPDATE rooms SET status = 'available' WHERE number = ?", [booking.room_number]);
        }
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'فشل في حذف الحجز' }, { status: 500 });
  }
}
