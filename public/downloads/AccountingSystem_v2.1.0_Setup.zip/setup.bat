@echo off
echo Installing dependencies...
call npm install
echo Creating data directory...
if not exist data mkdir data
echo Installation complete!
echo Run: npm run dev
