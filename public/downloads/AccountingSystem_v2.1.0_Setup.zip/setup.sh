#!/bin/bash
echo "Installing dependencies..."
npm install
echo "Creating data directory..."
mkdir -p data
echo "✅ Installation complete!"
echo "Run: npm run dev"
