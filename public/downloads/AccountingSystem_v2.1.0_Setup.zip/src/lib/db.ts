import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'data', 'accounting.db');
const DIR = path.dirname(DB_PATH);

let db: Database | null = null;

const CREATE_TABLES_SQL = `
  CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    address TEXT,
    balance REAL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now', 'localtime'))
  );

  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    category TEXT NOT NULL,
    amount REAL NOT NULL,
    description TEXT,
    date TEXT NOT NULL,
    client_id INTEGER,
    created_at TEXT DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL
  );
`;

export async function getDb(): Promise<Database> {
  if (!db) {
    if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });

    const SQL = await initSqlJs();

    if (fs.existsSync(DB_PATH)) {
      const buf = fs.readFileSync(DB_PATH);
      db = new SQL.Database(buf);
    } else {
      db = new SQL.Database();
      db.run(CREATE_TABLES_SQL);
      saveDb();
    }
  }
  return db;
}

export function saveDb(): void {
  if (!db) return;
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

export async function getAll<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T[]> {
  const database = await getDb();
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  const results: T[] = [];
  while (stmt.step()) {
    results.push(stmt.getAsObject() as T);
  }
  stmt.free();
  return results;
}

export async function getOne<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T | null> {
  const database = await getDb();
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  let result: T | null = null;
  if (stmt.step()) {
    result = stmt.getAsObject() as T;
  }
  stmt.free();
  return result;
}

export async function run(sql: string, params?: unknown[]): Promise<number> {
  const database = await getDb();
  database.run(sql, params);
  saveDb();
  const res = database.exec('SELECT last_insert_rowid()');
  return res.length > 0 && res[0].values.length > 0 ? Number(res[0].values[0][0]) : 0;
}

export function getLastInsertId(database: Database): number {
  const res = database.exec('SELECT last_insert_rowid()');
  return res.length > 0 && res[0].values.length > 0 ? Number(res[0].values[0][0]) : 0;
}

export function dbRun(database: Database, sql: string, params?: unknown[]): void {
  database.run(sql, params);
}

export function dbAll<T = Record<string, unknown>>(database: Database, sql: string, params?: unknown[]): T[] {
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  const results: T[] = [];
  while (stmt.step()) {
    results.push(stmt.getAsObject() as T);
  }
  stmt.free();
  return results;
}

export function dbGet<T = Record<string, unknown>>(database: Database, sql: string, params?: unknown[]): T | null {
  const stmt = database.prepare(sql);
  if (params && params.length > 0) stmt.bind(params);
  let result: T | null = null;
  if (stmt.step()) {
    result = stmt.getAsObject() as T;
  }
  stmt.free();
  return result;
}

export async function transaction<T>(fn: (database: Database) => T): Promise<T> {
  const database = await getDb();
  try {
    database.run('BEGIN');
    const result = fn(database);
    database.run('COMMIT');
    saveDb();
    return result;
  } catch (error) {
    database.run('ROLLBACK');
    throw error;
  }
}
