import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'نظام المحاسبة',
  description: 'نظام محاسبة متكامل لإدارة المعاملات المالية',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-gray-50 text-gray-900 antialiased font-sans">
        {children}
      </body>
    </html>
  );
}
