'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard, Receipt, Users, BarChart3, Plus, Pencil, Trash2, X,
  Search, ChevronDown, ChevronUp, Check, AlertCircle, Loader2,
  Calendar, Phone, CreditCard, TrendingUp, TrendingDown,
  ArrowUpRight, ArrowDownRight, DollarSign, Filter,
  Mail, MapPin, Eye, Wallet, PieChart
} from 'lucide-react';

// ==================== TYPES ====================
interface Client {
  id: number;
  name: string;
  phone: string;
  email: string;
  address: string;
  balance: number;
  created_at: string;
  total_income: number;
  total_expense: number;
  calculated_balance: number;
}

interface Transaction {
  id: number;
  type: string;
  category: string;
  amount: number;
  description: string;
  date: string;
  client_id: number | null;
  client_name: string | null;
  created_at: string;
}

interface ReportData {
  totalIncome: number;
  totalExpense: number;
  profit: number;
  incomeByCategory: { category: string; total: number; count: number }[];
  expenseByCategory: { category: string; total: number; count: number }[];
  monthlySummary: { month: string; income: number; expense: number; transactions: number }[];
  topClients: { id: number; name: string; total_income: number; total_expense: number; transaction_count: number }[];
}

type TabType = 'dashboard' | 'transactions' | 'clients' | 'reports';

// ==================== CONSTANTS ====================
const INCOME_CATEGORIES = [
  { value: 'sales', label: 'مبيعات' },
  { value: 'services', label: 'خدمات' },
  { value: 'investments', label: 'استثمارات' },
  { value: 'other_income', label: 'دخل آخر' },
];

const EXPENSE_CATEGORIES = [
  { value: 'salaries', label: 'رواتب' },
  { value: 'rent', label: 'إيجار' },
  { value: 'supplies', label: 'مستلزمات' },
  { value: 'utilities', label: 'خدمات' },
  { value: 'marketing', label: 'تسويق' },
  { value: 'transport', label: 'مواصلات' },
  { value: 'maintenance', label: 'صيانة' },
  { value: 'other_expense', label: 'مصروف آخر' },
];

const ALL_CATEGORIES = [...INCOME_CATEGORIES, ...EXPENSE_CATEGORIES];

// ==================== MAIN COMPONENT ====================
export default function AccountingPage() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const tabs: { key: TabType; label: string; icon: React.ReactNode }[] = [
    { key: 'dashboard', label: 'لوحة التحكم', icon: <LayoutDashboard size={20} /> },
    { key: 'transactions', label: 'المعاملات', icon: <Receipt size={20} /> },
    { key: 'clients', label: 'العملاء', icon: <Users size={20} /> },
    { key: 'reports', label: 'التقارير', icon: <BarChart3 size={20} /> },
  ];

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-primary-950 text-white transition-all duration-300 flex flex-col min-h-screen fixed right-0 top-0 bottom-0 z-30`}>
        <div className="p-4 border-b border-primary-800 flex items-center gap-3">
          <div className="w-10 h-10 bg-primary-800 rounded-lg flex items-center justify-center flex-shrink-0">
            <Wallet size={22} className="text-blue-300" />
          </div>
          {sidebarOpen && (
            <div className="animate-fade-in">
              <h1 className="font-bold text-lg leading-tight">نظام المحاسبة</h1>
              <p className="text-xs text-blue-300">Accounting System</p>
            </div>
          )}
        </div>
        <nav className="flex-1 py-4">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`w-full flex items-center gap-3 px-4 py-3 transition-all duration-200 ${
                activeTab === tab.key
                  ? 'bg-primary-800 text-white border-l-4 border-blue-400'
                  : 'text-blue-200 hover:bg-primary-900 hover:text-white'
              }`}
            >
              <span className="flex-shrink-0">{tab.icon}</span>
              {sidebarOpen && <span className="animate-fade-in">{tab.label}</span>}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-primary-800">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="w-full flex items-center justify-center gap-2 py-2 text-blue-200 hover:text-white transition-colors rounded-lg hover:bg-primary-900">
            {sidebarOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
            {sidebarOpen && <span className="text-sm">طي القائمة</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'mr-64' : 'mr-20'}`}>
        <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4 sticky top-0 z-20">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-primary-900">{tabs.find(t => t.key === activeTab)?.label}</h2>
              <p className="text-sm text-gray-500">
                {activeTab === 'dashboard' && 'نظرة عامة على الوضع المالي'}
                {activeTab === 'transactions' && 'إدارة المعاملات المالية'}
                {activeTab === 'clients' && 'إدارة حسابات العملاء'}
                {activeTab === 'reports' && 'التقارير والإحصائيات'}
              </p>
            </div>
            <div className="text-sm text-gray-500">
              {new Date().toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          </div>
        </header>
        <div className="p-6 animate-fade-in">
          {activeTab === 'dashboard' && <Dashboard />}
          {activeTab === 'transactions' && <TransactionsTab />}
          {activeTab === 'clients' && <ClientsTab />}
          {activeTab === 'reports' && <ReportsTab />}
        </div>
      </main>
    </div>
  );
}

// ==================== TOAST ====================
function Toast({ message, type, onClose }: { message: string; type: 'success' | 'error'; onClose: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);
  return (
    <div className={`fixed top-4 left-4 z-50 px-4 py-3 rounded-lg shadow-lg flex items-center gap-2 animate-slide-in ${type === 'success' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}`}>
      {type === 'success' ? <Check size={18} /> : <AlertCircle size={18} />}
      <span className="text-sm font-medium">{message}</span>
      <button onClick={onClose} className="mr-2 hover:opacity-80"><X size={14} /></button>
    </div>
  );
}

// ==================== DASHBOARD ====================
function Dashboard() {
  const [report, setReport] = useState<ReportData | null>(null);
  const [recentTx, setRecentTx] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [rRes, tRes] = await Promise.all([fetch('/api/reports'), fetch('/api/transactions')]);
        setReport(await rRes.json());
        setRecentTx((await tRes.json()).slice(0, 8));
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    }
    load();
  }, []);

  if (loading || !report) {
    return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-primary-600" size={40} /></div>;
  }

  const statCards = [
    { label: 'إجمالي الدخل', value: report.totalIncome, icon: <TrendingUp size={24} />, gradient: 'stat-card-income', trend: <ArrowUpRight size={16} /> },
    { label: 'إجمالي المصروفات', value: report.totalExpense, icon: <TrendingDown size={24} />, gradient: 'stat-card-expense', trend: <ArrowDownRight size={16} /> },
    { label: 'صافي الربح', value: report.profit, icon: <DollarSign size={24} />, gradient: 'stat-card-profit', trend: report.profit >= 0 ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} /> },
  ];

  return (
    <div className="space-y-6">
      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {statCards.map((card, i) => (
          <div key={i} className={`${card.gradient} text-white rounded-2xl p-6 shadow-lg card-hover`}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm opacity-90">{card.label}</span>
              <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">{card.icon}</div>
            </div>
            <div className="flex items-end gap-2">
              <p className="text-3xl font-bold">{card.value.toLocaleString('ar-EG')}</p>
              <span className="text-sm opacity-80 mb-1">ر.س</span>
              <span className="mb-1 opacity-80">{card.trend}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Summary */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-primary-900 mb-4 flex items-center gap-2">
            <Calendar size={20} />
            الملخص الشهري
          </h3>
          {report.monthlySummary.length === 0 ? (
            <p className="text-gray-400 text-center py-8">لا توجد بيانات شهرية</p>
          ) : (
            <div className="space-y-3 max-h-80 overflow-y-auto">
              {report.monthlySummary.map((m, i) => (
                <div key={i} className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-gray-700">{m.month}</span>
                    <span className="text-xs text-gray-500">{m.transactions} معاملة</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-green-600">الدخل</span>
                        <span className="font-medium">{m.income.toLocaleString('ar-EG')}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full" style={{ width: `${Math.min(100, (m.income / (report.totalIncome || 1)) * 100)}%` }} />
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-red-600">المصروفات</span>
                        <span className="font-medium">{m.expense.toLocaleString('ar-EG')}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{ width: `${Math.min(100, (m.expense / (report.totalExpense || 1)) * 100)}%` }} />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Transactions */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-primary-900 mb-4 flex items-center gap-2">
            <CreditCard size={20} />
            أحدث المعاملات
          </h3>
          {recentTx.length === 0 ? (
            <p className="text-gray-400 text-center py-8">لا توجد معاملات بعد</p>
          ) : (
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {recentTx.map((tx) => (
                <div key={tx.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tx.type === 'income' ? 'bg-green-100' : 'bg-red-100'}`}>
                      {tx.type === 'income' ? <ArrowUpRight size={14} className="text-green-600" /> : <ArrowDownRight size={14} className="text-red-600" />}
                    </div>
                    <div>
                      <p className="font-medium text-gray-800 text-sm">{tx.description || tx.category}</p>
                      <p className="text-xs text-gray-500">{tx.date} {tx.client_name ? `• ${tx.client_name}` : ''}</p>
                    </div>
                  </div>
                  <span className={`font-bold text-sm ${tx.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                    {tx.type === 'income' ? '+' : '-'}{tx.amount.toLocaleString('ar-EG')}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Category Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-green-700 mb-4 flex items-center gap-2">
            <PieChart size={20} />
            الدخل حسب الفئة
          </h3>
          {report.incomeByCategory.length === 0 ? (
            <p className="text-gray-400 text-center py-6">لا يوجد دخل مسجل</p>
          ) : (
            <div className="space-y-2">
              {report.incomeByCategory.map((c, i) => {
                const catLabel = ALL_CATEGORIES.find(cat => cat.value === c.category)?.label || c.category;
                const pct = report.totalIncome ? (c.total / report.totalIncome) * 100 : 0;
                return (
                  <div key={i} className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">{catLabel}</span>
                    <div className="flex items-center gap-3">
                      <div className="w-24 bg-gray-100 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-sm font-bold text-green-700 w-20 text-left">{c.total.toLocaleString('ar-EG')} ر.س</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-red-700 mb-4 flex items-center gap-2">
            <PieChart size={20} />
            المصروفات حسب الفئة
          </h3>
          {report.expenseByCategory.length === 0 ? (
            <p className="text-gray-400 text-center py-6">لا يوجد مصروفات مسجلة</p>
          ) : (
            <div className="space-y-2">
              {report.expenseByCategory.map((c, i) => {
                const catLabel = ALL_CATEGORIES.find(cat => cat.value === c.category)?.label || c.category;
                const pct = report.totalExpense ? (c.total / report.totalExpense) * 100 : 0;
                return (
                  <div key={i} className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">{catLabel}</span>
                    <div className="flex items-center gap-3">
                      <div className="w-24 bg-gray-100 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-sm font-bold text-red-700 w-20 text-left">{c.total.toLocaleString('ar-EG')} ر.س</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ==================== TRANSACTIONS TAB ====================
function TransactionsTab() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editTx, setEditTx] = useState<Transaction | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const [form, setForm] = useState({
    type: 'income', category: 'sales', amount: 0, description: '', date: new Date().toISOString().split('T')[0], client_id: '' as string
  });

  const fetchData = useCallback(async () => {
    try {
      const [tRes, cRes] = await Promise.all([fetch('/api/transactions'), fetch('/api/clients')]);
      setTransactions(await tRes.json());
      setClients(await cRes.json());
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const categories = form.type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  const openCreate = () => {
    setEditTx(null);
    setForm({ type: 'income', category: 'sales', amount: 0, description: '', date: new Date().toISOString().split('T')[0], client_id: '' });
    setShowModal(true);
  };

  const openEdit = (tx: Transaction) => {
    setEditTx(tx);
    setForm({ type: tx.type, category: tx.category, amount: tx.amount, description: tx.description, date: tx.date, client_id: tx.client_id ? String(tx.client_id) : '' });
    setShowModal(true);
  };

  const handleSave = async () => {
    try {
      const url = editTx ? '/api/transactions' : '/api/transactions';
      const method = editTx ? 'PUT' : 'POST';
      const body = editTx
        ? { id: editTx.id, type: form.type, category: form.category, amount: form.amount, description: form.description, date: form.date, client_id: form.client_id ? Number(form.client_id) : null }
        : { type: form.type, category: form.category, amount: form.amount, description: form.description, date: form.date, client_id: form.client_id ? Number(form.client_id) : null };

      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const data = await res.json();
      if (!res.ok) { setToast({ message: data.error || 'حدث خطأ', type: 'error' }); return; }
      setToast({ message: editTx ? 'تم تحديث المعاملة' : 'تم إنشاء المعاملة', type: 'success' });
      setShowModal(false);
      fetchData();
    } catch (e) { setToast({ message: 'حدث خطأ', type: 'error' }); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('هل أنت متأكد من حذف هذه المعاملة؟')) return;
    try {
      await fetch(`/api/transactions?id=${id}`, { method: 'DELETE' });
      setToast({ message: 'تم حذف المعاملة', type: 'success' });
      fetchData();
    } catch (e) { setToast({ message: 'حدث خطأ', type: 'error' }); }
  };

  const filtered = transactions.filter(tx => {
    const matchType = filterType === 'all' || tx.type === filterType;
    const matchSearch = !searchQuery || tx.description?.includes(searchQuery) || tx.category.includes(searchQuery) || (tx.client_name && tx.client_name.includes(searchQuery));
    return matchType && matchSearch;
  });

  if (loading) {
    return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-primary-600" size={40} /></div>;
  }

  return (
    <div className="space-y-6">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative">
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pr-9 pl-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 w-56" placeholder="بحث..." />
          </div>
          <div className="flex items-center gap-1">
            <button onClick={() => setFilterType('all')} className={`px-3 py-1.5 rounded-lg text-xs font-medium ${filterType === 'all' ? 'bg-primary-700 text-white' : 'bg-gray-100 text-gray-600'}`}>الكل</button>
            <button onClick={() => setFilterType('income')} className={`px-3 py-1.5 rounded-lg text-xs font-medium ${filterType === 'income' ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-600'}`}>دخل</button>
            <button onClick={() => setFilterType('expense')} className={`px-3 py-1.5 rounded-lg text-xs font-medium ${filterType === 'expense' ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-600'}`}>مصروفات</button>
          </div>
        </div>
        <button onClick={openCreate} className="flex items-center gap-2 bg-primary-700 text-white px-4 py-2.5 rounded-lg hover:bg-primary-800 transition-colors shadow-sm">
          <Plus size={18} /><span>معاملة جديدة</span>
        </button>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto max-h-[calc(100vh-320px)] overflow-y-auto">
          <table className="w-full">
            <thead className="bg-primary-800 text-white sticky top-0 z-10">
              <tr>
                <th className="px-4 py-3 text-right text-sm font-medium">#</th>
                <th className="px-4 py-3 text-right text-sm font-medium">النوع</th>
                <th className="px-4 py-3 text-right text-sm font-medium">الفئة</th>
                <th className="px-4 py-3 text-right text-sm font-medium">المبلغ</th>
                <th className="px-4 py-3 text-right text-sm font-medium">الوصف</th>
                <th className="px-4 py-3 text-right text-sm font-medium">العميل</th>
                <th className="px-4 py-3 text-right text-sm font-medium">التاريخ</th>
                <th className="px-4 py-3 text-center text-sm font-medium">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map((tx, i) => (
                <tr key={tx.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-sm text-gray-500">{i + 1}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${tx.type === 'income' ? 'type-income' : 'type-expense'}`}>
                      {tx.type === 'income' ? 'دخل' : 'مصروف'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-700">{ALL_CATEGORIES.find(c => c.value === tx.category)?.label || tx.category}</td>
                  <td className={`px-4 py-3 text-sm font-bold ${tx.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                    {tx.type === 'income' ? '+' : '-'}{tx.amount.toLocaleString('ar-EG')} ر.س
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600 max-w-[200px] truncate">{tx.description || '-'}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{tx.client_name || '-'}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{tx.date}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => openEdit(tx)} className="p-1.5 text-primary-600 hover:bg-primary-50 rounded-lg transition-colors" title="تعديل"><Pencil size={15} /></button>
                      <button onClick={() => handleDelete(tx.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="حذف"><Trash2 size={15} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="text-center py-12 text-gray-400">
              <Receipt size={40} className="mx-auto mb-3 opacity-30" />
              <p>لا توجد معاملات</p>
            </div>
          )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center modal-overlay" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 animate-fade-in" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h3 className="text-lg font-bold text-primary-900">{editTx ? 'تعديل معاملة' : 'معاملة جديدة'}</h3>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
            </div>
            <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
              {/* Type Toggle */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">نوع المعاملة</label>
                <div className="flex gap-2">
                  <button type="button" onClick={() => { setForm({ ...form, type: 'income', category: INCOME_CATEGORIES[0].value }); }} className={`flex-1 py-2.5 rounded-lg font-medium text-sm transition-colors ${form.type === 'income' ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                    <ArrowUpRight size={16} className="inline ml-1" /> دخل
                  </button>
                  <button type="button" onClick={() => { setForm({ ...form, type: 'expense', category: EXPENSE_CATEGORIES[0].value }); }} className={`flex-1 py-2.5 rounded-lg font-medium text-sm transition-colors ${form.type === 'expense' ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                    <ArrowDownRight size={16} className="inline ml-1" /> مصروف
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">الفئة *</label>
                <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 bg-white">
                  {categories.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">المبلغ (ر.س) *</label>
                <input type="number" value={form.amount} onChange={e => setForm({ ...form, amount: Number(e.target.value) })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" min="0" step="0.01" placeholder="0.00" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">الوصف</label>
                <input type="text" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" placeholder="وصف المعاملة..." />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">التاريخ *</label>
                <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">العميل (اختياري)</label>
                <select value={form.client_id} onChange={e => setForm({ ...form, client_id: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 bg-white">
                  <option value="">بدون عميل</option>
                  {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
            </div>
            <div className="flex items-center gap-3 p-5 border-t border-gray-100">
              <button onClick={handleSave} className="flex-1 bg-primary-700 text-white py-2.5 rounded-lg hover:bg-primary-800 font-medium transition-colors">
                {editTx ? 'حفظ التعديلات' : 'إضافة المعاملة'}
              </button>
              <button onClick={() => setShowModal(false)} className="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50 transition-colors">إلغاء</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ==================== CLIENTS TAB ====================
function ClientsTab() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editClient, setEditClient] = useState<Client | null>(null);
  const [showHistory, setShowHistory] = useState<number | null>(null);
  const [clientTx, setClientTx] = useState<Transaction[]>([]);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const [form, setForm] = useState({ name: '', phone: '', email: '', address: '' });

  const fetchClients = useCallback(async (query?: string) => {
    setLoading(true);
    try {
      const url = query ? `/api/clients?search=${encodeURIComponent(query)}` : '/api/clients';
      const res = await fetch(url);
      setClients(await res.json());
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchClients(); }, [fetchClients]);

  const handleSearch = (val: string) => { setSearchQuery(val); fetchClients(val); };

  const openCreate = () => {
    setEditClient(null);
    setForm({ name: '', phone: '', email: '', address: '' });
    setShowModal(true);
  };

  const openEdit = (c: Client) => {
    setEditClient(c);
    setForm({ name: c.name, phone: c.phone, email: c.email, address: c.address });
    setShowModal(true);
  };

  const handleSave = async () => {
    try {
      if (editClient) {
        const res = await fetch('/api/clients', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: editClient.id, ...form }) });
        if (!res.ok) { const d = await res.json(); setToast({ message: d.error, type: 'error' }); return; }
      } else {
        const res = await fetch('/api/clients', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
        if (!res.ok) { const d = await res.json(); setToast({ message: d.error, type: 'error' }); return; }
      }
      setToast({ message: editClient ? 'تم تحديث العميل' : 'تم إنشاء العميل', type: 'success' });
      setShowModal(false);
      fetchClients(searchQuery);
    } catch (e) { setToast({ message: 'حدث خطأ', type: 'error' }); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('هل أنت متأكد من حذف هذا العميل؟')) return;
    try {
      const res = await fetch(`/api/clients?id=${id}`, { method: 'DELETE' });
      if (!res.ok) { const d = await res.json(); setToast({ message: d.error, type: 'error' }); return; }
      setToast({ message: 'تم حذف العميل', type: 'success' });
      fetchClients(searchQuery);
    } catch (e) { setToast({ message: 'حدث خطأ', type: 'error' }); }
  };

  const viewHistory = async (clientId: number) => {
    try {
      const res = await fetch(`/api/transactions?client_id=${clientId}`);
      setClientTx(await res.json());
      setShowHistory(clientId);
    } catch (e) { console.error(e); }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-primary-600" size={40} /></div>;
  }

  return (
    <div className="space-y-6">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input type="text" value={searchQuery} onChange={e => handleSearch(e.target.value)} className="w-full pr-9 pl-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500" placeholder="بحث بالاسم أو الهاتف أو البريد..." />
        </div>
        <button onClick={openCreate} className="flex items-center gap-2 bg-primary-700 text-white px-4 py-2.5 rounded-lg hover:bg-primary-800 transition-colors shadow-sm">
          <Plus size={18} /><span>عميل جديد</span>
        </button>
      </div>

      {/* Clients Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto max-h-[calc(100vh-320px)] overflow-y-auto">
          <table className="w-full">
            <thead className="bg-primary-800 text-white sticky top-0 z-10">
              <tr>
                <th className="px-4 py-3 text-right text-sm font-medium">#</th>
                <th className="px-4 py-3 text-right text-sm font-medium">الاسم</th>
                <th className="px-4 py-3 text-right text-sm font-medium">الهاتف</th>
                <th className="px-4 py-3 text-right text-sm font-medium">البريد</th>
                <th className="px-4 py-3 text-right text-sm font-medium">الدخل</th>
                <th className="px-4 py-3 text-right text-sm font-medium">المصروفات</th>
                <th className="px-4 py-3 text-right text-sm font-medium">الرصيد</th>
                <th className="px-4 py-3 text-center text-sm font-medium">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {clients.map((c, i) => (
                <tr key={c.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-sm text-gray-500">{i + 1}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                        <Users size={14} className="text-primary-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">{c.name}</p>
                        {c.address && <p className="text-xs text-gray-400 flex items-center gap-1"><MapPin size={10} />{c.address}</p>}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">{c.phone || '-'}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{c.email || '-'}</td>
                  <td className="px-4 py-3 text-sm font-medium text-green-600">{(c.total_income || 0).toLocaleString('ar-EG')}</td>
                  <td className="px-4 py-3 text-sm font-medium text-red-600">{(c.total_expense || 0).toLocaleString('ar-EG')}</td>
                  <td className="px-4 py-3">
                    <span className={`text-sm font-bold ${(c.calculated_balance || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {(c.calculated_balance || 0).toLocaleString('ar-EG')} ر.س
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => viewHistory(c.id)} className="p-1.5 text-primary-600 hover:bg-primary-50 rounded-lg" title="السجل"><Eye size={15} /></button>
                      <button onClick={() => openEdit(c)} className="p-1.5 text-primary-600 hover:bg-primary-50 rounded-lg" title="تعديل"><Pencil size={15} /></button>
                      <button onClick={() => handleDelete(c.id)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg" title="حذف"><Trash2 size={15} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {clients.length === 0 && (
            <div className="text-center py-12 text-gray-400">
              <Users size={40} className="mx-auto mb-3 opacity-30" />
              <p>لا يوجد عملاء</p>
            </div>
          )}
        </div>
      </div>

      {/* Client Form Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center modal-overlay" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 animate-fade-in" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h3 className="text-lg font-bold text-primary-900">{editClient ? 'تعديل عميل' : 'عميل جديد'}</h3>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">اسم العميل *</label>
                <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">رقم الهاتف</label>
                <input type="text" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
                <input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" dir="ltr" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">العنوان</label>
                <input type="text" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" />
              </div>
            </div>
            <div className="flex items-center gap-3 p-5 border-t border-gray-100">
              <button onClick={handleSave} className="flex-1 bg-primary-700 text-white py-2.5 rounded-lg hover:bg-primary-800 font-medium transition-colors">
                {editClient ? 'حفظ التعديلات' : 'إضافة العميل'}
              </button>
              <button onClick={() => setShowModal(false)} className="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50 transition-colors">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {/* Transaction History Modal */}
      {showHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center modal-overlay" onClick={() => setShowHistory(null)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl mx-4 animate-fade-in" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h3 className="text-lg font-bold text-primary-900">
                سجل المعاملات - {clients.find(c => c.id === showHistory)?.name}
              </h3>
              <button onClick={() => setShowHistory(null)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
            </div>
            <div className="max-h-96 overflow-y-auto">
              {clientTx.length === 0 ? (
                <p className="text-center py-12 text-gray-400">لا توجد معاملات لهذا العميل</p>
              ) : (
                <table className="w-full">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-500">التاريخ</th>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-500">النوع</th>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-500">الفئة</th>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-500">المبلغ</th>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-500">الوصف</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {clientTx.map(tx => (
                      <tr key={tx.id} className="hover:bg-gray-50">
                        <td className="px-4 py-2 text-sm text-gray-500">{tx.date}</td>
                        <td className="px-4 py-2"><span className={`text-xs px-2 py-0.5 rounded-full ${tx.type === 'income' ? 'type-income' : 'type-expense'}`}>{tx.type === 'income' ? 'دخل' : 'مصروف'}</span></td>
                        <td className="px-4 py-2 text-sm text-gray-700">{ALL_CATEGORIES.find(c => c.value === tx.category)?.label || tx.category}</td>
                        <td className={`px-4 py-2 text-sm font-bold ${tx.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>{tx.type === 'income' ? '+' : '-'}{tx.amount.toLocaleString('ar-EG')}</td>
                        <td className="px-4 py-2 text-sm text-gray-500">{tx.description || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ==================== REPORTS TAB ====================
function ReportsTab() {
  const [report, setReport] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(true);
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  const fetchReport = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (dateFrom) params.set('from', dateFrom);
      if (dateTo) params.set('to', dateTo);
      const res = await fetch(`/api/reports?${params.toString()}`);
      setReport(await res.json());
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [dateFrom, dateTo]);

  useEffect(() => { fetchReport(); }, [fetchReport]);

  if (loading || !report) {
    return <div className="flex items-center justify-center h-64"><Loader2 className="animate-spin text-primary-600" size={40} /></div>;
  }

  return (
    <div className="space-y-6">
      {/* Date Filter */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <div className="flex items-center gap-2 mb-3">
          <Filter size={18} className="text-primary-600" />
          <h3 className="font-bold text-primary-900">تصفية حسب التاريخ</h3>
        </div>
        <div className="flex flex-wrap items-end gap-4">
          <div>
            <label className="block text-sm text-gray-600 mb-1">من تاريخ</label>
            <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500" />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">إلى تاريخ</label>
            <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500" />
          </div>
          <button onClick={() => { setDateFrom(''); setDateTo(''); }} className="px-4 py-2 text-sm text-gray-600 hover:text-primary-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            إعادة تعيين
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 border border-green-200 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp size={20} className="text-green-600" />
            <span className="text-sm text-green-700">إجمالي الدخل</span>
          </div>
          <p className="text-2xl font-bold text-green-700">{report.totalIncome.toLocaleString('ar-EG')} ر.س</p>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-2">
            <TrendingDown size={20} className="text-red-600" />
            <span className="text-sm text-red-700">إجمالي المصروفات</span>
          </div>
          <p className="text-2xl font-bold text-red-700">{report.totalExpense.toLocaleString('ar-EG')} ر.س</p>
        </div>
        <div className={`${report.profit >= 0 ? 'bg-blue-50 border-blue-200' : 'bg-orange-50 border-orange-200'} border rounded-xl p-5`}>
          <div className="flex items-center gap-2 mb-2">
            <DollarSign size={20} className={report.profit >= 0 ? 'text-blue-600' : 'text-orange-600'} />
            <span className={`text-sm ${report.profit >= 0 ? 'text-blue-700' : 'text-orange-700'}`}>صافي الربح</span>
          </div>
          <p className={`text-2xl font-bold ${report.profit >= 0 ? 'text-blue-700' : 'text-orange-700'}`}>{report.profit.toLocaleString('ar-EG')} ر.س</p>
        </div>
      </div>

      {/* Income vs Expense Bar */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-primary-900 mb-4">مقارنة الدخل والمصروفات</h3>
        {report.totalIncome === 0 && report.totalExpense === 0 ? (
          <p className="text-gray-400 text-center py-8">لا توجد بيانات لعرضها</p>
        ) : (
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-green-600 font-medium">الدخل</span>
                <span className="font-bold">{report.totalIncome.toLocaleString('ar-EG')} ر.س</span>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-4">
                <div className="bg-green-500 h-4 rounded-full transition-all duration-500" style={{ width: `${Math.min(100, report.totalIncome / Math.max(report.totalIncome, report.totalExpense) * 100)}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-red-600 font-medium">المصروفات</span>
                <span className="font-bold">{report.totalExpense.toLocaleString('ar-EG')} ر.س</span>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-4">
                <div className="bg-red-500 h-4 rounded-full transition-all duration-500" style={{ width: `${Math.min(100, report.totalExpense / Math.max(report.totalIncome, report.totalExpense) * 100)}%` }} />
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Income by Category */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-green-700 mb-4">الدخل حسب الفئة</h3>
          {report.incomeByCategory.length === 0 ? (
            <p className="text-gray-400 text-center py-6">لا يوجد دخل</p>
          ) : (
            <div className="space-y-3">
              {report.incomeByCategory.map((c, i) => {
                const label = ALL_CATEGORIES.find(cat => cat.value === c.category)?.label || c.category;
                const pct = report.totalIncome ? (c.total / report.totalIncome * 100).toFixed(1) : '0';
                return (
                  <div key={i} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-gray-700">{label}</span>
                      <div className="text-left">
                        <span className="text-sm font-bold text-green-700">{c.total.toLocaleString('ar-EG')} ر.س</span>
                        <span className="text-xs text-gray-500 mr-2">({pct}%)</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-xs text-gray-500">{c.count} معاملة</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Expense by Category */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-red-700 mb-4">المصروفات حسب الفئة</h3>
          {report.expenseByCategory.length === 0 ? (
            <p className="text-gray-400 text-center py-6">لا يوجد مصروفات</p>
          ) : (
            <div className="space-y-3">
              {report.expenseByCategory.map((c, i) => {
                const label = ALL_CATEGORIES.find(cat => cat.value === c.category)?.label || c.category;
                const pct = report.totalExpense ? (c.total / report.totalExpense * 100).toFixed(1) : '0';
                return (
                  <div key={i} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-gray-700">{label}</span>
                      <div className="text-left">
                        <span className="text-sm font-bold text-red-700">{c.total.toLocaleString('ar-EG')} ر.س</span>
                        <span className="text-xs text-gray-500 mr-2">({pct}%)</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-xs text-gray-500">{c.count} معاملة</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Monthly Summary */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-primary-900 mb-4 flex items-center gap-2">
          <BarChart3 size={20} />
          الملخص الشهري
        </h3>
        {report.monthlySummary.length === 0 ? (
          <p className="text-gray-400 text-center py-8">لا توجد بيانات شهرية</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-4 py-3 text-right text-sm font-medium text-gray-600">الشهر</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-green-600">الدخل</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-red-600">المصروفات</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-blue-600">صافي الربح</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-gray-600">عدد المعاملات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {report.monthlySummary.map((m, i) => {
                  const net = m.income - m.expense;
                  return (
                    <tr key={i} className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm font-medium text-gray-700">{m.month}</td>
                      <td className="px-4 py-3 text-sm font-medium text-green-600">{m.income.toLocaleString('ar-EG')} ر.س</td>
                      <td className="px-4 py-3 text-sm font-medium text-red-600">{m.expense.toLocaleString('ar-EG')} ر.س</td>
                      <td className={`px-4 py-3 text-sm font-bold ${net >= 0 ? 'text-blue-600' : 'text-orange-600'}`}>{net.toLocaleString('ar-EG')} ر.س</td>
                      <td className="px-4 py-3 text-sm text-gray-500">{m.transactions}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Top Clients */}
      {report.topClients.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-primary-900 mb-4 flex items-center gap-2">
            <Users size={20} />
            أكثر العملاء نشاطاً
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-4 py-3 text-right text-sm font-medium text-gray-600">العميل</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-green-600">الدخل</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-red-600">المصروفات</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-gray-600">عدد المعاملات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {report.topClients.map((c, i) => (
                  <tr key={i} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-800">{c.name}</td>
                    <td className="px-4 py-3 text-sm text-green-600">{c.total_income.toLocaleString('ar-EG')} ر.س</td>
                    <td className="px-4 py-3 text-sm text-red-600">{c.total_expense.toLocaleString('ar-EG')} ر.س</td>
                    <td className="px-4 py-3 text-sm text-gray-500">{c.transaction_count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
