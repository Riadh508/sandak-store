import { NextResponse } from 'next/server';
import { getAll, run } from '@/lib/db';

export async function GET() {
  try {
    const categories = await getAll('SELECT * FROM budget_categories ORDER BY name ASC');
    return NextResponse.json(categories);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch categories' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name } = body;
    const insertId = await run('INSERT INTO budget_categories (name) VALUES (?)', [name]);
    const category = await import('@/lib/db').then(m => m.getOne('SELECT * FROM budget_categories WHERE id = ?', [insertId]));
    return NextResponse.json(category, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to create category';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });
    await run('DELETE FROM budget_categories WHERE id = ?', [id]);
    return NextResponse.json({ success: true });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to delete category';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
