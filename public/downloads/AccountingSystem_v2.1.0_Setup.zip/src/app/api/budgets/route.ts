import { NextResponse } from 'next/server';
import { getAll, getOne, run } from '@/lib/db';

export async function GET() {
  try {
    const budgets = await getAll('SELECT * FROM budgets ORDER BY year DESC, month DESC');
    return NextResponse.json(budgets);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch budgets' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { year, month, amount, category, description } = body;
    const insertId = await run(
      'INSERT INTO budgets (year, month, amount, category, description) VALUES (?, ?, ?, ?, ?)',
      [year, month, amount, category || '', description || '']
    );
    const budget = await getOne('SELECT * FROM budgets WHERE id = ?', [insertId]);
    return NextResponse.json(budget, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to create budget';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, year, month, amount, category, description } = body;
    await run(
      'UPDATE budgets SET year = ?, month = ?, amount = ?, category = ?, description = ? WHERE id = ?',
      [year, month, amount, category || '', description || '', id]
    );
    const budget = await getOne('SELECT * FROM budgets WHERE id = ?', [id]);
    return NextResponse.json(budget);
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Failed to update budget';
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
