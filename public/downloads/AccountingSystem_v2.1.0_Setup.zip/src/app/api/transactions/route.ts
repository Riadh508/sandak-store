import { NextRequest, NextResponse } from 'next/server';
import { getAll, getOne, run, transaction, dbRun, dbGet } from '@/lib/db';

// GET all transactions with optional filters
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const category = searchParams.get('category');
    const client_id = searchParams.get('client_id');
    const from = searchParams.get('from');
    const to = searchParams.get('to');

    let query = 'SELECT t.*, c.name as client_name FROM transactions t LEFT JOIN clients c ON t.client_id = c.id WHERE 1=1';
    const params: unknown[] = [];

    if (type) { query += ' AND t.type = ?'; params.push(type); }
    if (category) { query += ' AND t.category = ?'; params.push(category); }
    if (client_id) { query += ' AND t.client_id = ?'; params.push(client_id); }
    if (from) { query += ' AND t.date >= ?'; params.push(from); }
    if (to) { query += ' AND t.date <= ?'; params.push(to); }

    query += ' ORDER BY t.date DESC, t.id DESC';

    const transactions = await getAll(query, params);
    return NextResponse.json(transactions);
  } catch (error) {
    return NextResponse.json({ error: 'فشل في جلب المعاملات' }, { status: 500 });
  }
}

// POST create transaction
export async function POST(request: NextRequest) {
  try {
    const { type, category, amount, description, date, client_id } = await request.json();

    if (!type || !category || !amount || !date) {
      return NextResponse.json({ error: 'جميع الحقول المطلوبة يجب ملؤها' }, { status: 400 });
    }

    if (amount <= 0) {
      return NextResponse.json({ error: 'المبلغ يجب أن يكون أكبر من صفر' }, { status: 400 });
    }

    const transaction = await transaction((database) => {
      dbRun(database,
        'INSERT INTO transactions (type, category, amount, description, date, client_id) VALUES (?, ?, ?, ?, ?, ?)',
        [type, category, amount, description || '', date, client_id || null]
      );
      const insertId = getLastInsertId(database);

      // Update client balance
      if (client_id) {
        if (type === 'income') {
          dbRun(database, 'UPDATE clients SET balance = balance + ? WHERE id = ?', [amount, client_id]);
        } else {
          dbRun(database, 'UPDATE clients SET balance = balance - ? WHERE id = ?', [amount, client_id]);
        }
      }

      return dbGet(
        'SELECT t.*, c.name as client_name FROM transactions t LEFT JOIN clients c ON t.client_id = c.id WHERE t.id = ?',
        [insertId]
      );
    });

    return NextResponse.json(transaction, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'فشل في إنشاء المعاملة' }, { status: 500 });
  }
}

// PUT update transaction
export async function PUT(request: NextRequest) {
  try {
    const { id, type, category, amount, description, date, client_id } = await request.json();

    if (!id) {
      return NextResponse.json({ error: 'معرف المعاملة مطلوب' }, { status: 400 });
    }

    const transaction = await transaction((database) => {
      // Get old transaction to reverse balance change
      const oldTx = dbGet<any>('SELECT * FROM transactions WHERE id = ?', [id]);

      // Reverse old balance change
      if (oldTx && oldTx.client_id) {
        if (oldTx.type === 'income') {
          dbRun(database, 'UPDATE clients SET balance = balance - ? WHERE id = ?', [oldTx.amount, oldTx.client_id]);
        } else {
          dbRun(database, 'UPDATE clients SET balance = balance + ? WHERE id = ?', [oldTx.amount, oldTx.client_id]);
        }
      }

      dbRun(database,
        'UPDATE transactions SET type = ?, category = ?, amount = ?, description = ?, date = ?, client_id = ? WHERE id = ?',
        [type, category, amount, description || '', date, client_id || null, id]
      );

      // Apply new balance change
      if (client_id) {
        if (type === 'income') {
          dbRun(database, 'UPDATE clients SET balance = balance + ? WHERE id = ?', [amount, client_id]);
        } else {
          dbRun(database, 'UPDATE clients SET balance = balance - ? WHERE id = ?', [amount, client_id]);
        }
      }

      return dbGet(
        'SELECT t.*, c.name as client_name FROM transactions t LEFT JOIN clients c ON t.client_id = c.id WHERE t.id = ?',
        [id]
      );
    });

    return NextResponse.json(transaction);
  } catch (error) {
    return NextResponse.json({ error: 'فشل في تحديث المعاملة' }, { status: 500 });
  }
}

// DELETE transaction
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'معرف المعاملة مطلوب' }, { status: 400 });
    }

    await transaction((database) => {
      const tx = dbGet<any>('SELECT * FROM transactions WHERE id = ?', [id]);

      if (tx && tx.client_id) {
        // Reverse balance change
        if (tx.type === 'income') {
          dbRun(database, 'UPDATE clients SET balance = balance - ? WHERE id = ?', [tx.amount, tx.client_id]);
        } else {
          dbRun(database, 'UPDATE clients SET balance = balance + ? WHERE id = ?', [tx.amount, tx.client_id]);
        }
      }

      dbRun(database, 'DELETE FROM transactions WHERE id = ?', [id]);
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'فشل في حذف المعاملة' }, { status: 500 });
  }
}
