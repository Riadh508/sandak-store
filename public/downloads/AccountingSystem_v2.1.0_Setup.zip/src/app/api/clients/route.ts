import { NextRequest, NextResponse } from 'next/server';
import { getAll, getOne, run } from '@/lib/db';

// GET all clients
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search');

    let clients;
    if (search) {
      clients = await getAll(
        'SELECT * FROM clients WHERE name LIKE ? OR phone LIKE ? OR email LIKE ? ORDER BY created_at DESC',
        [`%${search}%`, `%${search}%`, `%${search}%`]
      );
    } else {
      clients = await getAll('SELECT * FROM clients ORDER BY created_at DESC');
    }

    // Calculate balance from transactions for each client
    const clientsWithBalance = await Promise.all(clients.map(async (client: any) => {
      const income = ((await getOne<{ total: number }>('SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE client_id = ? AND type = ?', [client.id, 'income']))?.total) || 0;
      const expense = ((await getOne<{ total: number }>('SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE client_id = ? AND type = ?', [client.id, 'expense']))?.total) || 0;
      return {
        ...client,
        total_income: income,
        total_expense: expense,
        calculated_balance: income - expense,
      };
    }));

    return NextResponse.json(clientsWithBalance);
  } catch (error) {
    return NextResponse.json({ error: 'فشل في جلب العملاء' }, { status: 500 });
  }
}

// POST create client
export async function POST(request: NextRequest) {
  try {
    const { name, phone, email, address } = await request.json();

    if (!name) {
      return NextResponse.json({ error: 'اسم العميل مطلوب' }, { status: 400 });
    }

    const insertId = await run(
      'INSERT INTO clients (name, phone, email, address) VALUES (?, ?, ?, ?)',
      [name, phone || '', email || '', address || '']
    );

    const client = await getOne('SELECT * FROM clients WHERE id = ?', [insertId]);
    return NextResponse.json({ ...client, total_income: 0, total_expense: 0, calculated_balance: 0 }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'فشل في إنشاء العميل' }, { status: 500 });
  }
}

// PUT update client
export async function PUT(request: NextRequest) {
  try {
    const { id, name, phone, email, address } = await request.json();

    if (!id) {
      return NextResponse.json({ error: 'معرف العميل مطلوب' }, { status: 400 });
    }

    await run(
      'UPDATE clients SET name = ?, phone = ?, email = ?, address = ? WHERE id = ?',
      [name, phone || '', email || '', address || '', id]
    );

    const client = await getOne<any>('SELECT * FROM clients WHERE id = ?', [id]);
    const income = ((await getOne<{ total: number }>('SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE client_id = ? AND type = ?', [id, 'income']))?.total) || 0;
    const expense = ((await getOne<{ total: number }>('SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE client_id = ? AND type = ?', [id, 'expense']))?.total) || 0;

    return NextResponse.json({ ...client, total_income: income, total_expense: expense, calculated_balance: income - expense });
  } catch (error) {
    return NextResponse.json({ error: 'فشل في تحديث العميل' }, { status: 500 });
  }
}

// DELETE client
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'معرف العميل مطلوب' }, { status: 400 });
    }

    // Check if client has transactions
    const txCount = ((await getOne<{ count: number }>('SELECT COUNT(*) as count FROM transactions WHERE client_id = ?', [id]))?.count) || 0;
    if (txCount > 0) {
      return NextResponse.json({ error: 'لا يمكن حذف عميل لديه معاملات مالية. قم بحذف المعاملات أولاً.' }, { status: 400 });
    }

    await run('DELETE FROM clients WHERE id = ?', [id]);
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'فشل في حذف العميل' }, { status: 500 });
  }
}
