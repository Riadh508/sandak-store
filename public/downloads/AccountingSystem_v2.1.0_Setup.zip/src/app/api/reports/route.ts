import { NextResponse } from 'next/server';
import { getOne, getAll } from '@/lib/db';

// GET aggregated reports
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const from = searchParams.get('from');
    const to = searchParams.get('to');

    // Base date filter
    const dateFilter = from && to
      ? `AND date BETWEEN '${from}' AND '${to}'`
      : from
      ? `AND date >= '${from}'`
      : to
      ? `AND date <= '${to}'`
      : '';

    // Total income
    const totalIncome = ((await getOne<{ total: number }>(`SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE type = 'income' ${dateFilter}`))?.total) || 0;

    // Total expense
    const totalExpense = ((await getOne<{ total: number }>(`SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE type = 'expense' ${dateFilter}`))?.total) || 0;

    // Profit
    const profit = totalIncome - totalExpense;

    // Income by category
    const incomeByCategory = await getAll(
      `SELECT category, SUM(amount) as total, COUNT(*) as count FROM transactions WHERE type = 'income' ${dateFilter} GROUP BY category ORDER BY total DESC`
    );

    // Expense by category
    const expenseByCategory = await getAll(
      `SELECT category, SUM(amount) as total, COUNT(*) as count FROM transactions WHERE type = 'expense' ${dateFilter} GROUP BY category ORDER BY total DESC`
    );

    // Monthly summary
    const monthlySummary = await getAll(
      `SELECT
        strftime('%Y-%m', date) as month,
        SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) as income,
        SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as expense,
        COUNT(*) as transactions
       FROM transactions
       WHERE 1=1 ${dateFilter}
       GROUP BY strftime('%Y-%m', date)
       ORDER BY month DESC`
    );

    // Top clients by transaction volume
    const topClients = await getAll(
      `SELECT c.name, c.id,
        SUM(CASE WHEN t.type = 'income' THEN t.amount ELSE 0 END) as total_income,
        SUM(CASE WHEN t.type = 'expense' THEN t.amount ELSE 0 END) as total_expense,
        COUNT(t.id) as transaction_count
       FROM clients c
       LEFT JOIN transactions t ON c.id = t.client_id
       WHERE 1=1 ${dateFilter.replace(/AND date/g, 'AND t.date')}
       GROUP BY c.id
       HAVING transaction_count > 0
       ORDER BY transaction_count DESC
       LIMIT 10`
    );

    return NextResponse.json({
      totalIncome,
      totalExpense,
      profit,
      incomeByCategory,
      expenseByCategory,
      monthlySummary,
      topClients,
    });
  } catch (error) {
    return NextResponse.json({ error: 'فشل في جلب التقارير' }, { status: 500 });
  }
}
